#!/usr/bin/env bash
# Register-aggregation calibration (bench/calib_reg.cpp): GPU morsels of a group-by whose
# U = G x F accumulators per thread all live in registers (G = 7 groups of l_shipmode, F sums of
# l_extendedprice per group), at several F, sync and pipelined, GPU kept busy. GPU only. Results go
# to results/<machine>_<date-time>_reg/calib_reg.csv; list the run in analysis/model_runs.json and
# analysis/model.py fits register_agg (the GPU's cost per update) from it.
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_calib_reg.sh
#   FIELDS="1 6" MAX_LOG2=20 REPS=5 COOLDOWN=2 scripts/run_calib_reg.sh   # quick smoke run
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

BIN=build/calib_reg
DATA="${DATA:-data/tpch-sf10}"
KEYS="${KEYS:-l_shipmode}"
VALS="${VALS:-l_extendedprice}"
FIELDS="${FIELDS:-1 2 3 4 5 6}"  # sums per group: U = 7, 14, 21, 28, 35, 42 accumulators per thread
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-25}"
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"
CACHE="${CACHE:-cold}"
DISPATCH="${DISPATCH:-sync pipelined}"
BATCH="${BATCH:-16}"  # morsels per pipelined batch (capped at 1 GiB of input)
SPIN="${SPIN:-20}"    # ms of ALU-only GPU work before each timed rep (busy GPU clock)

for c in "$KEYS" "$VALS"; do
  [[ -f "$DATA/$c.u32" ]] || { echo "missing $DATA/$c.u32 — run: python3 scripts/gen_tpch.py --sf 10"; exit 1; }
done

sweep_begin reg
sweep_settings "DATA=$DATA KEYS=$KEYS VALS=$VALS FIELDS='$FIELDS' MIN_LOG2=$MIN_LOG2 MAX_LOG2=$MAX_LOG2 REPS=$REPS" \
               "CACHE=$CACHE DISPATCH='$DISPATCH' BATCH=$BATCH SPIN=$SPIN COOLDOWN=$COOLDOWN"
csv="$dir/calib_reg.csv"
common=(--device gpu --data "$DATA" --keys "$KEYS" --vals "$VALS" --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2"
        --reps "$REPS" --cache "$CACHE" --batch "$BATCH" --gpu-spin-ms "$SPIN" --out "$csv")
json=(--machine-json "$dir/machine.json")

first=1
for f in $FIELDS; do
  for d in $DISPATCH; do
    if [[ $first == 1 ]]; then first=0; else sleep "$COOLDOWN"; fi
    "$BIN" --fields "$f" --dispatch "$d" "${common[@]}" ${json[@]+"${json[@]}"}
    json=()
  done
done

echo "done -> $dir"
echo "next:  list $dir in analysis/model_runs.json, then python3 analysis/model.py"
