#!/usr/bin/env bash
# Held-out query validation sweep (QUERY=q1 or q6; usually run as scripts/run_val_q1.sh or
# scripts/run_val_q6.sh): per-morsel times of the fused query kernel on the GPU (sync and pipelined
# dispatch), one P-core and one E-core worker. Held out: the model is never fitted on these runs;
# they test it (analysis/predict_<query>.py). Results go to results/<machine>_<date-time>_<query>/.
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_val_q1.sh                                  # SF10
#   DATA=data/tpch-sf1 scripts/run_val_q6.sh
#   MAX_LOG2=20 REPS=5 COOLDOWN=2 scripts/run_val_q1.sh    # quick smoke run
#   SPIN=20 scripts/run_val_q6.sh                          # keep the GPU busy ~20 ms before each timed rep
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

QUERY="${QUERY:?set QUERY=q1 or q6, or run scripts/run_val_q1.sh / scripts/run_val_q6.sh}"
case "$QUERY" in q1|q6) ;; *) echo "unknown QUERY=$QUERY (q1 or q6)" >&2; exit 1 ;; esac
BIN="build/val_$QUERY"
DATA="${DATA:-data/tpch-sf10}"
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-25}"
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"
CACHE="${CACHE:-cold}"
DISPATCH="${DISPATCH:-sync pipelined}"
BATCH="${BATCH:-16}"         # morsels per pipelined batch (capped at 1 GiB of input)
SPIN="${SPIN:-0}"            # ms of ALU-only GPU work before each timed GPU rep (GPU clock up)

[[ -f "$DATA/l_shipdate.u32" ]] || { echo "missing $DATA — run: python3 scripts/gen_tpch.py --sf 10"; exit 1; }
[[ -f "$DATA/${QUERY}_expected.txt" ]] ||
  echo "note: no $DATA/${QUERY}_expected.txt, so no check against DuckDB; run: python3 scripts/tpch_reference.py --data $DATA"

sweep_begin "$QUERY"
sweep_settings "QUERY=$QUERY DATA=$DATA MIN_LOG2=$MIN_LOG2 MAX_LOG2=$MAX_LOG2 REPS=$REPS CACHE=$CACHE DISPATCH='$DISPATCH'" \
               "BATCH=$BATCH SPIN=$SPIN COOLDOWN=$COOLDOWN"
csv="$dir/val_$QUERY.csv"
common=(--data "$DATA" --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2" --reps "$REPS" --cache "$CACHE" --out "$csv")
json=(--machine-json "$dir/machine.json")

for d in $DISPATCH; do
  "$BIN" --device gpu --dispatch "$d" --batch "$BATCH" --gpu-spin-ms "$SPIN" "${common[@]}" ${json[@]+"${json[@]}"}
  json=()
  sleep "$COOLDOWN"
done
"$BIN" --device cpu --qos p "${common[@]}" ${json[@]+"${json[@]}"}
json=()
sleep "$COOLDOWN"
"$BIN" --device cpu --qos e "${common[@]}"

echo "done -> $dir"
echo "next:  python3 analysis/predict_$QUERY.py $csv"
