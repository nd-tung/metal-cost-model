#pragma once
// Host side of the Q6 GPU kernels (kernels/q6.metal), as engine/q1_gpu.hpp: the 4 columns are
// wrapped no-copy once, a morsel is a row range bound by buffer offset, and each morsel in flight
// needs its own Slot. The grid follows filter_count's (bench/calib_filter.cpp): 256 threads per
// threadgroup, ~16 rows per thread, at most 4096 threadgroups, so Q6 runs with the occupancy the
// filter was calibrated with.
#include <Foundation/Foundation.hpp>
#include <Metal/Metal.hpp>
#include <algorithm>
#include <stdexcept>

#include "common/metal_ctx.hpp"
#include "engine/q6.hpp"

namespace mcm::q6 {

struct GpuParams {
  uint32_t n, date_lo, date_span, disc_lo, disc_span, qty_hi;  // must match Q6Params in kernels/q6.metal
};

class Gpu {
 public:
  static constexpr NS::UInteger kThreads = 256;  // per q6_partial threadgroup (kernel: <= 8 simdgroups)
  static constexpr NS::UInteger kRowsPerThread = 16;
  static constexpr NS::UInteger kMaxGroups = 4096;  // q6_partial threadgroups per morsel (grid-stride beyond)
  static constexpr NS::UInteger kFinalThreads = 256;

  struct Slot {
    MTL::Buffer* partials = nullptr;  // kMaxGroups x kVals uint64
    MTL::Buffer* out = nullptr;       // kVals uint64
  };

  Gpu(MetalCtx& ctx, const Columns& c) : ctx_(ctx) {
    partial_ = ctx.pipeline("q6_partial");
    final_ = ctx.pipeline("q6_final");
    if (partial_->maxTotalThreadsPerThreadgroup() < kThreads || final_->maxTotalThreadsPerThreadgroup() < kFinalThreads)
      throw std::runtime_error("q6 kernels: fewer than 256 threads per threadgroup available");
    for (int i = 0; i < 4; ++i) cols_[i] = wrap_no_copy(ctx.device(), *c.mem[i]);
  }
  ~Gpu() {
    for (MTL::Buffer* b : cols_) b->release();
    final_->release();
    partial_->release();
  }
  Gpu(const Gpu&) = delete;
  Gpu& operator=(const Gpu&) = delete;

  Slot new_slot() const {
    Slot s;
    s.partials = ctx_.device()->newBuffer(kMaxGroups * kVals * sizeof(uint64_t), MTL::ResourceStorageModeShared);
    s.out = ctx_.device()->newBuffer(kVals * sizeof(uint64_t), MTL::ResourceStorageModeShared);
    return s;
  }
  static void free_slot(Slot& s) {
    s.partials->release();
    s.out->release();
    s = Slot{};
  }
  static Result read(const Slot& s) {
    const uint64_t* v = static_cast<const uint64_t*>(s.out->contents());
    Result r;
    r.count = v[0];
    r.revenue = v[1];
    return r;
  }

  MTL::ComputePipelineState* partial_pso() const { return partial_; }

  // Dispatches morsel [begin, begin + n) into `enc` (sets its own pipeline states): q6_partial,
  // then q6_final, which a serial compute encoder runs after q6_partial has finished.
  void encode(MTL::ComputeCommandEncoder* enc, size_t begin, uint32_t n, const Slot& s) const {
    const NS::UInteger per_group = kThreads * kRowsPerThread;
    const NS::UInteger groups = std::clamp<NS::UInteger>((n + per_group - 1) / per_group, 1, kMaxGroups);
    const GpuParams p{n, kDateLo, kDateHi - kDateLo, kDiscLo, kDiscHi - kDiscLo, kQtyHi};
    enc->setComputePipelineState(partial_);
    for (int i = 0; i < 4; ++i) enc->setBuffer(cols_[i], begin * sizeof(uint32_t), static_cast<NS::UInteger>(i));
    enc->setBuffer(s.partials, 0, 4);
    enc->setBytes(&p, sizeof(p), 5);
    enc->dispatchThreadgroups(MTL::Size(groups, 1, 1), MTL::Size(kThreads, 1, 1));
    const uint32_t rows = static_cast<uint32_t>(groups);
    enc->setComputePipelineState(final_);
    enc->setBuffer(s.partials, 0, 0);
    enc->setBuffer(s.out, 0, 1);
    enc->setBytes(&rows, sizeof(rows), 2);
    enc->dispatchThreadgroups(MTL::Size(kVals, 1, 1), MTL::Size(kFinalThreads, 1, 1));
  }

 private:
  MetalCtx& ctx_;
  MTL::ComputePipelineState* partial_ = nullptr;
  MTL::ComputePipelineState* final_ = nullptr;
  MTL::Buffer* cols_[4] = {};
};

}  // namespace mcm::q6
