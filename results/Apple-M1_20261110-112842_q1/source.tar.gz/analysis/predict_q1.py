#!/usr/bin/env python3
"""Predict TPC-H Q1 morsel times from the single-operator model and test the prediction on the
held-out Q1 runs (bench/val_q1, scripts/run_val_q1.sh). Nothing here is fitted on Q1.

usage: python3 analysis/predict_q1.py results/<run>_q1/val_q1.csv [more runs ...] [--model models/Apple-M1.json]

Q1 per row: 7 uint32 columns (28 B), one predicate, 6 groups, 6 aggregate fields per group.
Composition rules, per device configuration d (cpu-p, cpu-e, gpu-warm, gpu-warm-pipe), from the
calibrated operators in models/<machine>.json:
  stream    T = alpha_d + n * 28 B / BW_d                     bandwidth only
  roofline  T = alpha_d + n * max(28 B / BW_d, 6 * c_d)       streaming and compute overlap
  additive  T = alpha_d + n * (28 B / BW_d + 6 * c_d)         streaming and compute do not overlap
  BW_d    = 4 B / beta of filter_count (the device's streaming rate)
  c_d     = beta of agg_group/G=7 minus its 8 B / BW_d: compute per aggregate update (>= 0)
  alpha_d = alpha of filter_count (launch + sync; Q1's two GPU dispatches share one command buffer)
For comparison, `q1-fit` is a line fitted on the Q1 runs themselves: the best any alpha + beta * n
model could do (not a prediction).

Reported per rule: the prediction error over every (run, n) median per device, and placement
accuracy: over all (run, n), how often the device the rule predicts fastest is the one measured
fastest, for a sync router {cpu-p, cpu-e, gpu-warm} and a pipelined one {cpu-p, cpu-e, gpu-warm-pipe}.
Writes predict_q1.json next to the first CSV.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fit  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
BYTES_PER_ROW = 28
AGG_FIELDS = 6
DEVICES = ["cpu-p", "cpu-e", "gpu-warm", "gpu-warm-pipe", "gpu-warm-spin", "gpu-warm-pipe-spin"]
ROUTERS = {"sync": ["cpu-p", "cpu-e", "gpu-warm"], "pipelined": ["cpu-p", "cpu-e", "gpu-warm-pipe"],
           "sync-spin": ["cpu-p", "cpu-e", "gpu-warm-spin"], "pipelined-spin": ["cpu-p", "cpu-e", "gpu-warm-pipe-spin"]}
RULES = ["stream", "roofline", "additive"]


def load_runs(paths):
    meds = []
    for p in paths:
        df = fit.prepare(pd.read_csv(p))
        df["dev"] = df["config"].str.split("/", n=1).str[1]
        if "gpu_spin_ms" in df:  # GPU kept busy before each timed rep (val_q1 --gpu-spin-ms)
            df["dev"] = df["dev"].where(~((df["device"] == "gpu") & (df["gpu_spin_ms"] > 0)), df["dev"] + "-spin")
        df["config"] = df["dev"]
        m = fit.medians(df)
        m["run"] = Path(p).parent.name
        meds.append(m)
    return pd.concat(meds, ignore_index=True)


def coefficients(model, dev):
    dev = dev.removesuffix("-spin")  # same calibrated coefficients; only the measurement differs
    f = model["ops"]["filter_count"]["configs"][dev]
    g = model["ops"]["agg_group/G=7"]["configs"][dev]
    bw = f["bytes_per_elem"] / f["beta_us_per_elem"]  # bytes per us
    c = max(g["beta_us_per_elem"] - g["bytes_per_elem"] / bw, 0.0)
    stream = BYTES_PER_ROW / bw
    return {"alpha_us": f["alpha_us"], "stream_us_per_row": stream, "compute_us_per_row": AGG_FIELDS * c,
            "beta": {"stream": stream, "roofline": max(stream, AGG_FIELDS * c), "additive": stream + AGG_FIELDS * c}}


def l2(x):
    return f"2^{math.log2(x):.1f}" if x else "none"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--model", default=str(ROOT / "models" / "Apple-M1.json"))
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    meds = load_runs(args.csv)
    meds = meds[meds["config"].isin(DEVICES)]
    devs = [d for d in DEVICES if d in set(meds["config"])]

    coef = {d: coefficients(model, d) for d in devs}
    pred = {}
    for d in devs:
        g = meds[meds["config"] == d]
        a, b, _, _ = fit.fit_linear_rel(g.groupby("n")["t_med"].median().index.values.astype(float),
                                        g.groupby("n")["t_med"].median().values.astype(float))
        coef[d]["q1_fit"] = {"alpha_us": a, "beta_us_per_row": b}
        for r in RULES:
            pred[(r, d)] = (coef[d]["alpha_us"], coef[d]["beta"][r])
        pred[("q1-fit", d)] = (a, b)
    rules = RULES + ["q1-fit"]

    out = {"model": str(Path(args.model).relative_to(ROOT)) if Path(args.model).is_absolute() else args.model,
           "runs": sorted(meds["run"].unique()), "coefficients": coef, "rules": {}}
    err = sys.stderr
    print(f"Q1 runs: {', '.join(out['runs'])}\nmodel: {out['model']}\n", file=err)
    print(f"{'device':14s} {'alpha us':>9s} {'stream':>7s} {'compute':>8s} {'Q1 fit':>7s}   (ns/row; Q1 fit = measured)",
          file=err)
    for d in devs:
        c = coef[d]
        print(f"{d:14s} {c['alpha_us']:9.1f} {c['stream_us_per_row'] * 1e3:7.3f} {c['compute_us_per_row'] * 1e3:8.3f}"
              f" {c['q1_fit']['beta_us_per_row'] * 1e3:7.3f}", file=err)

    for r in rules:
        res = {"devices": {}, "placement": {}}
        for d in devs:
            g = meds[meds["config"] == d]
            a, b = pred[(r, d)]
            rel = (a + b * g["n"].values - g["t_med"].values) / g["t_med"].values
            res["devices"][d] = {"alpha_us": a, "beta_ns_per_row": b * 1e3,
                                 "err_median": float(np.median(np.abs(rel))),
                                 "err_p90": float(np.quantile(np.abs(rel), 0.9)),
                                 "bias_median": float(np.median(rel))}
        for name, cand in ROUTERS.items():
            cand = [d for d in cand if d in devs]
            if len(cand) < 2:
                continue
            piv = meds[meds["config"].isin(cand)].pivot_table(index=["run", "n"], columns="config", values="t_med")
            piv = piv.dropna()
            measured_best = piv.idxmin(axis=1)
            ns = piv.index.get_level_values("n").values.astype(float)
            pt = pd.DataFrame({d: pred[(r, d)][0] + pred[(r, d)][1] * ns for d in cand}, index=piv.index)
            predicted_best = pt.idxmin(axis=1)
            hit = (measured_best == predicted_best)
            # cost of a wrong pick: measured time of the predicted device / measured best time
            regret = np.array([piv.loc[i, predicted_best[i]] / piv.loc[i, measured_best[i]] for i in piv.index])
            res["placement"][name] = {"accuracy": float(hit.mean()), "points": int(hit.size),
                                      "mean_slowdown_when_wrong": float(regret[~hit.values].mean()) if (~hit).any() else 1.0,
                                      "max_slowdown": float(regret.max())}
        out["rules"][r] = res

    print(f"\n{'rule':10s} " + " ".join(f"{d:>22s}" for d in devs) + "   placement: " +
          "  ".join(k for k in ROUTERS if all(d in devs for d in ROUTERS[k])), file=err)
    for r in rules:
        res = out["rules"][r]
        cells = " ".join(f"{res['devices'][d]['err_median']:>9.0%} med {res['devices'][d]['err_p90']:>5.0%} p90"
                         for d in devs)
        pl = res["placement"]
        acc = "  ".join(f"{pl[k]['accuracy']:>{len(k)}.0%}" for k in ROUTERS if k in pl)
        print(f"{r:10s} {cells}   {acc}", file=err)
    print("(error = |predicted - measured| / measured over every (run, n) median)", file=err)

    # Measured vs predicted GPU/CPU crossovers on the pooled medians.
    pooled = meds.groupby(["config", "n"])["t_med"].median()
    print("\ncrossovers (GPU faster from):", file=err)
    out["crossovers"] = {}
    for gk in [d for d in devs if d.startswith("gpu")]:
        for ck in [d for d in devs if d.startswith("cpu")]:
            m = fit.measured_crossover(pooled[gk], pooled[ck])
            _, text = fit.report(m)
            row = {"measured": text, "measured_n": m["measured_interp_n"]}
            for r in RULES:
                ga, gb = pred[(r, gk)]
                ca, cb = pred[(r, ck)]
                row[r] = (ga - ca) / (cb - gb) if cb > gb else None
            out["crossovers"][f"{gk} vs {ck}"] = row
            print(f"  {gk:14s} vs {ck}: measured {text}; predicted " +
                  ", ".join(f"{r} {l2(row[r])}" for r in RULES), file=err)

    path = Path(args.csv[0]).with_name("predict_q1.json")
    path.write_text(json.dumps(out, indent=2, default=float))
    print(f"\n-> {path}", file=err)


if __name__ == "__main__":
    main()
