#!/usr/bin/env python3
"""Exact TPC-H answers from DuckDB, in the integer encodings of scripts/gen_tpch.py, so the engine's
results can be checked exactly. Also times DuckDB on the official query text (informational only:
the DuckDB baseline has its own protocol in the evaluation).

usage: python3 scripts/tpch_reference.py --data data/tpch-sf10 [--runs 5]

Writes <data>/q1_expected.txt, one line per group in ORDER BY l_returnflag, l_linestatus:
  returnflag linestatus count sum_qty sum_base_price sum_disc_price sum_charge sum_disc
Flags are ASCII codes. Sums are over the x100 integers of gen_tpch.py: sum_qty, sum_base_price and
sum_disc are x100, sum_disc_price = sum(price * (100 - disc)) is x10^4, and
sum_charge = sum(price * (100 - disc) * (100 + tax)) is x10^6. The averages of Q1 follow from these
and count.
"""
import argparse
import statistics
import time
from pathlib import Path

import duckdb

Q1_CUTOFF_DAYS = 10471  # DATE '1998-12-01' - INTERVAL 90 DAY, as days since 1970-01-01

Q1_EXACT = """
SELECT ascii(l_returnflag) AS rf, ascii(l_linestatus) AS ls, count(*) AS cnt,
       sum(CAST(l_quantity * 100 AS HUGEINT)) AS sum_qty,
       sum(CAST(l_extendedprice * 100 AS HUGEINT)) AS sum_base_price,
       sum(CAST(l_extendedprice * 100 AS HUGEINT) * (100 - CAST(l_discount * 100 AS HUGEINT))) AS sum_disc_price,
       sum(CAST(l_extendedprice * 100 AS HUGEINT) * (100 - CAST(l_discount * 100 AS HUGEINT))
           * (100 + CAST(l_tax * 100 AS HUGEINT))) AS sum_charge,
       sum(CAST(l_discount * 100 AS HUGEINT)) AS sum_disc
FROM lineitem
WHERE l_shipdate <= DATE '1998-12-01' - INTERVAL 90 DAY
GROUP BY ALL
ORDER BY rf, ls
"""

Q1_OFFICIAL = """
SELECT l_returnflag, l_linestatus,
       sum(l_quantity) AS sum_qty,
       sum(l_extendedprice) AS sum_base_price,
       sum(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
       sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
       avg(l_quantity) AS avg_qty,
       avg(l_extendedprice) AS avg_price,
       avg(l_discount) AS avg_disc,
       count(*) AS count_order
FROM lineitem
WHERE l_shipdate <= DATE '1998-12-01' - INTERVAL 90 DAY
GROUP BY l_returnflag, l_linestatus
ORDER BY l_returnflag, l_linestatus
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="directory written by scripts/gen_tpch.py")
    ap.add_argument("--runs", type=int, default=5, help="timed DuckDB runs of the official Q1 (after one warm-up)")
    args = ap.parse_args()
    data = Path(args.data)
    con = duckdb.connect(str(data / "tpch.duckdb"), read_only=True)

    cutoff = con.execute("SELECT CAST(DATE '1998-12-01' - INTERVAL 90 DAY AS DATE) - DATE '1970-01-01'").fetchone()[0]
    if cutoff != Q1_CUTOFF_DAYS:
        raise SystemExit(f"Q1 cutoff is day {cutoff}, expected {Q1_CUTOFF_DAYS}")

    rows = con.execute(Q1_EXACT).fetchall()
    out = data / "q1_expected.txt"
    out.write_text("".join(" ".join(str(int(v)) for v in r) + "\n" for r in rows))
    print(f"Q1: {len(rows)} groups, {sum(r[2] for r in rows)} rows pass the filter -> {out}")
    for r in rows:
        print(f"  {chr(r[0])}{chr(r[1])} count={r[2]} sum_charge={r[6]}")

    con.execute(Q1_OFFICIAL).fetchall()  # warm-up
    times = []
    for _ in range(args.runs):
        t0 = time.perf_counter()
        con.execute(Q1_OFFICIAL).fetchall()
        times.append(time.perf_counter() - t0)
    threads = con.execute("SELECT current_setting('threads')").fetchone()[0]
    print(f"DuckDB official Q1: median {statistics.median(times) * 1e3:.1f} ms over {args.runs} runs "
          f"({threads} threads; informational, not the baseline protocol)")


if __name__ == "__main__":
    main()
