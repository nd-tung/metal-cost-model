#!/usr/bin/env python3
"""Generate TPC-H with DuckDB and export lineitem columns as raw binary arrays.

usage: python3 scripts/gen_tpch.py --sf 1 [--out data/tpch-sf1]

Output (one file per column, little-endian, no header):
  <col>.u32   uint32 values, one per lineitem row
  manifest.json   row count, column encodings, distinct counts, min/max

Encodings (all fit uint32 so every kernel reads the same element type):
  DATE columns     -> days since 1970-01-01
  DECIMAL(15,2)    -> value * 100 (exact integer cents)
  CHAR(1) flags    -> ASCII code
  l_shipmode       -> dictionary code 0..6 (dictionary stored in manifest)
  keys             -> as is

The DuckDB database file is kept as well (tpch.duckdb) so the DuckDB CPU-only
baseline runs on exactly the same data.
"""
import argparse
import json
import time
from pathlib import Path

import duckdb
import numpy as np

COLUMNS = {
    # name: SQL expression producing a non-negative integer < 2^32
    "l_orderkey":      "l_orderkey",
    "l_partkey":       "l_partkey",
    "l_suppkey":       "l_suppkey",
    "l_quantity":      "CAST(l_quantity * 100 AS UBIGINT)",
    "l_extendedprice": "CAST(l_extendedprice * 100 AS UBIGINT)",
    "l_discount":      "CAST(l_discount * 100 AS UBIGINT)",
    "l_tax":           "CAST(l_tax * 100 AS UBIGINT)",
    "l_returnflag":    "ascii(l_returnflag)",
    "l_linestatus":    "ascii(l_linestatus)",
    "l_shipdate":      "CAST(l_shipdate - DATE '1970-01-01' AS UBIGINT)",
    "l_commitdate":    "CAST(l_commitdate - DATE '1970-01-01' AS UBIGINT)",
    "l_receiptdate":   "CAST(l_receiptdate - DATE '1970-01-01' AS UBIGINT)",
    "l_shipmode":      "shipmode_code",
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sf", type=float, default=1.0)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    sf_tag = f"{args.sf:g}"
    out = Path(args.out or f"data/tpch-sf{sf_tag}")
    out.mkdir(parents=True, exist_ok=True)
    db_path = out / "tpch.duckdb"

    con = duckdb.connect(str(db_path))
    have = con.execute(
        "SELECT count(*) FROM information_schema.tables WHERE table_name = 'lineitem'"
    ).fetchone()[0]
    if not have:
        con.execute("INSTALL tpch; LOAD tpch;")
        t0 = time.time()
        print(f"generating TPC-H SF{sf_tag} ...")
        con.execute(f"CALL dbgen(sf={args.sf})")
        print(f"  done in {time.time() - t0:.1f}s")
    else:
        print(f"reusing existing {db_path}")

    modes = [r[0] for r in con.execute(
        "SELECT DISTINCT l_shipmode FROM lineitem ORDER BY 1").fetchall()]
    case = " ".join(f"WHEN '{m}' THEN {i}" for i, m in enumerate(modes))

    nrows = con.execute("SELECT count(*) FROM lineitem").fetchone()[0]
    manifest = {"sf": args.sf, "rows": nrows, "dtype": "uint32", "columns": {},
                "shipmode_dictionary": modes}

    # Export in a stable physical order (orderkey, linenumber) so runs are reproducible.
    for name, expr in COLUMNS.items():
        e = expr.replace("shipmode_code", f"CASE l_shipmode {case} END")
        arr = con.execute(
            f"SELECT {e} AS v FROM lineitem ORDER BY l_orderkey, l_linenumber"
        ).fetchnumpy()["v"]
        if arr.max() >= 2**32:
            raise SystemExit(f"{name} does not fit uint32")
        arr = np.ascontiguousarray(arr.astype("<u4"))
        arr.tofile(out / f"{name}.u32")
        manifest["columns"][name] = {
            "file": f"{name}.u32",
            "min": int(arr.min()),
            "max": int(arr.max()),
            "distinct": int(len(np.unique(arr))),
        }
        print(f"  {name:16s} distinct={manifest['columns'][name]['distinct']:>9d}")

    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"{nrows} rows -> {out}")


if __name__ == "__main__":
    main()
