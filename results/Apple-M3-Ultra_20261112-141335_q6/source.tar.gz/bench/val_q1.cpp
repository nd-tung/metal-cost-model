// val_q1 — TPC-H Q1 per morsel on CPU-P, CPU-E and the GPU: held-out validation data for the cost
// model (never used for fitting; analysis/predict_q1.py compares it with the model's prediction).
// The fused Q1 kernels are src/engine/q1.hpp and kernels/q1.metal; the protocol (morsel sizes,
// dispatch, cache flush, checks, CSV) is bench/val_query.hpp. CSV: op = q1, thr = the shipdate
// cutoff, bytes = 28 n (7 uint32 columns).

#include <string>

#include "engine/q1.hpp"
#include "engine/q1_gpu.hpp"
#include "val_query.hpp"

namespace {

struct Q1 {
  static constexpr const char* kOp = "q1";
  static constexpr const char* kKernelFile = "q1.metal";
  static constexpr const char* kPartialKernel = "q1_partial";
  static constexpr size_t kBytesPerRow = mcm::q1::kBytesPerRow;
  static constexpr uint32_t kThr = mcm::q1::kCutoff;
  using Columns = mcm::q1::Columns;
  using Result = mcm::q1::Result;
  using Gpu = mcm::q1::Gpu;
  static std::string what() { return "Q1, shipdate <= " + std::to_string(mcm::q1::kCutoff); }
  static Columns load(const std::string& dir) { return mcm::q1::load_columns(dir); }
  static Result reference(const Columns& c, size_t begin, size_t n) { return mcm::q1::reference(c, begin, n); }
  static void cpu(const Columns& c, size_t begin, size_t n, Result& out) { mcm::q1::cpu(c, begin, n, out); }
  static bool load_expected(const std::string& path, Result& r) { return mcm::q1::load_expected(path, r); }
  static std::string describe(const Result& r) { return mcm::q1::describe(r); }
};

}  // namespace

int main(int argc, char** argv) { return mcm::valq::run<Q1>(argc, argv); }
