#!/usr/bin/env python3
"""Build the per-machine cost model the router loads: models/<machine>.json.

usage: python3 analysis/model.py [--machine Apple-M1] [--manifest analysis/model_runs.json] [--max-err 0.2]

analysis/model_runs.json lists, per machine, the runs the model is built from (results/README.md
says which runs are valid) and which rows of each to keep:
  keep = "all"            every row
         "sync"           drop pipelined GPU rows (runs made before the span / K metric)
         "sync-no-cpu-e"  also drop CPU-E rows

Calibration: T(n) = alpha + beta * n per operator key and device configuration. Operator keys are
filter_count, agg_sum and agg_group/G=<group count>; configurations are fit.py's (cpu-p, cpu-e,
gpu-warm, gpu-cold, ... with -pipe for pipelined dispatch and -priv for private storage).
  per run     medians per n, fitted with fit.py's relative-error fit -> alpha_r, beta_r
  model       the median over runs of the per-run medians, per n, fitted the same way.
              alpha_cv, beta_cv: spread of the per-run fits (sample std / mean).
  pred_err_*  |model - measured| / measured over every (run, n) median: in-sample prediction error
              (PLAN metric 1 on the calibration data; the held-out queries come later).
  crossovers  model vs pooled medians, as in fit.json: quote `report`, the measured one.
Contention (analysis/contention.py): per-pair medians over the contention runs, one shared-ceiling
fit (B_max, w_gpu) on them, plus each run's own fit for the spread.
"""
import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import contention as cont  # noqa: E402
import fit  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

CONVENTIONS = {
    "time": "microseconds per morsel; cache-cold input (64 MB flush before every timed rep)",
    "cpu-p, cpu-e": "one worker thread on a P-core / E-core",
    "gpu-warm": "sync round trip (encode, commit, wait) on a GPU-resident buffer, GPU idle before",
    "gpu-cold": "as gpu-warm on fresh host memory wrapped no-copy right before; includes the wrap",
    "-pipe": "pipelined dispatch: GPU time per morsel with the queue kept full (span / K)",
    "-priv": "blit into a private buffer, then the kernel (resident: no blit); not a routing option",
    "-spin": "GPU kept busy (ALU-only kernel, ~20 ms) before each timed rep: the clock regime of a busy router",
    "join, sort": "groups = build rows after the filter (join) or radix passes / merged runs (sort)",
    "contention": "devices streaming together share B_max; each gets B_max * w_d * D_d / sum(w * D) "
                  "of it when their solo demands D_d exceed it (w = 1 for CPU, w_gpu for GPU)",
}


def keep_rows(df, keep):
    if keep == "all":
        return df
    if keep not in ("sync", "sync-no-cpu-e"):
        raise SystemExit(f"unknown keep rule {keep!r}")
    if "dispatch" in df:
        df = df[~((df["device"] == "gpu") & (df["dispatch"] == "pipelined"))]
    if keep == "sync-no-cpu-e":
        df = df[~((df["device"] == "cpu") & (df["qos"] == "e"))]
    return df


def op_key(df):
    """agg_group/G=<G>; join and sort ops carry their configuration in the data tag
    (join_probe/<join>_probe, sort/<keys>, sort_merge/<keys>_merge<k>); other ops are their name."""
    key = df["op"].copy()
    if "groups" in df:
        g = df["groups"].fillna(1).astype(int).astype(str)
        key = key.where(df["op"] != "agg_group", df["op"] + "/G=" + g)
    per_data = df["op"].str.startswith("join_") | df["op"].str.startswith("sort")
    return key.where(~per_data, df["op"] + "/" + df["data"])


def run_medians(entries):
    """Per-run medians per (op key | config, n), tagged with the run; plus op key -> data tags."""
    meds, tags, groups = [], {}, {}
    for e in entries:
        run, keep = e["run"], e.get("keep", "all")
        csvs = sorted((ROOT / "results" / run).glob("calib_*.csv"))
        if len(csvs) != 1:
            raise SystemExit(f"{run}: expected one calib_*.csv, found {len(csvs)}")
        raw = keep_rows(pd.read_csv(csvs[0]), keep)
        if "cache" in raw and (raw["cache"] != "cold").any():
            raise SystemExit(f"{run}: has cache-hot rows; the model is built from cache-cold runs only")
        df = fit.prepare(raw)
        df["opkey"] = op_key(df)
        for k, d in df.groupby("opkey")["data"].unique().items():
            tags.setdefault(k, set()).update(d)
        if "groups" in df:  # G (agg_group), build rows (join), radix passes or merged runs (sort)
            for k, g in df.groupby("opkey")["groups"].first().items():
                groups[k] = int(g)
        dev = df["config"].str.split("/", n=1).str[1]  # fit.py's config is <data>/<device config>
        df["config"] = df["opkey"] + "|" + dev
        m = fit.medians(df)
        m["run"] = run
        meds.append(m)
    return pd.concat(meds, ignore_index=True), tags, groups


def fit_entry(n, t, bpe, max_err):
    a, b, med, mx = fit.fit_linear_rel(np.asarray(n, float), np.asarray(t, float))
    return {"alpha_us": a, "beta_us_per_elem": b, "beta_ns_per_row": b * 1e3, "bytes_per_elem": bpe,
            "eff_bw_GBps": bpe / (b * 1e3) if b > 0 else None,
            "median_rel_err": med, "max_rel_err": mx, "fit_ok": bool(mx <= max_err), "points": int(len(n))}


def cv(x):
    x = np.asarray(x, float)
    return float(x.std(ddof=1) / abs(x.mean())) if len(x) > 1 and x.mean() != 0 else None


def build_ops(meds, tags, groups, max_err, notes):
    ops, pooled = {}, {}
    for cfg, g in meds.groupby("config"):
        key, dev = cfg.split("|")
        p = g.groupby("n")["t_med"].median()
        pooled[(key, dev)] = p
        bpe = float((g["bytes"] / g["n"]).median())
        e = fit_entry(p.index.values, p.values, bpe, max_err)
        per_run = [fit.fit_linear_rel(r["n"].values.astype(float), r["t_med"].values.astype(float))
                   for _, r in g.groupby("run")]
        pred = e["alpha_us"] + e["beta_us_per_elem"] * g["n"].values
        rel = np.abs(pred - g["t_med"].values) / g["t_med"].values
        e.update(runs=int(g["run"].nunique()), alpha_cv=cv([f[0] for f in per_run]),
                 beta_cv=cv([f[1] for f in per_run]), pred_err_median=float(np.median(rel)),
                 pred_err_p90=float(np.quantile(rel, 0.9)), n_range=[int(g["n"].min()), int(g["n"].max())],
                 source_runs=sorted(g["run"].unique()))
        op = ops.setdefault(key, {"data": sorted(tags.get(key, [])), "configs": {}})
        op["configs"][dev] = e
    for key, op in ops.items():
        cfgs = op["configs"]
        op["bytes_per_row"] = float(np.median([c["bytes_per_elem"] for c in cfgs.values()]))
        op["groups"] = groups.get(key, 1)  # G, build rows, radix passes or merged runs; 1 if none
        if key in notes:
            op["note"] = notes[key]
        op["crossovers"] = {}
        for gk in sorted(k for k in cfgs if k.startswith("gpu-")):
            for ck in ("cpu-p", "cpu-e"):
                if ck not in cfgs:
                    continue
                fg, fc = cfgs[gk], cfgs[ck]
                x = fit.fitted_crossover(fg, fc)
                m = fit.measured_crossover(pooled[(key, gk)], pooled[(key, ck)])
                status, agrees = fit.judge(x, fg, fc, m, max_err)
                rn, text = fit.report(m)
                op["crossovers"][f"{gk} vs {ck}"] = {"report": text, "report_n": rn, "fitted_n": x,
                                                     "fitted_status": status, **m}
    return dict(sorted(ops.items(), key=lambda kv: (kv[0].split("/")[0], kv[1]["groups"], kv[0])))


def build_contention(runs):
    per = []
    for run in runs:
        s = cont.summarize(cont.load(ROOT / "results" / run / "calib_contention.csv"))
        s["run"] = run
        s["shared_cap"] = cont.fit_shared_cap(s["pairs"])
        per.append(s)
    pairs = []
    for qos, t in sorted({(p["qos"], p["threads"]) for s in per for p in s["pairs"]}):
        ps = [p for s in per for p in s["pairs"] if (p["qos"], p["threads"]) == (qos, t)]
        med = {k: float(np.median([p[k] for p in ps])) for k in
               ("cpu_solo_GBps", "gpu_solo_GBps", "cpu_GBps", "gpu_GBps", "total_GBps", "kappa_cpu", "kappa_gpu")}
        pairs.append({"qos": qos, "threads": t, **med, "runs": len(ps)})
    cap = cont.fit_shared_cap(pairs)
    cpu_solo = {}
    for s in per:
        for qos, d in s["cpu_solo_GBps"].items():
            for t, v in d.items():
                cpu_solo.setdefault(qos, {}).setdefault(t, []).append(v)
    return {
        "B_max_GBps": cap["B_max_GBps"], "w_gpu": cap["w_gpu"],
        "median_rel_err": cap["median_rel_err"], "max_rel_err": cap["max_rel_err"],
        "B_max_cv": cv([s["shared_cap"]["B_max_GBps"] for s in per]),
        "w_gpu_cv": cv([s["shared_cap"]["w_gpu"] for s in per]),
        "gpu_solo_GBps": float(np.median([s["gpu_solo_GBps"] for s in per])),
        "cpu_solo_GBps": {q: {t: float(np.median(v)) for t, v in d.items()} for q, d in cpu_solo.items()},
        "pairs": pairs, "points": cap["points"],
        "per_run": [{"run": s["run"], "B_max_GBps": s["shared_cap"]["B_max_GBps"], "w_gpu": s["shared_cap"]["w_gpu"],
                     "max_rel_err": s["shared_cap"]["max_rel_err"], "gpu_drift": s["gpu_drift"]} for s in per],
    }


def pct(x):
    return "-" if x is None else f"{x:.1%}"


def print_summary(model):
    out = sys.stderr
    print(f"{model['machine']}: model from {len(model['sources']['calibration'])} calibration runs, "
          f"{len(model['sources']['contention'])} contention runs", file=out)
    for key, op in model["ops"].items():
        print(f"\n{key}  ({op['bytes_per_row']:.0f} B/row{'; ' + op['note'] if 'note' in op else ''})", file=out)
        print(f"  {'config':20s} {'alpha us':>9s} {'ns/row':>7s} {'GB/s':>6s} {'runs':>4s} {'a_cv':>6s} {'b_cv':>6s}"
              f" {'err med':>7s} {'p90':>6s}  fit", file=out)
        for dev, c in op["configs"].items():
            bw = f"{c['eff_bw_GBps']:.1f}" if c["eff_bw_GBps"] else "-"
            print(f"  {dev:20s} {c['alpha_us']:9.1f} {c['beta_ns_per_row']:7.3f} {bw:>6s} {c['runs']:4d}"
                  f" {pct(c['alpha_cv']):>6s} {pct(c['beta_cv']):>6s} {pct(c['pred_err_median']):>7s}"
                  f" {pct(c['pred_err_p90']):>6s}  {'ok' if c['fit_ok'] else 'POOR (max ' + pct(c['max_rel_err']) + ')'}",
                  file=out)
        for pair, x in op["crossovers"].items():
            if "-priv" not in pair:
                print(f"  {pair:28s} {x['report']}", file=out)
    c = model["contention"]
    print(f"\ncontention: B_max {c['B_max_GBps']:.1f} GB/s (cv {pct(c['B_max_cv'])}), w_gpu {c['w_gpu']:.2f}"
          f" (cv {pct(c['w_gpu_cv'])}), |error| median {pct(c['median_rel_err'])}, max {pct(c['max_rel_err'])}",
          file=out)
    pred = {(p["qos"], p["threads"]): p for p in c["points"]}
    for p in c["pairs"]:
        m = pred[(p["qos"], p["threads"])]
        print(f"  {p['qos']}{p['threads']} + GPU: CPU {p['cpu_GBps']:5.1f} (model {m['cpu_pred_GBps']:5.1f}, alone"
              f" {p['cpu_solo_GBps']:5.1f})  GPU {p['gpu_GBps']:5.1f} (model {m['gpu_pred_GBps']:5.1f}, alone"
              f" {p['gpu_solo_GBps']:5.1f})  total {p['total_GBps']:5.1f}", file=out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default=str(ROOT / "analysis" / "model_runs.json"))
    ap.add_argument("--machine", help="build only this machine's model (default: every machine in the manifest)")
    ap.add_argument("--max-err", type=float, default=0.2)
    args = ap.parse_args()
    manifest = json.loads(Path(args.manifest).read_text())
    machines = [args.machine] if args.machine else [k for k in manifest if not k.startswith("_")]
    for machine in machines:
        spec = manifest[machine]
        meds, tags, groups = run_medians(spec["calibration"])
        found = set(meds["machine"].unique())
        if found != {machine}:
            raise SystemExit(f"{machine}: runs report machine {sorted(found)}")
        model = {
            "machine": machine,
            "built": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "form": "T(n) = alpha_us + beta_us_per_elem * n, per op key and device configuration",
            "conventions": CONVENTIONS,
            "sources": {"calibration": spec["calibration"], "contention": spec["contention"]},
            "ops": build_ops(meds, tags, groups, args.max_err, spec.get("op_notes", {})),
            "contention": build_contention(spec["contention"]),
        }
        path = ROOT / "models" / f"{machine}.json"
        path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps(model, indent=2))
        print_summary(model)
        print(f"\n-> {path.relative_to(ROOT)}", file=sys.stderr)


if __name__ == "__main__":
    main()
