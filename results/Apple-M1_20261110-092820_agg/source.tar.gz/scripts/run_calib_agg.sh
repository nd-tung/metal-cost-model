#!/usr/bin/env bash
# Full calib_agg sweep for one machine: SUM and GROUP BY at the natural TPC-H group counts,
# each on GPU warm and cold (sync and pipelined dispatch), CPU P and CPU E.
# Results go to results/<machine>_<date-time>_agg/.
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_calib_agg.sh                        # SF10, all group counts
#   KEYS="l_shipmode l_suppkey" scripts/run_calib_agg.sh
#   MAX_LOG2=20 REPS=5 COOLDOWN=2 scripts/run_calib_agg.sh   # quick smoke run
#   DISPATCH=sync scripts/run_calib_agg.sh          # GPU round trips only (no pipelined runs)
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

BIN=build/calib_agg
DATA="${DATA:-data/tpch-sf10}"
VALS="${VALS:-l_extendedprice}"
# "-" = plain SUM (G = 1). SF10 group counts: shipmode 7, shipdate 2526, suppkey 100k, partkey 2M.
KEYS="${KEYS:-- l_shipmode l_shipdate l_suppkey l_partkey}"
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-25}"
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"
CACHE="${CACHE:-cold}"
DISPATCH="${DISPATCH:-sync pipelined}"
BATCH="${BATCH:-16}"         # morsels per pipelined batch (capped at 1 GiB of buffers)

[[ -f "$DATA/$VALS.u32" ]] || { echo "missing $DATA/$VALS.u32 — run: python3 scripts/gen_tpch.py --sf 10"; exit 1; }

sweep_begin agg
sweep_settings "DATA=$DATA VALS=$VALS KEYS='$KEYS' MIN_LOG2=$MIN_LOG2 MAX_LOG2=$MAX_LOG2 REPS=$REPS" \
               "CACHE=$CACHE DISPATCH='$DISPATCH' BATCH=$BATCH COOLDOWN=$COOLDOWN"
csv="$dir/calib_agg.csv"
json=(--machine-json "$dir/machine.json")

cfgs=()
for d in $DISPATCH; do
  cfgs+=("gpu --state warm --dispatch $d --batch $BATCH" "gpu --state cold --dispatch $d --batch $BATCH")
done
cfgs+=("cpu --qos p" "cpu --qos e")

for k in $KEYS; do
  common=(--vals "$DATA/$VALS.u32" --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2" --reps "$REPS"
          --cache "$CACHE" --out "$csv")
  [[ "$k" != "-" ]] && common+=(--keys "$DATA/$k.u32")
  for cfg in "${cfgs[@]}"; do
    # shellcheck disable=SC2086
    "$BIN" --device $cfg "${common[@]}" ${json[@]+"${json[@]}"}
    json=()
    sleep "$COOLDOWN"
  done
done

echo "done -> $dir"
echo "next:  python3 analysis/fit.py $csv --plot $dir/crossover.pdf"
