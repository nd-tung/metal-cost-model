#!/usr/bin/env bash
# Full calib_filter sweep for one machine. Results go to results/<machine>_<date-time>/
# (results/<machine>_<date-time>_cache/ when CACHE is not the default).
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_calib_filter.sh                       # TPC-H SF1 l_quantity < 24 (Q6 predicate)
#   COLUMN=data/tpch-sf1/l_shipdate.u32 THR=9131 scripts/run_calib_filter.sh
#   COLUMN= scripts/run_calib_filter.sh                # random uint32 instead of TPC-H
#   MAX_LOG2=20 REPS=5 scripts/run_calib_filter.sh     # quick smoke run
#   COLUMN=data/tpch-sf10/l_quantity.u32 scripts/run_calib_filter.sh   # SF10: sizes up to 2^25
#   CACHE=hot scripts/run_calib_filter.sh              # no cache flush (old behaviour)
#   CACHE="cold cpu-write gpu-write gpu-read cpu-read" scripts/run_calib_filter.sh   # cache-state probe (PLAN.md)
#   DISPATCH=sync scripts/run_calib_filter.sh          # GPU round trips only (no pipelined runs)
#   STORAGE="shared private" scripts/run_calib_filter.sh   # add private + blit (warm, cold, resident; sync)
#   SPIN=0 scripts/run_calib_filter.sh                 # GPU from idle (the regime of runs before 10 Nov)
#
# GPU configurations: warm and cold buffers, each with sync and pipelined dispatch
# (see bench/calib_filter.cpp); CPU: one P worker, one E worker. Each CACHE value runs all of them
# (a touched input is a GPU-resident buffer, so cpu-*/gpu-* skip the cold-buffer and private configs).
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

BIN=build/calib_filter
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-26}"
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"   # seconds between configurations (thermal)
COLUMN="${COLUMN-data/tpch-sf1/l_quantity.u32}"
THR="${THR:-2400}"           # l_quantity is stored x100, so 2400 = quantity < 24
CACHE="${CACHE:-cold}"       # cache state of the morsel's input (bench/calib_filter.cpp): cold (flush before each
                             # timed rep), hot (no flush), cpu-write, cpu-read, gpu-write, gpu-read (flush, then that
                             # device rewrites or reads the rows). Several values run each in turn into the same CSV
                             # (column cache; analysis/fit.py names every state but cold <config>-<state>)
DISPATCH="${DISPATCH:-sync pipelined}"
BATCH="${BATCH:-16}"         # morsels per pipelined batch (capped at 1 GiB of buffers)
STORAGE="${STORAGE:-shared}" # add "private" for the blit-into-private-buffer configurations
SPIN="${SPIN:-20}"           # ms of ALU-only GPU work after each flush (busy GPU clock); 0 = from idle

if [[ -n "$COLUMN" ]]; then
  [[ -f "$COLUMN" ]] || { echo "missing $COLUMN — run: python3 scripts/gen_tpch.py --sf 1"; exit 1; }
fi

suffix=""
[[ "$CACHE" == cold ]] || suffix=cache
sweep_begin "$suffix"
sweep_settings "MIN_LOG2=$MIN_LOG2 MAX_LOG2=$MAX_LOG2 REPS=$REPS CACHE='$CACHE' COLUMN=$COLUMN THR=$THR" \
               "DISPATCH='$DISPATCH' BATCH=$BATCH STORAGE='$STORAGE' SPIN=$SPIN COOLDOWN=$COOLDOWN"
csv="$dir/calib_filter.csv"
common=(--min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2" --reps "$REPS" --out "$csv")
[[ -n "$COLUMN" ]] && common+=(--column "$COLUMN" --thr "$THR")
json=(--machine-json "$dir/machine.json")

first=1
bench() {  # bench <args...>: one configuration, after a cool-down unless it is the first
  if [[ $first == 1 ]]; then first=0; else sleep "$COOLDOWN"; fi
  "$BIN" "$@" "${common[@]}" ${json[@]+"${json[@]}"}
  json=()
}

for c in $CACHE; do
  states="warm cold"
  case "$c" in cold|hot) ;; *) states=warm ;; esac
  for d in $DISPATCH; do
    for s in $states; do
      bench --device gpu --state "$s" --dispatch "$d" --batch "$BATCH" --gpu-spin-ms "$SPIN" --cache "$c"
    done
  done
  if [[ " $STORAGE " == *" private "* && ( $c == cold || $c == hot ) ]]; then
    for s in warm cold resident; do
      bench --device gpu --state "$s" --storage private --gpu-spin-ms "$SPIN" --cache "$c"
    done
  fi
  bench --device cpu --qos p --cache "$c"
  bench --device cpu --qos e --cache "$c"
done

echo "done -> $dir"
echo "next:  python3 analysis/fit.py $csv --plot $dir/crossover.pdf"
