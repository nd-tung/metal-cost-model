#pragma once
// TPC-H Q14 on the uint32 columns of scripts/gen_tpch.py: the micro-engine's fused filter + hash
// probe + sum kernel, CPU side (the GPU side is kernels/q14.metal + engine/q14_gpu.hpp).
//
//   SELECT 100 * sum(CASE WHEN p_type LIKE 'PROMO%' THEN l_extendedprice * (1 - l_discount) ELSE 0 END)
//          / sum(l_extendedprice * (1 - l_discount)) AS promo_revenue
//   FROM lineitem, part
//   WHERE l_partkey = p_partkey AND l_shipdate >= date '1995-09-01' AND l_shipdate < date '1995-10-01'
//
// Exact integer arithmetic on the encodings (dates: days since 1970-01-01; decimals: x100): the two
// sums of price * (100 - disc) are x10^4, uint64; the quotient is a presentation step. The part side
// is the hash table of engine/hash_join.hpp (key p_partkey, payload p_promo = 1 for PROMO types),
// built once on the CPU when the columns are loaded and shared by every device; every lineitem row
// of the month matches exactly one part (foreign key), the others do not probe. A morsel is a row
// range [begin, begin + n) of the four lineitem columns; the kernels branch on the date, so the rows
// of the month (1.2% of lineitem) load three more columns and probe, the rest read 4 B. kBytesPerRow
// is the upper bound, 16 B: the model's rules decide what to charge (analysis/predict_q14.py).
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "common/metal_ctx.hpp"
#include "engine/columns.hpp"
#include "engine/hash_join.hpp"

namespace mcm::q14 {

inline constexpr uint32_t kDateLo = 9374;  // DATE '1995-09-01', days since 1970-01-01 (scripts/tpch_reference.py checks)
inline constexpr uint32_t kDateHi = 9404;  // DATE '1995-10-01' (exclusive)
inline constexpr int kVals = 2;            // total, promo (must match kernels/q14.metal)
inline constexpr size_t kBytesPerRow = 4 * sizeof(uint32_t);
inline const char* const kColumnNames[4] = {"l_shipdate", "l_partkey", "l_extendedprice", "l_discount"};

struct Result {
  uint64_t total = 0, promo = 0;  // x10^4
  void merge(const Result& o) {
    total += o.total;
    promo += o.promo;
  }
  bool operator==(const Result& o) const { return total == o.total && promo == o.promo; }
};

struct Columns {
  size_t rows = 0;
  std::unique_ptr<PageAlloc> mem[4];  // the lineitem columns a morsel ranges over
  const uint32_t* col(int i) const { return static_cast<const uint32_t*>(mem[i]->data()); }
  const uint32_t* shipdate() const { return col(0); }
  const uint32_t* partkey() const { return col(1); }
  const uint32_t* price() const { return col(2); }
  const uint32_t* discount() const { return col(3); }
  // The part side: the hash table (shared by every device) and, for the reference, promo by key.
  join::Table table;
  std::vector<uint8_t> promo_of;  // indexed by p_partkey; 2 = no such part
  size_t parts = 0;
};

inline Columns load_columns(const std::string& dir) {
  Columns c;
  c.rows = load_u32_columns(dir, kColumnNames, c.mem);
  const std::vector<uint32_t> keys = join::load_u32(dir + "/p_partkey.u32");
  const std::vector<uint32_t> promo = join::load_u32(dir + "/p_promo.u32");
  if (keys.size() != promo.size()) throw std::runtime_error(dir + ": p_partkey and p_promo differ in length");
  c.parts = keys.size();
  c.table = join::make_table(keys.size());
  join::cpu_build(c.table, keys.data(), promo.data(), nullptr, 0, keys.size());
  uint32_t max_key = 0;
  for (uint32_t k : keys) max_key = std::max(max_key, k);
  c.promo_of.assign(size_t(max_key) + 1, 2);
  for (size_t i = 0; i < keys.size(); ++i) c.promo_of[keys[i]] = static_cast<uint8_t>(promo[i] ? 1 : 0);
  return c;
}

// Plain scalar loop with the dense part lookup, independent of the hash table: the correctness reference.
inline Result reference(const Columns& c, size_t begin, size_t n) {
  Result r;
  for (size_t i = begin; i < begin + n; ++i) {
    const uint32_t sd = c.shipdate()[i];
    if (sd < kDateLo || sd >= kDateHi) continue;
    const uint32_t k = c.partkey()[i];
    const uint8_t flag = k < c.promo_of.size() ? c.promo_of[k] : 2;
    if (flag == 2) continue;
    const uint64_t rev = static_cast<uint64_t>(c.price()[i]) * (100 - c.discount()[i]);
    r.total += rev;
    if (flag) r.promo += rev;
  }
  return r;
}

// The timed CPU kernel (one worker): the date test, then the hash probe for the rows that pass.
inline void cpu(const Columns& c, size_t begin, size_t n, Result& out) {
  const uint32_t *sd = c.shipdate() + begin, *pk = c.partkey() + begin, *pr = c.price() + begin, *dc = c.discount() + begin;
  const uint32_t* s = c.table.slots();
  const uint32_t mask = c.table.mask;
  uint64_t total = 0, promo = 0;
  for (size_t i = 0; i < n; ++i) {
    if (sd[i] - kDateLo >= kDateHi - kDateLo) continue;
    const uint32_t k = pk[i];
    uint32_t h = c.table.slot_of(k);
    for (;;) {
      const uint32_t sk = s[2 * h];
      if (sk == k) {
        const uint64_t rev = static_cast<uint64_t>(pr[i]) * (100 - dc[i]);
        total += rev;
        promo += rev * s[2 * h + 1];
        break;
      }
      if (sk == join::kEmpty) break;
      h = (h + 1) & mask;
    }
  }
  out.total += total;
  out.promo += promo;
}

// DuckDB's answer (scripts/tpch_reference.py): one line "count promo total" (count: the rows of the
// month). Returns false if the file does not exist.
inline bool load_expected(const std::string& path, Result& r) {
  std::ifstream f(path);
  if (!f) return false;
  uint64_t count = 0;
  if (!(f >> count >> r.promo >> r.total)) throw std::runtime_error(path + ": expected one line 'count promo total'");
  return true;
}

inline std::string describe(const Result& r) {
  std::ostringstream o;
  o << "  total=" << r.total << " promo=" << r.promo << " (x10^4); promo_revenue = "
    << (r.total ? 100.0 * static_cast<double>(r.promo) / static_cast<double>(r.total) : 0.0) << "\n";
  return o.str();
}

}  // namespace mcm::q14
