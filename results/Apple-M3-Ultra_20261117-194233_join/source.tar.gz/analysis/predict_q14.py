#!/usr/bin/env python3
"""Predict TPC-H Q14 morsel times from the single-operator model and test the prediction on the
held-out Q14 runs (bench/val_q14, scripts/run_val_q14.sh). Nothing here is fitted on Q14.

usage: python3 analysis/predict_q14.py results/<run>_q14/val_q14.csv [more runs ...] [--model models/Apple-M3-Ultra.json]
                                      [--data data/tpch-sf10]

Q14 per row: a shipdate test (4 B), and for the rows of the month (selectivity s, 1.2–1.3%) three more
columns (12 B), one probe of the part hash table (2M keys, 32 MB on the M3 Ultra) and two multiply-adds.
Composition rules, per device configuration d, from the calibrated operators:
  all-columns  T = alpha_d + n * 16 B / BW_d                      every column of every row, as Q6's kernels
  shipdate     T = alpha_d + n * 4 B / BW_d                        the filter column alone
  selective    T = alpha_d + n * (4 B / BW_d + s * (12 B / BW_d + h_d))   the selected rows' columns and probes
  lines        T = alpha_d + n * (4 B / BW_d + L(s) * 12 B / BW_d + s * h_d)   as selective, but a selected
               row pulls in the whole 128 B line of each other column: L(s) = 1 - (1 - s)^32 of the lines
  gathers      T = alpha_d + n * (4 B / BW_d + s * 4 * h_d)   each selected row costs four random accesses at
               the probe's cost: its three column lines (a selected row is ~80 rows from the next, so its
               lines are not streamed) and its slot. Added 17 Nov 2026 with the CPU kernel's selection
               vector (engine/q14.hpp) and before the M3 runs of that kernel: on the M1 a selected row cost
               ~24 ns, about four times the M1's part probe, so for those runs it is a prediction
  BW_d  = 4 B / beta of filter_count (the device's streaming rate)
  h_d   = beta of join_probe/part_probe minus its 4 B / BW_d: the cost of one probe into the part table
          (the natural build size of lineitem x part; the calibration probed every row)
  alpha_d = alpha of filter_count (launch + sync; Q14's two GPU dispatches share one command buffer)
Pipelined GPU configs: the overlap form with the large-morsel slopes, as predict_q1.py. `q14-fit` is a
line fitted on the Q14 runs themselves (not a prediction). Scored as in predict_q1.py (validate.py).
Writes predict_q14.json next to the first CSV.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import validate as V  # noqa: E402

ROOT = V.ROOT
BYTES_FILTER = 4
BYTES_REST = 12
BYTES_PER_ROW = 16
LINE_ROWS = 32  # 128 B lines of uint32
RULES = ["all-columns", "shipdate", "selective", "lines", "gathers"]
GATHERS = 4  # random accesses per selected row: three column lines and one hash slot


def selectivity(data_dir):
    rows = Path(data_dir, "l_shipdate.u32").stat().st_size // 4
    count = int(Path(data_dir, "q14_expected.txt").read_text().split()[0])
    return count / rows, rows, count


def coefficients(model, dev, sel, regime="auto", pipe_form="overlap"):
    f, src = V.pick(model, "filter_count", dev, regime)
    fb, k = V.pipe_coef(f, dev, pipe_form)
    bw = f["bytes_per_elem"] / fb  # bytes per us
    probe, _ = V.pick(model, "join_probe/part_probe", dev, regime)
    pb, _ = V.pipe_coef(probe, dev, pipe_form)
    h = max(pb - probe["bytes_per_elem"] / bw, 0.0)  # us per probe beyond streaming the key
    lines = 1 - (1 - sel) ** LINE_ROWS
    return {"calibration": src, "alpha_us": f["alpha_us"], "k": k, "probe_us": h, "selectivity": sel,
            "beta": {"all-columns": BYTES_PER_ROW / bw, "shipdate": BYTES_FILTER / bw,
                     "selective": BYTES_FILTER / bw + sel * (BYTES_REST / bw + h),
                     "lines": BYTES_FILTER / bw + lines * BYTES_REST / bw + sel * h,
                     "gathers": BYTES_FILTER / bw + sel * GATHERS * h}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--model", default=str(ROOT / "models" / "Apple-M3-Ultra.json"))
    ap.add_argument("--data", default=str(ROOT / "data" / "tpch-sf10"), help="for the selectivity: q14_expected.txt and the row count")
    ap.add_argument("--coef-regime", choices=["auto", "idle"], default="auto")
    ap.add_argument("--pipe-form", choices=V.PIPE_FORMS, default="overlap")
    ap.add_argument("--state-form", choices=V.STATE_FORMS + ["none"], default="delta")
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    sel, rows, count = selectivity(args.data)
    meds = V.load_runs(args.csv)
    devs = V.select_devices(meds["config"])
    meds = meds[meds["config"].isin(devs)]
    coef = {d: coefficients(model, V.split_state(d)[0], sel, args.coef_regime, args.pipe_form) for d in devs}
    pred = {}
    for d in devs:
        a, b = V.query_fit(meds, d)
        coef[d]["q14_fit"] = {"alpha_us": a, "beta_us_per_row": b}
        for r in RULES:
            pred[(r, d)] = V.with_state((coef[d]["alpha_us"], coef[d]["beta"][r], coef[d]["k"]), model, d, BYTES_PER_ROW, args.state_form)
        pred[("q14-fit", d)] = (a, b)
    rules = RULES + ["q14-fit"]
    states = sorted({s for d in devs for s in [V.split_state(d)[1]] if s})
    out = {"model": args.model, "runs": sorted(meds["run"].unique()), "selectivity": sel, "rows": rows, "month_rows": count,
           "coefficients": coef}
    err = sys.stderr
    print(f"Q14 runs: {', '.join(out['runs'])}\nmodel: {args.model}; selectivity {sel:.4%} ({count} of {rows} rows)" +
          (f"\ncache states: {', '.join(states)} (form {args.state_form})" if states else "") + "\n", file=err)
    print(f"{'device':19s} {'calibration':19s} {'alpha us':>9s} {'k':>5s} {'probe':>7s} " + " ".join(f"{r:>11s}" for r in RULES) +
          f" {'Q14 fit':>8s} {'alpha fit':>9s}   (ns/row; Q14 fit = measured)", file=err)
    for d in devs:
        c = coef[d]
        print(f"{d:19s} {c['calibration']:19s} {c['alpha_us']:9.1f} {c['k']:5.2f} {c['probe_us'] * 1e3:7.3f} " +
              " ".join(f"{c['beta'][r] * 1e3:11.4f}" for r in RULES) +
              f" {c['q14_fit']['beta_us_per_row'] * 1e3:8.4f} {c['q14_fit']['alpha_us']:9.1f}", file=err)
    out["rules"], out["crossovers"] = V.score(meds, devs, pred, rules, RULES, err)
    out["coef_regime"], out["pipe_form"], out["state_form"] = args.coef_regime, args.pipe_form, args.state_form
    suffix = ("" if args.coef_regime == "auto" else "_idle_coef") + ("" if args.pipe_form == "overlap" else f"_pipe_{args.pipe_form}") + (f"_state_{args.state_form}" if states else "")
    path = Path(args.csv[0]).with_name(f"predict_q14{suffix}.json")
    path.write_text(json.dumps(out, indent=2, default=float))
    print(f"\n-> {path}", file=err)


if __name__ == "__main__":
    main()
