#!/usr/bin/env python3
"""Compare the predictor forms on a cache-state validation: the predict_<query>*.json files one run of
analysis/predict_q6.py or predict_q1.py writes per --state-form (delta, ratio, line, none = the
cache-oblivious baseline). Per device config under each state: the median error per form; per router
and state: the placement accuracy per form; per GPU/CPU pair: the measured crossover and each form's.

usage: python3 analysis/compare_states.py results/<run>_q6cache/predict_q6_state_*.json [--rule stream]
"""
import argparse
import json
import math
from pathlib import Path


def l2(x):
    return f"2^{math.log2(x):.1f}" if x else "none"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("json", nargs="+")
    ap.add_argument("--rule", help="the rule to compare (default: the first rule of the first file)")
    args = ap.parse_args()
    files = {}
    for p in args.json:
        d = json.loads(Path(p).read_text())
        files[d.get("state_form", Path(p).stem)] = d
    forms = sorted(files, key=lambda f: ["delta", "ratio", "line", "none"].index(f) if f in ["delta", "ratio", "line", "none"] else 9)
    first = files[forms[0]]
    rule = args.rule or next(iter(first["rules"]))
    print(f"runs: {', '.join(first['runs'])}\nrule {rule}; forms: {', '.join(forms)}")
    devs = list(first["rules"][rule]["devices"])
    print(f"\n{'device config':34s} " + " ".join(f"{f:>14s}" for f in forms) + "   (median | p90 error)")
    for d in devs:
        cells = []
        for f in forms:
            e = files[f]["rules"][rule]["devices"].get(d)
            cells.append(f"{e['err_median']:6.1%} {e['err_p90']:6.1%}" if e else " " * 14)
        print(f"{d:34s} " + " ".join(cells))
    routers = list(first["rules"][rule]["placement"])
    print(f"\n{'router':28s} " + " ".join(f"{f:>8s}" for f in forms) + "   (placement accuracy; mean slowdown when wrong)")
    for r in routers:
        cells = []
        for f in forms:
            p = files[f]["rules"][rule]["placement"].get(r)
            cells.append(f"{p['accuracy']:4.0%}/{p['mean_slowdown_when_wrong']:4.2f}" if p else " " * 8)
        print(f"{r:28s} " + " ".join(f"{c:>8s}" for c in cells))
    print(f"\n{'pair':52s} {'measured':>9s} " + " ".join(f"{f:>8s}" for f in forms) + "   (GPU faster from)")
    for pair, x in first["crossovers"].items():
        cells = [l2(files[f]["crossovers"].get(pair, {}).get(rule)) for f in forms]
        print(f"{pair:52s} {l2(x['measured_n']):>9s} " + " ".join(f"{c:>8s}" for c in cells))


if __name__ == "__main__":
    main()
