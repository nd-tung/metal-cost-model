#!/usr/bin/env python3
"""Check of the cache-state predictor path on the probe itself: predict the cache-state runs' rows
(filter_count, 4 B per row) from the base model's filter_count (the cold calibration runs) plus the
model's cache_states tables, per state and form, and score them as the query predictors do
(analysis/validate.py: error per device config, routers and crossovers per state). Rule cold+state is
that prediction, cold-only the cache-oblivious one (the base config's cold prediction for every state),
own-fit a line on the runs themselves. In sample for the tables, out of sample for the base.

usage: python3 analysis/predict_filter.py results/<run>_cache/calib_filter.csv ... [--model models/<machine>.json] [--state-form delta|ratio|line]
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import validate as V  # noqa: E402

BYTES_PER_ROW = 4


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--model", default=str(V.ROOT / "models" / "Apple-M3-Ultra.json"))
    ap.add_argument("--state-form", choices=V.STATE_FORMS, default="delta")
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    meds = V.load_runs(args.csv)
    devs = V.select_devices(meds["config"])
    meds = meds[meds["config"].isin(devs)]
    pred = {}
    for d in devs:
        base, _ = V.split_state(d)
        f, _ = V.pick(model, "filter_count", base)
        b, k = V.pipe_coef(f, base)
        pred[("cold+state", d)] = V.with_state((f["alpha_us"], b, k), model, d, BYTES_PER_ROW, args.state_form)
        pred[("cold-only", d)] = (f["alpha_us"], b, k)
        pred[("own-fit", d)] = V.query_fit(meds, d)
    err = sys.stderr
    print(f"runs: {', '.join(sorted(meds['run'].unique()))}\nmodel: {args.model}; state form {args.state_form}", file=err)
    out, cross = V.score(meds, devs, pred, ["cold+state", "cold-only", "own-fit"], ["cold+state", "cold-only"], err)
    print("\nerror per device config, cold+state against cold-only (median | p90 | median bias):", file=err)
    for d in devs:
        s, c = out["cold+state"]["devices"][d], out["cold-only"]["devices"][d]
        print(f"  {d:32s} {s['err_median']:6.1%} {s['err_p90']:7.1%} {s['bias_median']:+7.1%}   |"
              f" {c['err_median']:6.1%} {c['err_p90']:7.1%} {c['bias_median']:+7.1%}", file=err)
    path = Path(args.csv[0]).with_name(f"predict_filter_state_{args.state_form}.json")
    path.write_text(json.dumps({"model": args.model, "state_form": args.state_form, "runs": sorted(meds["run"].unique()),
                                "rules": out, "crossovers": cross}, indent=2, default=float))
    print(f"\n-> {path}", file=err)


if __name__ == "__main__":
    main()
