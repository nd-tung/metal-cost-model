"""First look at the cache-state probe (calib_filter --cache: cold, hot, cpu-write, cpu-read, gpu-write, gpu-read
and the one-row controls cpu-touch1, gpu-touch1; README "Cache state: producer probe").
usage: cache_probe.py [--slc-mb MB] <calib_filter.csv>...   (several runs are pooled by median)
Per device: t(policy) / t(cold) per size, GB/s, the footprint touched (sync: 4 n B; pipelined: K x 4 n B),
line fits over the resident range (footprint <= SLC/2, n >= 2^16) and over the largest morsels, and
the GPU/CPU crossovers per policy."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "analysis"))
import fit  # noqa: E402

args = sys.argv[1:]
slc_mb = None
if args and args[0] == "--slc-mb":
    slc_mb = float(args[1])
    args = args[2:]
POLICIES = ["hot", "cpu-write", "cpu-read", "gpu-write", "gpu-read", "cpu-touch1", "gpu-touch1"]
DEVS = ["gpu-warm-spin", "gpu-warm-pipe-spin", "cpu-p", "cpu-e"]

meds, Ks = [], []
for p in args:
    raw = pd.read_csv(p)
    df = fit.prepare(raw)
    df["config"] = df["config"].str.split("/", n=1).str[1]
    m = fit.medians(df)
    m["run"] = Path(p).parent.name
    meds.append(m)
    Ks.append(df.groupby(["config", "n"])["batch"].median())
meds = pd.concat(meds, ignore_index=True)
K = pd.concat(Ks).groupby(level=[0, 1]).median()
machine = meds["machine"].iloc[0]
if slc_mb is None:
    slc_mb = 96.0 if "M3-Ultra" in machine else 8.0
print(f"{machine}: runs {', '.join(sorted(meds['run'].unique()))}; SLC taken as {slc_mb:.0f} MB")

pooled = meds.groupby(["config", "n"])["t_med"].median()  # median over runs


def series(cfg):
    return pooled[cfg] if cfg in pooled.index.get_level_values(0) else None


def footprint(cfg, n):
    k = K.get((cfg, n), 1)
    return 4.0 * n * (k if "-pipe" in cfg else 1)


for d in DEVS:
    cold = series(d)
    if cold is None:
        continue
    print(f"\n== {d}: cold GB/s, then t(policy) / t(cold) (median over runs of the per-run ratio; [min..max])")
    present = [p for p in POLICIES if series(f"{d}-{p}") is not None]
    hdr = f"{'n':>6s} {'footprint':>10s} {'cold GB/s':>9s} " + " ".join(f"{p:>22s}" for p in present)
    print(hdr)
    for n in cold.index:
        cells = []
        for p in present:
            cfg = f"{d}-{p}"
            r = []
            for run, g in meds[meds["n"] == n].groupby("run"):
                tc = g[g["config"] == d]["t_med"]
                tp = g[g["config"] == cfg]["t_med"]
                if len(tc) and len(tp):
                    r.append(float(tp.iloc[0] / tc.iloc[0]))
            cells.append(f"{np.median(r):6.2f} [{min(r):4.2f}..{max(r):4.2f}]" if r else " " * 22)
        fp = footprint(d, n)
        fps = f"{fp / 2**20:7.1f} MB" if fp >= 2**20 else f"{fp / 1024:7.0f} KB"
        print(f"2^{int(np.log2(n)):<4d} {fps:>10s} {4 * n / cold[n] / 1e3:9.1f} " + " ".join(cells))

print("\n== line fits, ps per row (beta) and GB/s: resident range (footprint <= SLC/2, n >= 2^16) | largest morsels (n >= n_max/8)")
print(f"{'config':34s} {'resident beta':>13s} {'GB/s':>6s} {'pts':>3s} | {'large beta':>10s} {'GB/s':>6s} | {'alpha us (line)':>15s}")
for d in DEVS:
    for p in [None] + POLICIES:
        cfg = d if p is None else f"{d}-{p}"
        s = series(cfg)
        if s is None:
            continue
        n = s.index.values.astype(float)
        fp = np.array([footprint(cfg, int(x)) for x in n])
        res = (fp <= slc_mb * 2**20 / 2) & (n >= 2**16)
        big = n >= n.max() / 8
        out = f"{cfg:34s}"
        if res.sum() >= 3:
            b = np.polyfit(n[res], s.values[res], 1)[0]
            out += f" {b * 1e6:13.2f} {4 / (b * 1e3):6.0f} {res.sum():3d} |"
        else:
            out += f" {'-':>13s} {'-':>6s} {res.sum():3d} |"
        bb = np.polyfit(n[big], s.values[big], 1)[0]
        a = fit.fit_linear_rel(n, s.values.astype(float))[0]
        out += f" {bb * 1e6:10.2f} {4 / (bb * 1e3):6.0f} | {a:15.1f}"
        print(out)

print("\n== GPU faster than the CPU from (first size where the pooled median is lower), per policy")
for g in ["gpu-warm-spin", "gpu-warm-pipe-spin"]:
    for c in ["cpu-p", "cpu-e"]:
        row = []
        for p in [None] + POLICIES:
            sg, sc = series(g if p is None else f"{g}-{p}"), series(c if p is None else f"{c}-{p}")
            if sg is None or sc is None:
                continue
            n = sorted(set(sg.index) & set(sc.index))
            faster = [x for x in n if sg[x] < sc[x]]
            row.append(f"{p or 'cold'}: {'2^' + str(int(np.log2(faster[0]))) if faster else 'never'}")
        print(f"  {g} vs {c}: " + "; ".join(row))
