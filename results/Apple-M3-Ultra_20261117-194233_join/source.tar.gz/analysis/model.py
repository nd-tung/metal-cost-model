#!/usr/bin/env python3
"""Build the per-machine cost model the router loads: models/<machine>.json.

usage: python3 analysis/model.py [--machine Apple-M1] [--manifest analysis/model_runs.json] [--max-err 0.2]

analysis/model_runs.json lists, per machine, the runs the model is built from (results/README.md
says which runs are valid) and which rows of each to keep:
  keep = "all"            every row
         "sync"           drop pipelined GPU rows (runs made before the span / K metric)
         "sync-no-cpu-e"  also drop CPU-E rows

Calibration: T(n) = alpha + beta * n per operator key and device configuration. Operator keys are
filter_count, agg_sum, agg_group/G=<group count> and agg_reg/C=<columns>/U=<accumulators per thread> (GPU only);
configurations are fit.py's (cpu-p, cpu-e, gpu-warm, gpu-cold, ... with -pipe for pipelined dispatch
and -priv for private storage).
  per run     medians per n, fitted with fit.py's relative-error fit -> alpha_r, beta_r
  model       the median over runs of the per-run medians, per n, fitted the same way.
              alpha_cv, beta_cv: spread of the per-run fits (sample std / mean).
  pred_err_*  |model - measured| / measured over every (run, n) median: in-sample prediction error
              (PLAN metric 1 on the calibration data; the held-out queries come later).
  large_n     least-squares line over the largest morsels (n >= n_max / 8: 2^22..2^25) of the pooled
              medians: the rate a config streams at once its launch is paid off.
  overlap     pipelined GPU configs (-pipe) only: T(n) = max(alpha, b n) + k min(alpha, b n), with
              b = large_n beta. With the queue full, a morsel's launch overlaps the previous morsel's
              execution: k = 0 hides it completely (the morsel costs its launch or its streaming,
              whichever is longer), k = 1 not at all (the line alpha + b n). k by the same
              relative-error least squares as the line, clipped to [0, 1]; its errors as above. A line
              through this shape gets the slope wrong (M3 Ultra filter_count: 1235 GB/s, above the
              819 GB/s DRAM peak, against 801 over the largest morsels). The query predictors use it.
  crossovers  model vs pooled medians, as in fit.json: quote `report`, the measured one.
Register aggregation (register_agg; bench/calib_reg.cpp, ops agg_reg/C=<C>/U=<U>): per GPU configuration,
the per-row cost b_U of a group-by that loads C columns (4C B) per row, keeps U accumulators per
thread in registers and updates all of them every row, fitted across U as
b_U = max(l_C, U c) + kappa_C min(l_C, U c), with l_C = its 4C B per row at filter_count's rate in the
same configuration. c, the cost of one update, is fitted together with kappa on the fewest columns
measured, where U reaches both sides of the crossover U = l_C / c; every other column count gets its
own kappa_C with that c. kappa_C is the share of the shorter of loads and arithmetic that the longer
does not hide (0: the roofline, 1: they add). b_U and the rate are the slopes the predictors use:
large_n for pipelined configs, the line otherwise.
Contention (analysis/contention.py): per-pair medians over the contention runs, one shared-ceiling
fit (B_max, w_gpu) on them, plus each run's own fit for the spread.
Cache states (cache_states; the manifest's "cache_states" runs, calib_filter --cache, README "Cache
state: producer probe"): what a morsel costs when its input is where a producer has just left it. Per
op key, base device configuration and state (hot: no flush; cpu-write, cpu-read, gpu-write, gpu-read:
flush, then that device rewrote or read the rows; cpu-touch1, gpu-touch1: controls, one row), against
the cold rows of the same runs, a table over the morsel's footprint F = bytes_per_row x n:
  ratio           sync GPU: kernel time under the state / cold (ratio_of "kernel"); pipelined GPU and
                  CPU: morsel time / cold (ratio_of "morsel"; a pipelined morsel's kernel overlaps its
                  launch, so its time outside the kernel is not a fixed part)
  delta_us        morsel time under the state - cold
  delta_fixed_us  sync GPU: the round trip outside the kernel, state - cold (0 elsewhere)
  morsel_ratio    morsel time under the state / cold, both devices
  entry, line     the state's own calibration as a config (entry) and the slopes the predictors take
                  (line; cold_line: the cold config's, same runs)
  summary         medians of ratio and morsel_ratio by footprint band (small <= 64 KB, resident
                  256 KB..SLC/2, beyond > SLC; "slc_mb" in the manifest), the peak ratio and the
                  footprint windows where the state costs (ratio >= 1.2) or saves (<= 0.8)
  form_err        in-sample error of the predictor forms on these medians (analysis/validate.py
                  StatePred: delta, ratio, line; delta is the predictors' default), from the cold line
                  of the same runs
  crossovers      measured, per state, from same-state GPU/CPU pairs ("cold": these runs' cold rows)
The base model (ops) is built from the calibration runs only; the cache runs' cold rows are the
states' reference and agree with it (M3 Ultra filter_count: within 2-7%).
"""
import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import contention as cont  # noqa: E402
import fit  # noqa: E402
import validate as V  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

CONVENTIONS = {
    "time": "microseconds per morsel; cache-cold input (64 MB flush before every timed rep)",
    "cpu-p, cpu-e": "one worker thread on a P-core / E-core",
    "gpu-warm": "sync round trip (encode, commit, wait) on a GPU-resident buffer, GPU idle before",
    "gpu-cold": "as gpu-warm on fresh host memory wrapped no-copy right before; includes the wrap",
    "-pipe": "pipelined dispatch: GPU time per morsel with the queue kept full (span / K)",
    "-priv": "blit into a private buffer, then the kernel (resident: no blit); not a routing option",
    "-spin": "GPU kept busy (ALU-only kernel, ~20 ms) before each timed rep: the clock regime of a busy router",
    "join, sort": "groups = build rows after the filter (join) or radix passes / merged runs (sort)",
    "contention": "devices streaming together share B_max; each gets B_max * w_d * D_d / sum(w * D) "
                  "of it when their solo demands D_d exceed it (w = 1 for CPU, w_gpu for GPU)",
    "cache_states": "ops are cache-cold; cache_states gives, per base config and state of the input (what last "
                    "touched the rows), tables over the morsel's footprint that a predictor applies to the cold "
                    "prediction (analysis/validate.py StatePred: delta | ratio | line)",
}


def keep_rows(df, keep):
    if keep == "all":
        return df
    if keep not in ("sync", "sync-no-cpu-e"):
        raise SystemExit(f"unknown keep rule {keep!r}")
    if "dispatch" in df:
        df = df[~((df["device"] == "gpu") & (df["dispatch"] == "pipelined"))]
    if keep == "sync-no-cpu-e":
        df = df[~((df["device"] == "cpu") & (df["qos"] == "e"))]
    return df


def op_key(df):
    """agg_group/G=<G>, agg_reg/C=<columns per row>/U=<U>; join and sort ops carry their configuration
    in the data tag (join_probe/<join>_probe, sort/<keys>, sort_merge/<keys>_merge<k>); other ops are
    their name."""
    key = df["op"].copy()
    if "groups" in df:
        g = df["groups"].fillna(1).astype(int).astype(str)
        key = key.where(df["op"] != "agg_group", df["op"] + "/G=" + g)
    cols = (df["bytes"] / df["n"] / 4).round().astype(int).astype(str)  # calib_reg: 4 B per column
    key = key.where(df["op"] != "agg_reg", df["op"] + "/C=" + cols + "/U=" + df["thr"].astype(int).astype(str))
    per_data = df["op"].str.startswith("join_") | df["op"].str.startswith("sort")
    return key.where(~per_data, df["op"] + "/" + df["data"])


def run_medians(entries, states=False):
    """Per-run medians per (op key | config, n), tagged with the run; plus op key -> data tags, op key ->
    groups, and config -> morsels per pipelined batch. Calibration runs must be cache-cold; the
    cache-state runs (states=True) carry every state as its own config (fit.prepare: <config>-<state>)."""
    meds, tags, groups, batches = [], {}, {}, {}
    for e in entries:
        run, keep = e["run"], e.get("keep", "all")
        csvs = sorted((ROOT / "results" / run).glob("calib_*.csv"))
        if len(csvs) != 1:
            raise SystemExit(f"{run}: expected one calib_*.csv, found {len(csvs)}")
        raw = keep_rows(pd.read_csv(csvs[0]), keep)
        if not states and "cache" in raw and (raw["cache"] != "cold").any():
            raise SystemExit(f"{run}: has rows under a cache state other than cold; the model's ops are built from "
                             f"cache-cold runs only (cache-state runs go under the manifest's \"cache_states\")")
        df = fit.prepare(raw)
        df["opkey"] = op_key(df)
        if "groups" not in df and (df["op"] == "agg_reg").any():
            df["groups"] = df["thr"]  # calib_reg: thr = U, the accumulators updated per row
        for k, d in df.groupby("opkey")["data"].unique().items():
            tags.setdefault(k, set()).update(d)
        if "groups" in df:  # G (agg_group), build rows (join), radix passes or merged runs (sort)
            for k, g in df.groupby("opkey")["groups"].first().items():
                groups[k] = int(g)
        dev = df["config"].str.split("/", n=1).str[1]  # fit.py's config is <data>/<device config>
        df["config"] = df["opkey"] + "|" + dev
        if "batch" in df:
            for k, b in df[df["config"].str.contains("-pipe")].groupby("config")["batch"].median().items():
                batches[k] = int(b)
        m = fit.medians(df)
        m["run"] = run
        meds.append(m)
    return pd.concat(meds, ignore_index=True), tags, groups, batches


def fit_entry(n, t, bpe, max_err):
    a, b, med, mx = fit.fit_linear_rel(np.asarray(n, float), np.asarray(t, float))
    return {"alpha_us": a, "beta_us_per_elem": b, "beta_ns_per_row": b * 1e3, "bytes_per_elem": bpe,
            "eff_bw_GBps": bpe / (b * 1e3) if b > 0 else None,
            "median_rel_err": med, "max_rel_err": mx, "fit_ok": bool(mx <= max_err), "points": int(len(n))}


def large_line(p, bpe):
    """Least-squares line over the largest morsels (n >= n_max / 8) of the pooled medians p."""
    big = p[p.index >= p.index.max() / 8]
    if len(big) < 3:
        return None
    b, a = np.polyfit(big.index.values.astype(float), big.values.astype(float), 1)
    return {"n_range": [int(big.index.min()), int(big.index.max())], "points": int(len(big)),
            "alpha_us": float(a), "beta_us_per_elem": float(b), "eff_bw_GBps": bpe / (b * 1e3) if b > 0 else None}


def overlap_fit(a, b, p, g):
    """k of T(n) = max(a, b n) + k min(a, b n) on the pooled medians p (relative-error least squares,
    clipped to [0, 1]), and the errors of that form on p and on every (run, n) median in g."""
    n, t = p.index.values.astype(float), p.values.astype(float)
    hi, lo = np.maximum(a, b * n), np.minimum(a, b * n)
    k = float(np.clip(np.sum(lo / t * (t - hi) / t) / np.sum((lo / t) ** 2), 0.0, 1.0))

    def rel(n, t):
        return np.abs(np.maximum(a, b * n) + k * np.minimum(a, b * n) - t) / t

    fit_rel = rel(n, t)
    run_rel = rel(g["n"].values.astype(float), g["t_med"].values.astype(float))
    return {"k": k, "median_rel_err": float(np.median(fit_rel)), "max_rel_err": float(fit_rel.max()),
            "pred_err_median": float(np.median(run_rel)), "pred_err_p90": float(np.quantile(run_rel, 0.9))}


def cv(x):
    x = np.asarray(x, float)
    return float(x.std(ddof=1) / abs(x.mean())) if len(x) > 1 and x.mean() != 0 else None


def config_entry(dev, g, p, bpe, max_err):
    """The model entry of one (op key, device config): the line on the pooled medians p (per n), the
    per-run spread, the in-sample error over every (run, n) median in g, the large-morsel line and, for
    -pipe configs, the overlap form (module docstring)."""
    e = fit_entry(p.index.values, p.values, bpe, max_err)
    per_run = [fit.fit_linear_rel(r["n"].values.astype(float), r["t_med"].values.astype(float))
               for _, r in g.groupby("run")]
    pred = e["alpha_us"] + e["beta_us_per_elem"] * g["n"].values
    rel = np.abs(pred - g["t_med"].values) / g["t_med"].values
    e.update(runs=int(g["run"].nunique()), alpha_cv=cv([f[0] for f in per_run]),
             beta_cv=cv([f[1] for f in per_run]), pred_err_median=float(np.median(rel)),
             pred_err_p90=float(np.quantile(rel, 0.9)), n_range=[int(g["n"].min()), int(g["n"].max())],
             source_runs=sorted(g["run"].unique()))
    large = large_line(p, bpe)
    if large:
        e["large_n"] = large
    if large and "-pipe" in dev:
        e["overlap"] = overlap_fit(e["alpha_us"], large["beta_us_per_elem"], p, g)
    return e


def build_ops(meds, tags, groups, max_err, notes):
    ops, pooled = {}, {}
    for cfg, g in meds.groupby("config"):
        key, dev = cfg.split("|")
        p = g.groupby("n")["t_med"].median()
        pooled[(key, dev)] = p
        bpe = float((g["bytes"] / g["n"]).median())
        e = config_entry(dev, g, p, bpe, max_err)
        op = ops.setdefault(key, {"data": sorted(tags.get(key, [])), "configs": {}})
        op["configs"][dev] = e
    for key, op in ops.items():
        cfgs = op["configs"]
        op["bytes_per_row"] = float(np.median([c["bytes_per_elem"] for c in cfgs.values()]))
        op["groups"] = groups.get(key, 1)  # G, build rows, radix passes or merged runs; 1 if none
        if key in notes:
            op["note"] = notes[key]
        op["crossovers"] = {}
        for gk in sorted(k for k in cfgs if k.startswith("gpu-")):
            for ck in ("cpu-p", "cpu-e"):
                if ck not in cfgs:
                    continue
                fg, fc = cfgs[gk], cfgs[ck]
                x = fit.fitted_crossover(fg, fc)
                m = fit.measured_crossover(pooled[(key, gk)], pooled[(key, ck)])
                status, agrees = fit.judge(x, fg, fc, m, max_err)
                rn, text = fit.report(m)
                op["crossovers"][f"{gk} vs {ck}"] = {"report": text, "report_n": rn, "fitted_n": x,
                                                     "fitted_status": status, **m}
    return dict(sorted(ops.items(), key=lambda kv: (kv[0].split("/")[0], kv[1]["groups"], kv[0])))


def predictor_line(e, dev):
    """(alpha, slope, k) a predictor takes from a config entry: the large-morsel slope and overlap.k for
    -pipe configs, the line and k = 1 otherwise (validate.pipe_coef)."""
    b, k = V.pipe_coef(e, dev)
    return {"alpha_us": e["alpha_us"], "beta_us_per_elem": b, "k": k}


def band_median(x, F, lo, hi):
    sel = (F >= lo) & (F <= hi)
    return float(np.median(x[sel])) if sel.any() else None


def window(F, mask):
    return [float(F[mask].min()), float(F[mask].max())] if mask.any() else None


def state_summary(F, ratio, morsel_ratio, slc_bytes):
    """Medians by footprint band, the peak ratio and the footprint windows where the state costs or saves."""
    bands = {"small": (0, 64 * 2 ** 10), "resident": (256 * 2 ** 10, slc_bytes / 2), "beyond": (slc_bytes + 1, np.inf)}
    out = {f"ratio_{b}": band_median(ratio, F, lo, hi) for b, (lo, hi) in bands.items()}
    out.update({f"morsel_ratio_{b}": band_median(morsel_ratio, F, lo, hi) for b, (lo, hi) in bands.items()})
    i = int(np.argmax(np.abs(np.log(ratio))))
    out["peak"] = {"ratio": float(ratio[i]), "footprint_bytes": float(F[i])}
    out["cost_window_bytes"] = window(F, ratio >= 1.2)
    out["gain_window_bytes"] = window(F, ratio <= 0.8)
    return out


def form_errors(table, dev, bpe, ns, t_state):
    """In-sample relative error of each predictor form (validate.StatePred) on the state's pooled medians,
    from the cold line of the same runs."""
    cold = table["cold_line"]
    base = (cold["alpha_us"], cold["beta_us_per_elem"], cold["k"])
    out = {}
    for form in V.STATE_FORMS:
        pred = V.StatePred(base, table, form, bpe, dev)(np.asarray(ns, float))
        rel = np.abs(pred - t_state) / t_state
        out[form] = {"median_rel_err": float(np.median(rel)), "p90_rel_err": float(np.quantile(rel, 0.9)),
                     "max_rel_err": float(rel.max())}
    return out


def build_cache_states(meds, batches, max_err, slc_bytes):
    """cache_states.ops (module docstring): per op key and base device config, the cold entry of these
    runs and one table per state; crossovers per state from same-state pairs."""
    pooled = {cfg: g.groupby("n")["t_med"].median() for cfg, g in meds.groupby("config")}
    execs = {cfg: g.groupby("n")["gpu_exec_med"].median() for cfg, g in meds.groupby("config")}
    bpe_of = {cfg: float((g["bytes"] / g["n"]).median()) for cfg, g in meds.groupby("config")}
    ops = {}
    for cfg, g in meds.groupby("config"):
        key, dev = cfg.split("|")
        base, state = V.split_state(dev)
        cold_cfg = f"{key}|{base}"
        if state is None or cold_cfg not in pooled:
            continue
        op = ops.setdefault(key, {"bytes_per_row": bpe_of[cold_cfg], "configs": {}, "crossovers": {}})
        c = op["configs"].setdefault(base, {"states": {}})
        if "cold" not in c:
            gc = meds[meds["config"] == cold_cfg]
            c["cold"] = config_entry(base, gc, pooled[cold_cfg], bpe_of[cold_cfg], max_err)
        e = config_entry(dev, g, pooled[cfg], bpe_of[cfg], max_err)
        ns = sorted(set(pooled[cfg].index) & set(pooled[cold_cfg].index))
        ps, pc = pooled[cfg].loc[ns].values.astype(float), pooled[cold_cfg].loc[ns].values.astype(float)
        bpe = bpe_of[cold_cfg]
        F = bpe * np.asarray(ns, float)
        morsel_ratio, delta = ps / pc, ps - pc
        kernel_ratio = None
        if base.startswith("gpu-"):
            es, ec = execs[cfg].loc[ns].values.astype(float), execs[cold_cfg].loc[ns].values.astype(float)
            kernel_ratio = es / ec
        if base.startswith("gpu-") and "-pipe" not in base:
            ratio_of, ratio, fixed = "kernel", kernel_ratio, (ps - es) - (pc - ec)
        else:
            ratio_of, ratio, fixed = "morsel", morsel_ratio, np.zeros(len(ns))
        t = {"control": state.endswith("touch1"), "runs": int(g["run"].nunique()), "source_runs": sorted(g["run"].unique()),
             "batch": batches.get(cfg, 1), "n": [int(x) for x in ns], "footprint_bytes": F.tolist(),
             "t_cold_us": pc.tolist(), "t_state_us": ps.tolist(), "ratio_of": ratio_of, "ratio": ratio.tolist(),
             "delta_us": delta.tolist(), "delta_fixed_us": fixed.tolist(), "morsel_ratio": morsel_ratio.tolist(),
             "kernel_ratio": None if kernel_ratio is None else kernel_ratio.tolist(),
             "summary": state_summary(F, ratio, morsel_ratio, slc_bytes),
             "entry": e, "line": predictor_line(e, dev), "cold_line": predictor_line(c["cold"], base)}
        t["form_err"] = form_errors(t, dev, bpe, ns, ps)
        c["states"][state] = t
    for key, op in ops.items():
        cfgs = op["configs"]
        states = sorted({s for c in cfgs.values() for s in c["states"]})
        for s in ["cold"] + states:
            suf = "" if s == "cold" else "-" + s
            for gk in sorted(k for k in cfgs if k.startswith("gpu-")):
                for ck in ("cpu-p", "cpu-e"):
                    sg, sc = f"{key}|{gk}{suf}", f"{key}|{ck}{suf}"
                    if sg in pooled and sc in pooled:
                        m = fit.measured_crossover(pooled[sg], pooled[sc])
                        rn, text = fit.report(m)
                        op["crossovers"].setdefault(s, {})[f"{gk} vs {ck}"] = {"report": text, "report_n": rn, **m}
        for base, c in cfgs.items():
            c["states"] = dict(sorted(c["states"].items(), key=lambda kv: V.STATES.index(kv[0])))
    return dict(sorted(ops.items()))


REG_PREFIX = "agg_reg/C="


def reg_keys(ops):
    """agg_reg op keys per column count: {C: [keys sorted by U]}, C ascending."""
    by = {}
    for k in ops:
        if k.startswith(REG_PREFIX):
            by.setdefault(int(k.split("/")[1].removeprefix("C=")), []).append(k)
    return {c: sorted(ks, key=lambda k: ops[k]["groups"]) for c, ks in sorted(by.items())}


def register_agg(ops):
    """register_agg (module docstring): per GPU configuration, c and kappa of
    b_U = max(l, U c) + kappa min(l, U c) on the fewest columns measured at three or more U, then
    kappa for every other column count with that c (relative-error least squares on a grid)."""
    by = {c: ks for c, ks in reg_keys(ops).items() if len(ks) >= 3}
    if not by or "filter_count" not in ops:
        return None
    filt = ops["filter_count"]["configs"]
    c_grid = np.geomspace(1e-8, 1e-4, 4001)[:, None, None]  # us per update
    k_grid = np.linspace(0.0, 1.0, 201)[None, :, None]
    ref = min(by)  # the fewest columns: U reaches both sides of the crossover, so c and kappa separate
    devs = set.intersection(*(set(ops[k]["configs"]) for ks in by.values() for k in ks))
    out = {}
    for dev in sorted(d for d in devs if d.startswith("gpu-") and d in filt):

        def slope(e):
            return e["large_n"]["beta_us_per_elem"] if "-pipe" in dev else e["beta_us_per_elem"]

        per_byte = slope(filt[dev]) / filt[dev]["bytes_per_elem"]  # us per byte at filter_count's rate
        cols, c_upd = {}, None
        for C, keys in by.items():  # ref first
            U = np.array([ops[k]["groups"] for k in keys], float)
            b = np.array([slope(ops[k]["configs"][dev]) for k in keys])
            bpr = float(np.median([ops[k]["bytes_per_row"] for k in keys]))
            load = bpr * per_byte
            cg = c_grid if C == ref else np.array([[[c_upd]]])
            a = U[None, None, :] * cg
            sse = ((((np.maximum(load, a) + k_grid * np.minimum(load, a)) - b) / b) ** 2).sum(axis=2)
            i, j = np.unravel_index(np.argmin(sse), sse.shape)
            c_upd, kappa = float(cg[i, 0, 0]), float(k_grid[0, j, 0])
            fitted = np.maximum(load, U * c_upd) + kappa * np.minimum(load, U * c_upd)
            rel = (fitted - b) / b
            cols[str(C)] = {"kappa": kappa, "load_us_per_row": load, "bytes_per_row": bpr,
                            "crossover_U": load / c_upd,
                            "both_sides": bool((U * c_upd < load).any() and (U * c_upd > load).any()),
                            "points": [{"U": int(u), "beta_us_per_row": float(x), "fit_us_per_row": float(y),
                                        "rel_err": float(r)} for u, x, y, r in zip(U, b, fitted, rel)],
                            "max_rel_err": float(np.abs(rel).max())}
        out[dev] = {"c_us_per_update": c_upd, "c_from_cols": ref, "cols": cols}
    return {"form": "beta_U = max(l_C, U c) + kappa_C min(l_C, U c) per column count C; l_C = load_us_per_row "
                    "(4C B at filter_count's rate); c from the fewest columns (c_from_cols), fitted with its kappa; "
                    "kappa 0: loads and updates overlap completely, 1: they add. both_sides: measured on both "
                    "sides of the crossover U = l_C / c (else c and kappa_C are not separable)",
            "ops": {str(c): ks for c, ks in by.items()}, "configs": out}


def build_contention(runs):
    per = []
    for run in runs:
        s = cont.summarize(cont.load(ROOT / "results" / run / "calib_contention.csv"))
        s["run"] = run
        s["shared_cap"] = cont.fit_shared_cap(s["pairs"])
        per.append(s)
    pairs = []
    for qos, t in sorted({(p["qos"], p["threads"]) for s in per for p in s["pairs"]}):
        ps = [p for s in per for p in s["pairs"] if (p["qos"], p["threads"]) == (qos, t)]
        med = {k: float(np.median([p[k] for p in ps])) for k in
               ("cpu_solo_GBps", "gpu_solo_GBps", "cpu_GBps", "gpu_GBps", "total_GBps", "kappa_cpu", "kappa_gpu")}
        pairs.append({"qos": qos, "threads": t, **med, "runs": len(ps)})
    cap = cont.fit_shared_cap(pairs)
    cpu_solo = {}
    for s in per:
        for qos, d in s["cpu_solo_GBps"].items():
            for t, v in d.items():
                cpu_solo.setdefault(qos, {}).setdefault(t, []).append(v)
    return {
        "B_max_GBps": cap["B_max_GBps"], "w_gpu": cap["w_gpu"],
        "median_rel_err": cap["median_rel_err"], "max_rel_err": cap["max_rel_err"],
        "B_max_cv": cv([s["shared_cap"]["B_max_GBps"] for s in per]),
        "w_gpu_cv": cv([s["shared_cap"]["w_gpu"] for s in per]),
        "gpu_solo_GBps": float(np.median([s["gpu_solo_GBps"] for s in per])),
        "cpu_solo_GBps": {q: {t: float(np.median(v)) for t, v in d.items()} for q, d in cpu_solo.items()},
        "pairs": pairs, "points": cap["points"],
        "per_run": [{"run": s["run"], "B_max_GBps": s["shared_cap"]["B_max_GBps"], "w_gpu": s["shared_cap"]["w_gpu"],
                     "max_rel_err": s["shared_cap"]["max_rel_err"], "gpu_drift": s["gpu_drift"]} for s in per],
    }


def pct(x):
    return "-" if x is None else f"{x:.1%}"


def print_summary(model):
    out = sys.stderr
    print(f"{model['machine']}: model from {len(model['sources']['calibration'])} calibration runs, "
          f"{len(model['sources']['contention'])} contention runs", file=out)
    for key, op in model["ops"].items():
        print(f"\n{key}  ({op['bytes_per_row']:.0f} B/row{'; ' + op['note'] if 'note' in op else ''})", file=out)
        print(f"  {'config':20s} {'alpha us':>9s} {'ns/row':>7s} {'GB/s':>6s} {'large':>6s} {'runs':>4s} {'a_cv':>6s}"
              f" {'b_cv':>6s} {'err med':>7s} {'p90':>6s}  fit   (large: GB/s over the largest morsels)", file=out)
        for dev, c in op["configs"].items():
            bw = f"{c['eff_bw_GBps']:.1f}" if c["eff_bw_GBps"] else "-"
            lbw = f"{c['large_n']['eff_bw_GBps']:.1f}" if c.get("large_n", {}).get("eff_bw_GBps") else "-"
            print(f"  {dev:20s} {c['alpha_us']:9.1f} {c['beta_ns_per_row']:7.3f} {bw:>6s} {lbw:>6s} {c['runs']:4d}"
                  f" {pct(c['alpha_cv']):>6s} {pct(c['beta_cv']):>6s} {pct(c['pred_err_median']):>7s}"
                  f" {pct(c['pred_err_p90']):>6s}  {'ok' if c['fit_ok'] else 'POOR (max ' + pct(c['max_rel_err']) + ')'}",
                  file=out)
            if "overlap" in c:
                m = c["overlap"]
                print(f"  {'':20s} overlap k {m['k']:.2f} (large-morsel slope): err med {pct(m['pred_err_median'])},"
                      f" p90 {pct(m['pred_err_p90'])}, max {pct(m['max_rel_err'])} on the pooled medians", file=out)
        for pair, x in op["crossovers"].items():
            if "-priv" not in pair:
                print(f"  {pair:28s} {x['report']}", file=out)
    if "register_agg" in model:
        ra = model["register_agg"]
        print(f"\nregister_agg ({', '.join(k for ks in ra['ops'].values() for k in ks)}): {ra['form']}", file=out)
        for dev, r in ra["configs"].items():
            print(f"  {dev:20s} c {r['c_us_per_update'] * 1e6:.3f} ps/update (from C={r['c_from_cols']})", file=out)
            for C, e in r["cols"].items():
                pts = "  ".join(f"U={p['U']}: {p['beta_us_per_row'] * 1e6:.1f}/{p['fit_us_per_row'] * 1e6:.1f}"
                                for p in e["points"])
                print(f"    C={C} ({e['bytes_per_row']:.0f} B/row): kappa {e['kappa']:.2f}, l {e['load_us_per_row'] * 1e6:.1f}"
                      f" ps/row, crossover U {e['crossover_U']:.1f}{'' if e['both_sides'] else ' (one side only)'},"
                      f" max err {pct(e['max_rel_err'])}", file=out)
                print(f"      ps/row measured/fit: {pts}", file=out)
    if "cache_states" in model:
        cs = model["cache_states"]
        print(f"\ncache states ({len(cs['sources'])} runs; SLC {cs['slc_mb']} MB): ratio = state / cold (sync GPU: kernel "
              f"time; pipelined GPU, CPU: morsel time), median by footprint band (small <= 64 KB, resident 256 KB..SLC/2, beyond > SLC); "
              f"morsel: morsel time ratio, resident band; peak ratio at its footprint; the state's own line; in-sample "
              f"error (median) of the predictor forms ratio / delta / line", file=out)
        for key, op in cs["ops"].items():
            print(f"\n{key}  ({op['bytes_per_row']:.0f} B/row)", file=out)
            print(f"  {'config':20s} {'state':11s} {'small':>6s} {'resid':>6s} {'beyond':>6s} {'morsel':>6s} "
                  f"{'peak @ footprint':>18s} {'line GB/s':>9s} {'ratio':>6s} {'delta':>6s} {'line':>6s}", file=out)

            def f(x):
                return "-" if x is None else f"{x:6.2f}"

            def mb(b):
                return f"{b / 2 ** 20:g} MB" if b >= 2 ** 20 else f"{b / 2 ** 10:g} KB"

            for base, c in op["configs"].items():
                cl = c["cold"]
                print(f"  {base:20s} {'cold':11s} {'':6s} {'':6s} {'':6s} {'':6s} {'':18s} "
                      f"{op['bytes_per_row'] / (predictor_line(cl, base)['beta_us_per_elem'] * 1e3):9.0f}", file=out)
                for s, t in c["states"].items():
                    sm, fe = t["summary"], t["form_err"]
                    bw = op["bytes_per_row"] / (t["line"]["beta_us_per_elem"] * 1e3)
                    print(f"  {'':20s} {s:11s} {f(sm['ratio_small'])} {f(sm['ratio_resident'])} {f(sm['ratio_beyond'])} "
                          f"{f(sm['morsel_ratio_resident'])} {sm['peak']['ratio']:6.2f} @ {mb(sm['peak']['footprint_bytes']):>9s}"
                          f" {bw:9.0f} {pct(fe['ratio']['median_rel_err']):>6s} {pct(fe['delta']['median_rel_err']):>6s}"
                          f" {pct(fe['line']['median_rel_err']):>6s}", file=out)
            for s, pairs in op["crossovers"].items():
                for pair, x in pairs.items():
                    print(f"  {s:11s} {pair:30s} {x['report']}", file=out)
    c = model["contention"]
    print(f"\ncontention: B_max {c['B_max_GBps']:.1f} GB/s (cv {pct(c['B_max_cv'])}), w_gpu {c['w_gpu']:.2f}"
          f" (cv {pct(c['w_gpu_cv'])}), |error| median {pct(c['median_rel_err'])}, max {pct(c['max_rel_err'])}",
          file=out)
    pred = {(p["qos"], p["threads"]): p for p in c["points"]}
    for p in c["pairs"]:
        m = pred[(p["qos"], p["threads"])]
        print(f"  {p['qos']}{p['threads']} + GPU: CPU {p['cpu_GBps']:5.1f} (model {m['cpu_pred_GBps']:5.1f}, alone"
              f" {p['cpu_solo_GBps']:5.1f})  GPU {p['gpu_GBps']:5.1f} (model {m['gpu_pred_GBps']:5.1f}, alone"
              f" {p['gpu_solo_GBps']:5.1f})  total {p['total_GBps']:5.1f}", file=out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default=str(ROOT / "analysis" / "model_runs.json"))
    ap.add_argument("--machine", help="build only this machine's model (default: every machine in the manifest)")
    ap.add_argument("--max-err", type=float, default=0.2)
    args = ap.parse_args()
    manifest = json.loads(Path(args.manifest).read_text())
    machines = [args.machine] if args.machine else [k for k in manifest if not k.startswith("_")]
    for machine in machines:
        spec = manifest[machine]
        meds, tags, groups, _ = run_medians(spec["calibration"])
        found = set(meds["machine"].unique())
        if found != {machine}:
            raise SystemExit(f"{machine}: runs report machine {sorted(found)}")
        model = {
            "machine": machine,
            "built": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "form": "T(n) = alpha_us + beta_us_per_elem * n, per op key and device configuration; pipelined GPU "
                    "configs (-pipe): T(n) = max(alpha_us, b n) + k min(alpha_us, b n) with b = "
                    "large_n.beta_us_per_elem and k = overlap.k (k = 1: the line alpha_us + b n); register_agg: the "
                    "GPU's cost per register-accumulator update (its own form)",
            "conventions": CONVENTIONS,
            "sources": {"calibration": spec["calibration"], "contention": spec["contention"],
                        "cache_states": spec.get("cache_states", [])},
            "ops": build_ops(meds, tags, groups, args.max_err, spec.get("op_notes", {})),
            "contention": build_contention(spec["contention"]),
        }
        reg = register_agg(model["ops"])
        if reg:
            model["register_agg"] = reg
        if spec.get("cache_states"):
            if "slc_mb" not in spec:
                raise SystemExit(f"{machine}: cache_states runs need \"slc_mb\" (the system level cache size) in the manifest")
            cmeds, _, _, batches = run_medians(spec["cache_states"], states=True)
            if set(cmeds["machine"].unique()) != {machine}:
                raise SystemExit(f"{machine}: cache-state runs report machine {sorted(cmeds['machine'].unique())}")
            model["cache_states"] = {
                "form": "per op key, base device config and state of the input (what last touched the rows), against the "
                        "cold rows of the same runs: tables over the morsel's footprint F = bytes_per_row x n (per morsel; "
                        "pipelined states measured at `batch` morsels per batch) of ratio (sync GPU: kernel time state / cold, "
                        "ratio_of kernel; pipelined GPU and CPU: morsel time, ratio_of morsel), delta_us, delta_fixed_us (sync "
                        "GPU: the round trip outside the kernel) and morsel_ratio (kernel_ratio too on the GPU); "
                        "the state's own calibration (entry; line and cold_line: the slopes the predictors take) and the "
                        "in-sample error of the predictor forms (form_err; analysis/validate.py StatePred). A predictor "
                        "applies a state to the cold prediction of the base config: delta (+ delta_us(F); the default, the form "
                        "that transferred to the held-out queries), ratio (streaming term x ratio(F), fixed part + "
                        "delta_fixed_us(F)) or line, interpolated in log F and clamped",
                "slc_mb": spec["slc_mb"], "sources": spec["cache_states"],
                "ops": build_cache_states(cmeds, batches, args.max_err, spec["slc_mb"] * 2 ** 20),
            }
        path = ROOT / "models" / f"{machine}.json"
        path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps(model, indent=2))
        print_summary(model)
        print(f"\n-> {path.relative_to(ROOT)}", file=sys.stderr)


if __name__ == "__main__":
    main()
