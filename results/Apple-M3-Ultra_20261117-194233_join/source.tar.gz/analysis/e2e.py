#!/usr/bin/env python3
"""Summary of an end-to-end run set (scripts/run_e2e.sh; bench/run_query.cpp): per query and morsel size,
the measured wall time of every policy (median and min over reps), the plan's prediction, the morsels
each device class took and when each finished, and each policy's time relative to the best static
placement (gpu or cpu alone). Q14: one row per policy and build device (run_e2e.sh runs split, dynamic
and router with both), the build phase and the probe morsels apart; with --duckdb, the DuckDB CPU-only baseline (scripts/duckdb_baseline.py)
on the same rows.

usage: python3 analysis/e2e.py results/<run>_e2e/run_query.csv [--duckdb results/<run>_e2e/duckdb.csv]
Writes e2e.json next to the CSV.
"""
import argparse
import json
import math
from pathlib import Path

import pandas as pd

POLICIES = ["gpu", "cpu", "cpu-router", "split", "dynamic", "router"]


def plan_build_device(csv, q, n):
    """The build device the plan chose (q14; plan_<query>_<log2>.json next to the CSV), or None."""
    p = Path(csv).with_name(f"plan_{q}_{int(math.log2(n))}.json")
    if not p.exists():
        return None
    return json.loads(p.read_text()).get("build", {}).get("device")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--duckdb")
    args = ap.parse_args()
    df = pd.read_csv(args.csv)
    if "build_device" not in df.columns:  # runs before Q14 (no build phase)
        df["build_device"], df["build_ms"] = "-", 0.0
    df["build_device"] = df["build_device"].fillna("-").astype(str)
    duck = pd.read_csv(args.duckdb) if args.duckdb else None
    out = {"csv": args.csv, "queries": {}}
    for q, dq in df.groupby("op", sort=False):
        has_build = (dq["build_device"] != "-").any()
        print(f"\n== {q} ({dq['machine'].iloc[0]}, {dq['morsels'].iloc[0] * dq['n'].iloc[0] // 2**20:d} Mi rows; "
              f"{int(dq['p_workers'].max())} P + {int(dq['e_workers'].max())} E workers, {int(dq['inflight'].max())} in flight)")
        if duck is not None and (duck["op"] == q).any():
            d = duck[duck["op"] == q].iloc[0]
            print(f"   DuckDB {d['duckdb']} CPU-only, {d['threads']} threads: {d['t_ms_median']:.1f} ms median (min {d['t_ms_min']:.1f})")
            out["queries"].setdefault(q, {})["duckdb_ms"] = float(d["t_ms_median"])
        if has_build:
            print("   build: the device of the build phase (* the plan's choice for split, dynamic, router); "
                  "build and probe ms: medians of the two phases")
        print(f"   {'n':>6s} {'policy':10s} {'build':>5s} {'ms med':>8s} {'min':>8s} {'pred':>8s} "
              + (f"{'build':>7s} {'probe':>7s} " if has_build else "")
              + f"{'vs best static':>14s} {'GPU/P/E morsels':>18s} {'finished GPU/P/E ms':>22s}")
        for n, dn in dq.groupby("n"):
            chosen = plan_build_device(args.csv, q, n) if has_build else None
            rows = {}
            for pol in POLICIES:
                for b, g in dn[dn["policy"] == pol].groupby("build_device", sort=False):
                    key = pol if b == "-" else f"{pol} {b}-build"
                    rows[key] = {"policy": pol, "build_device": b, "plan_build": b == chosen if chosen else None,
                                 "ms_median": float(g["t_ms"].median()), "ms_min": float(g["t_ms"].min()),
                                 "pred_ms": float(g["pred_ms"].iloc[0]), "reps": int(len(g)), "ok": bool(g["ok"].all()),
                                 "build_ms": float(g["build_ms"].median()), "probe_ms": float((g["t_ms"] - g["build_ms"]).median()),
                                 "morsels": [float(g["gpu_morsels"].median()), float(g["p_morsels"].median()), float(g["e_morsels"].median())],
                                 "finished_ms": [float(g["gpu_finished_ms"].median()), float(g["p_finished_ms"].median()),
                                                 float(g["e_finished_ms"].median())],
                                 "gpu_share": float(g["gpu_share"].iloc[0]) if pol == "split" else None}
            statics = [r["ms_median"] for r in rows.values() if r["policy"] in ("gpu", "cpu")]
            static = min(statics) if statics else None
            for key, r in rows.items():
                r["vs_best_static"] = r["ms_median"] / static if static else None
                m, f = r["morsels"], r["finished_ms"]
                vs = f"{r['vs_best_static']:14.2f}" if r["vs_best_static"] else f"{'-':>14s}"
                b = r["build_device"] + ("*" if r["plan_build"] and r["policy"] in ("split", "dynamic", "router") else "")
                phases = f"{r['build_ms']:7.3f} {r['probe_ms']:7.3f} " if has_build else ""
                print(f"   2^{int(math.log2(n)):<4d} {r['policy']:10s} {b:>5s} {r['ms_median']:8.2f} {r['ms_min']:8.2f} {r['pred_ms']:8.2f} "
                      f"{phases}{vs} {int(m[0]):>6d}/{int(m[1]):>4d}/{int(m[2]):>4d}    {f[0]:6.2f}/{f[1]:6.2f}/{f[2]:6.2f}"
                      f"{'' if r['ok'] else '  MISMATCH'}")
            out["queries"].setdefault(q, {})[str(n)] = rows
    path = Path(args.csv).with_name("e2e.json")
    path.write_text(json.dumps(out, indent=2))
    print(f"\n-> {path}")


if __name__ == "__main__":
    main()
