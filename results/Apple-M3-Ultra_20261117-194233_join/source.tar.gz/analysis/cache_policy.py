#!/usr/bin/env python3
"""Stage 4 of the cache plan (PLAN.md): what a router gains from knowing the cache state of a morsel's
input, i.e. who touched it last. From runs made under several --cache states (the filter probe,
val_q6, val_q1) and models/<machine>.json:

  matrix          per state s, device config d and morsel size n: the pooled median time M[s][d][n]
  oracle          per (s, n) the device measured fastest under that state (the cache-aware optimum)
  routers         per (s, n) the device each router picks, and what it costs under s:
    measured-cold   the device fastest under cold in the measured matrix (the best any cold-calibrated
                    router can do): cache-oblivious
    model-none      the model's cold prediction (--state-form none): today's router, cache-oblivious
    model-<form>    the model's prediction with the state applied (delta by default): cache-aware
  scores          per router, state and candidate set (validate.ROUTERS: sync and pipelined, in the
                  clock regime of the runs): placement accuracy against the oracle over the sizes,
                  the loss M[s][pick][n] / M[s][oracle][n] (mean and max over n, with the sizes where
                  the pick is not the oracle's), and the measured GPU/CPU crossovers per state.
The query's prediction per device config is the predictor's (predict_q6 rule stream, predict_q1 rule
register, the filter from filter_count), as in analysis/validate.py.

usage: python3 analysis/cache_policy.py results/<run>_q6cache/val_q6.csv [...] [--model models/<machine>.json]
                                       [--state-form delta] [--plot results/<run>/routing_map.pdf]
Writes cache_policy[_<form>].json next to the first CSV.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fit  # noqa: E402
import validate as V  # noqa: E402

ROOT = V.ROOT


def query_of(csv):
    op = pd.read_csv(csv, nrows=1)["op"].iloc[0]
    return {"q6": "q6", "q1": "q1", "filter_count": "filter"}[op]


def predictions(query, model, devs, form):
    """pred[dev] for every device config in devs (cold ones and <base>-<state> ones)."""
    out = {}
    if query == "q6":
        import predict_q6 as P
        bpr = P.BYTES_PER_ROW
    elif query == "q1":
        import predict_q1 as P
        bpr = P.BYTES_PER_ROW
    else:
        P, bpr = None, 4
    for d in devs:
        base, _ = V.split_state(d)
        if query == "filter":
            f, _ = V.pick(model, "filter_count", base)
            b, k = V.pipe_coef(f, base)
            p = (f["alpha_us"], b, k)
        else:
            c = P.coefficients(model, base)
            if query == "q6":
                p = (c["alpha_us"], c["beta"]["stream"], c["k"])
            elif "register" in c:  # Q1 on the GPU: agg_reg's launch terms
                p = (c["register"]["alpha_us"], c["beta"][P.REG_RULE], c["register"]["k"])
            else:
                p = (c["alpha_us"], c["beta"][P.REG_RULE], c["k"])
        out[d] = V.with_state(p, model, d, bpr, form)
    return out


def l2(x):
    return f"2^{math.log2(x):.1f}" if x else "none"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--model", default=str(ROOT / "models" / "Apple-M3-Ultra.json"))
    ap.add_argument("--state-form", choices=V.STATE_FORMS, default="delta")
    ap.add_argument("--plot", help="write the routing map (pdf/png): per router and state, the device measured fastest per size")
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    query = query_of(args.csv[0])
    meds = V.load_runs(args.csv)
    devs = V.select_devices(meds["config"])
    meds = meds[meds["config"].isin(devs)]
    pooled = meds.groupby(["config", "n"])["t_med"].median()
    states = ["cold"] + sorted({s for d in devs for s in [V.split_state(d)[1]] if s}, key=V.STATES.index)
    pred = {f: predictions(query, model, devs, f) for f in ["none", args.state_form]}
    err = sys.stderr
    print(f"{query}: runs {', '.join(sorted(meds['run'].unique()))}\nmodel {args.model}; aware form {args.state_form}", file=err)

    def cfg(base, s):
        return base if s == "cold" else f"{base}-{s}"

    out = {"query": query, "model": args.model, "state_form": args.state_form, "runs": sorted(meds["run"].unique()),
           "routers": {}}
    routers = {name: cand for name, cand in V.ROUTERS.items() if all(c in devs for c in cand)}
    for name, cand in routers.items():
        res = {}
        print(f"\n== router {name}: candidates {', '.join(cand)}", file=err)
        print(f"  {'state':10s} {'router':16s} {'accuracy':>8s} {'mean loss':>9s} {'max loss':>8s} {'at':>7s}  sizes where the pick is not the oracle's",
              file=err)
        for s in states:
            if not all(cfg(c, s) in pooled.index.get_level_values(0) for c in cand):
                continue
            ns = sorted(set.intersection(*(set(pooled[cfg(c, s)].index) for c in cand)))
            M = {c: np.array([pooled[cfg(c, s)][n] for n in ns]) for c in cand}
            Mcold = {c: np.array([pooled[c][n] for n in ns]) for c in cand}
            stack = np.stack([M[c] for c in cand])
            oracle = np.argmin(stack, axis=0)
            t_oracle = stack[oracle, np.arange(len(ns))]
            nsf = np.array(ns, float)
            picks = {
                "measured-cold": np.argmin(np.stack([Mcold[c] for c in cand]), axis=0),
                "model-none": np.argmin(np.stack([V.evaluate(pred["none"][cfg(c, s)], nsf) for c in cand]), axis=0),
                f"model-{args.state_form}": np.argmin(np.stack([V.evaluate(pred[args.state_form][cfg(c, s)], nsf) for c in cand]), axis=0),
            }
            row = {"n": ns, "oracle": [cand[i] for i in oracle], "t_oracle_us": t_oracle.tolist(), "routers": {}}
            for r, pick in picks.items():
                loss = stack[pick, np.arange(len(ns))] / t_oracle
                wrong = [ns[i] for i in range(len(ns)) if pick[i] != oracle[i]]
                worst = int(np.argmax(loss))
                row["routers"][r] = {"pick": [cand[i] for i in pick], "loss": loss.tolist(),
                                     "accuracy": float(np.mean(pick == oracle)), "mean_loss": float(loss.mean()),
                                     "max_loss": float(loss.max()), "max_loss_n": int(ns[worst]), "wrong_n": wrong}
                span = f"{l2(wrong[0])}..{l2(wrong[-1])}" if wrong else "-"
                print(f"  {s:10s} {r:16s} {np.mean(pick == oracle):8.0%} {loss.mean():9.2f} {loss.max():8.2f} {l2(ns[worst]):>7s}  {span}"
                      f"{'' if not wrong else ' (' + str(len(wrong)) + ')'}", file=err)
            # measured crossovers under this state
            row["crossovers"] = {}
            for g in [c for c in cand if c.startswith("gpu")]:
                for c in [c for c in cand if c.startswith("cpu")]:
                    m = fit.measured_crossover(pooled[cfg(g, s)], pooled[cfg(c, s)])
                    _, text = fit.report(m)
                    row["crossovers"][f"{g} vs {c}"] = {"report": text, "n": m["measured_interp_n"]}
            res[s] = row
        for s, row in res.items():
            print(f"  {s:10s} measured crossovers: " + "; ".join(f"{k.split(' vs ')[1]}: {l2(v['n'])}" for k, v in row["crossovers"].items()), file=err)
        out["routers"][name] = res

    if args.plot:
        plot(out, args.plot)
        print(f"routing map -> {args.plot}", file=err)
    path = Path(args.csv[0]).with_name(f"cache_policy{'' if args.state_form == 'delta' else '_' + args.state_form}.json")
    path.write_text(json.dumps(out, indent=2, default=float))
    print(f"-> {path}", file=err)


def plot(out, path):
    """Per router: one strip per state showing the device measured fastest per size (the oracle), with the
    picks of the cache-oblivious cold router marked where they differ."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    routers = out["routers"]
    fig, axes = plt.subplots(len(routers), 1, figsize=(9, 1.2 + 1.6 * len(routers)), squeeze=False)
    colors = {"cpu-p": "#d62728", "cpu-e": "#ff7f0e", "gpu": "#1f77b4"}
    for ax, (name, res) in zip(axes[:, 0], routers.items()):
        states = list(res)
        for y, s in enumerate(states):
            row = res[s]
            ns = row["n"]
            for i, (n, d) in enumerate(zip(ns, row["oracle"])):
                key = "gpu" if d.startswith("gpu") else d
                ax.barh(y, 1, left=i, color=colors[key], edgecolor="white", height=0.8)
            for i, (n, d) in enumerate(zip(ns, row["routers"]["measured-cold"]["pick"])):
                if d != row["oracle"][i]:
                    ax.text(i + 0.5, y, "x", ha="center", va="center", fontsize=8, color="white", fontweight="bold")
        ax.set_yticks(range(len(states)))
        ax.set_yticklabels(states)
        ax.set_xticks([i + 0.5 for i in range(len(ns))])
        ax.set_xticklabels([f"2^{int(math.log2(n))}" for n in ns], fontsize=7)
        ax.set_xlim(0, len(ns))
        ax.set_title(f"{out['query']}: device measured fastest per state and morsel size ({name} router; "
                     f"x: the cold-calibrated pick differs)", fontsize=9)
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in colors.values()]
    axes[0, 0].legend(handles, list(colors), loc="upper left", bbox_to_anchor=(1.0, 1.0), fontsize=8)
    fig.tight_layout()
    fig.savefig(path)


if __name__ == "__main__":
    main()
