#!/usr/bin/env python3
"""Held-out sort validation (PLAN.md): the radix sort's per-pass cost, fitted on the key columns in
--fit (uniform random keys, 4 passes, and l_partkey, 3), predicts the other key columns from their
pass count alone (l_shipdate: 2 passes; l_orderkey: 4, and already sorted). Per device configuration:
  --alpha pass  (default)  T(n, p) = alpha0 + p * alpha_pass + p * b * n
  --alpha fixed            T(n, p) = alpha + p * b * n   (the first form: one fixed cost for every pass count)
by relative least squares over the fit columns' pooled medians (calib_sort runs; the passes come from the
CSV's groups column). alpha_pass is the launch cost of one pass: on the GPU each pass is three dependent
dispatches (histogram, scan, scatter) in the one command buffer, so the fixed cost grows with the passes;
the two fit columns have different pass counts, so alpha0 and alpha_pass are both determined. A pass
cannot cost negative time: where the free fit gives alpha_pass < 0 (the CPU, whose pass has no launch;
noisy GPU intercepts) the device gets the fixed form. The pass term was added after the first form's
held-out test (its GPU error on l_shipdate came from alpha); it is fitted on the same fit columns. Scored on the test columns as the query predictors are: error per
(run, n) median, the measured line's slope against the predicted p * b, and the measured against the
predicted GPU/CPU crossovers.

usage: python3 analysis/predict_sort.py results/<run>_sort/calib_sort.csv [...] [--fit random,l_partkey] [--test l_shipdate,l_orderkey]
                                       [--alpha pass|fixed]
Writes predict_sort.json (predict_sort_alpha_fixed.json with --alpha fixed) next to the first CSV.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fit  # noqa: E402

DEVS = ["gpu-warm-spin", "gpu-cold-spin", "cpu-p", "cpu-e"]


def l2(x):
    return f"2^{math.log2(x):.1f}" if x else "none"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--fit", default="random,l_partkey")
    ap.add_argument("--test", default="l_shipdate,l_orderkey")
    ap.add_argument("--alpha", choices=["pass", "fixed"], default="pass",
                    help="pass: alpha0 + p * alpha_pass; fixed: one alpha for every pass count (the first form)")
    args = ap.parse_args()
    fit_keys, test_keys = args.fit.split(","), args.test.split(",")
    meds, passes = [], {}
    for p in args.csv:
        raw = pd.read_csv(p)
        raw = raw[(raw["op"] == "sort") & raw["data"].isin(fit_keys + test_keys)]
        for k, g in raw.groupby("data")["groups"].first().items():
            passes[k] = int(g)
        df = fit.prepare(raw)
        m = fit.medians(df)
        m["run"] = Path(p).parent.name
        meds.append(m)
    meds = pd.concat(meds, ignore_index=True)
    meds["key"] = meds["config"].str.split("/", n=1).str[0]
    meds["dev"] = meds["config"].str.split("/", n=1).str[1]
    pooled = meds.groupby(["key", "dev", "n"])["t_med"].median()
    err = sys.stderr
    print(f"runs: {', '.join(sorted(meds['run'].unique()))}\nfit on {fit_keys} (passes {[passes[k] for k in fit_keys]}), "
          f"test {test_keys} (passes {[passes[k] for k in test_keys]})\n", file=err)
    out = {"runs": sorted(meds["run"].unique()), "fit": fit_keys, "test": test_keys, "passes": passes, "alpha_form": args.alpha,
           "devices": {}, "crossovers": {}}
    print(f"alpha form: {args.alpha}\n{'device':16s} {'alpha0 us':>9s} {'us/pass':>7s} {'b ns/row/pass':>13s}   " +
          "  ".join(f"{k + ' pred/meas ns/row':>30s} {'err med':>7s} {'p90':>6s}" for k in test_keys), file=err)
    pred_lines = {}
    for d in DEVS:
        pts = [(k, pooled.loc[(k, d)]) for k in fit_keys if (k, d) in pooled.index.droplevel(2)]
        if len(pts) < len(fit_keys):
            continue
        t = np.concatenate([s.values.astype(float) for _, s in pts])
        pp = np.concatenate([np.full(len(s), passes[k], float) for k, s in pts])
        pn = np.concatenate([np.full(len(s), passes[k], float) * s.index.values for k, s in pts])
        ap_, clipped = 0.0, False
        if args.alpha == "pass":
            if len({passes[k] for k in fit_keys}) < 2:
                raise SystemExit("--alpha pass needs fit columns with at least two pass counts")
            A = np.stack([np.ones_like(t), pp, pn], axis=1) / t[:, None]
            (a0, ap_, b), *_ = np.linalg.lstsq(A, np.ones_like(t), rcond=None)
            # A pass cannot cost negative time: alpha_pass >= 0. The problem is convex, so if the free fit
            # gives alpha_pass < 0 the constrained optimum is alpha_pass = 0, i.e. the fixed form.
            clipped = bool(ap_ < 0)
        if args.alpha == "fixed" or clipped:
            A = np.stack([np.ones_like(t), pn], axis=1) / t[:, None]
            (a0, b), *_ = np.linalg.lstsq(A, np.ones_like(t), rcond=None)
            ap_ = 0.0
        res = {"alpha0_us": float(a0), "alpha_per_pass_us": float(ap_), "alpha_pass_clipped": clipped,
               "b_us_per_row_per_pass": float(b), "test": {}}
        cells = []
        for k in test_keys:
            if (k, d) not in pooled.index.droplevel(2):
                cells.append(" " * 46)
                continue
            p = passes[k]
            a = a0 + p * ap_
            g = meds[(meds["key"] == k) & (meds["dev"] == d)]
            pred = a + p * b * g["n"].values.astype(float)
            rel = np.abs(pred - g["t_med"].values) / g["t_med"].values
            s = pooled.loc[(k, d)]
            am, bm, _, _ = fit.fit_linear_rel(s.index.values.astype(float), s.values.astype(float))
            res["test"][k] = {"passes": p, "pred_beta_ns_per_row": p * b * 1e3, "meas_beta_ns_per_row": bm * 1e3,
                              "pred_alpha_us": float(a), "meas_alpha_us": am,
                              "err_median": float(np.median(rel)), "err_p90": float(np.quantile(rel, 0.9)),
                              "bias_median": float(np.median((pred - g["t_med"].values) / g["t_med"].values))}
            pred_lines[(k, d)] = (a, p * b)
            cells.append(f"{p * b * 1e3:14.3f} / {bm * 1e3:<13.3f} {np.median(rel):7.1%} {np.quantile(rel, 0.9):6.1%}")
        out["devices"][d] = res
        print(f"{d:16s} {a0:9.1f} {ap_:7.1f}{'*' if clipped else ' '}{b * 1e3:12.4f}   " + "  ".join(cells), file=err)
        if clipped:
            print(f"{'':16s} * the free fit gave alpha_pass < 0: one alpha for every pass count", file=err)
    print("\ncrossovers (GPU faster from), measured vs predicted:", file=err)
    for k in test_keys:
        for g in ["gpu-warm-spin"]:
            for c in ["cpu-p", "cpu-e"]:
                if (k, g) not in pred_lines or (k, c) not in pred_lines:
                    continue
                m = fit.measured_crossover(pooled.loc[(k, g)], pooled.loc[(k, c)])
                _, text = fit.report(m)
                ga, gb = pred_lines[(k, g)]
                ca, cb = pred_lines[(k, c)]
                x = (ga - ca) / (cb - gb) if cb > gb else None
                out["crossovers"][f"{k}: {g} vs {c}"] = {"measured": text, "measured_n": m["measured_interp_n"], "predicted_n": x}
                print(f"  {k:11s} {g} vs {c}: measured {text}; predicted {l2(x)}", file=err)
    path = Path(args.csv[0]).with_name("predict_sort.json" if args.alpha == "pass" else "predict_sort_alpha_fixed.json")
    path.write_text(json.dumps(out, indent=2, default=float))
    print(f"\n-> {path}", file=err)


if __name__ == "__main__":
    main()
