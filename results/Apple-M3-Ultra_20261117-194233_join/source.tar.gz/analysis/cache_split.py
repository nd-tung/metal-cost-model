"""Kernel-time split of the cache-state probe: per GPU config and size, cold gpu_exec (us, GB/s) and the CPU-side
remainder t_us - gpu_exec (us); per policy the ratio gpu_exec(policy)/gpu_exec(cold) and the remainder's delta (us).
Medians per run, then the median over runs.  usage: cache_split.py <calib_filter.csv>..."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import fit
POLICIES = ["hot", "cpu-write", "cpu-read", "gpu-write", "gpu-read", "cpu-touch1", "gpu-touch1"]
rows = []
for p in sys.argv[1:]:
    df = fit.prepare(pd.read_csv(p))
    df["config"] = df["config"].str.split("/", n=1).str[1]
    df = df[df["device"] == "gpu"].copy()
    df["rem"] = df["t_us"] - df["gpu_exec_us"]
    g = df.groupby(["config", "n"]).agg(exec_med=("gpu_exec_us", "median"), rem_med=("rem", "median"),
                                        t_med=("t_us", "median")).reset_index()
    g["run"] = Path(p).parent.name
    rows.append(g)
m = pd.concat(rows, ignore_index=True)
for d in ["gpu-warm-spin", "gpu-warm-pipe-spin"]:
    present = [p for p in POLICIES if (m["config"] == f"{d}-{p}").any()]
    print(f"\n== {d}: kernel time (gpu_exec): cold us and GB/s, then gpu_exec(policy)/gpu_exec(cold) [min..max over runs]")
    print(f"{'n':>6s} {'cold us':>8s} {'GB/s':>6s} " + " ".join(f"{p:>20s}" for p in present))
    ns = sorted(m[m["config"] == d]["n"].unique())
    for n in ns:
        cold = m[(m["config"] == d) & (m["n"] == n)].set_index("run")
        cells = []
        for p in present:
            pol = m[(m["config"] == f"{d}-{p}") & (m["n"] == n)].set_index("run")
            r = (pol["exec_med"] / cold["exec_med"]).dropna()
            cells.append(f"{r.median():5.2f} [{r.min():4.2f}..{r.max():4.2f}]" if len(r) else " " * 20)
        ce = cold["exec_med"].median()
        print(f"2^{int(np.log2(n)):<4d} {ce:8.1f} {4 * n / ce / 1e3:6.0f} " + " ".join(cells))
    print(f"\n== {d}: CPU-side remainder t - gpu_exec: cold us, then remainder(policy) - remainder(cold) in us [min..max]")
    print(f"{'n':>6s} {'cold us':>8s} " + " ".join(f"{p:>20s}" for p in present))
    for n in ns:
        cold = m[(m["config"] == d) & (m["n"] == n)].set_index("run")
        cells = []
        for p in present:
            pol = m[(m["config"] == f"{d}-{p}") & (m["n"] == n)].set_index("run")
            dlt = (pol["rem_med"] - cold["rem_med"]).dropna()
            cells.append(f"{dlt.median():+6.1f} [{dlt.min():+5.1f}..{dlt.max():+5.1f}]" if len(dlt) else " " * 20)
        print(f"2^{int(np.log2(n)):<4d} {cold['rem_med'].median():8.1f} " + " ".join(cells))
