#!/usr/bin/env python3
"""The router's plan for one end-to-end run (bench/run_query.cpp): from models/<machine>.json, the
predicted time per morsel of n rows on the pipelined GPU, one P worker and one E worker (the query
predictors' coefficients: predict_q6 rule stream, predict_q1 rule register, predict_q14 rule gathers;
busy-GPU calibration), then the contention model: the CPU workers together stream at most what the contention calibration
measured for that many threads alone (cpu_solo_GBps; on the M3 Ultra 24 P threads reach 256 GB/s,
not the per-thread rate times 24), and the GPU and the CPU together share the ceiling B_max with
the GPU's weight w_gpu (when their demands add up to more, each gets B_max * w_d D_d / sum(w D)).
That gives the per-morsel times under contention (--t-gpu, --t-p, --t-e of run_query), the GPU's
share of the morsels for the static split (both sides finish together) and the predicted wall time
of every policy (gpu alone, cpu alone, both).

Q14 has a build phase before its probe morsels (bench/run_query.cpp): the part hash table, 2M rows at
SF10, cleared and built on the GPU (one command buffer) or by the P workers together. Its prediction
per device: the insert line of join_build/part_build over its largest calibrated builds (large_n; the
calibration stops at 2^20 rows, so 2M is one octave beyond it) plus the clear, the table's bytes at
the device's filter_count streaming rate. The P workers' inserts: the calibrated config cpu-p-t<k>
for k = --p-workers (calib_join --threads k: k threads inserting together, the kernel run_query
runs) when the model has it; else the single-thread line divided by k, stretched if their streaming
demand exceeds what that many threads reach (cpu_solo_GBps). The Q14 end-to-end run of 17 Nov 2026
found that division 2.6-3.0x optimistic (results/Apple-M3-Ultra_20261117-095403_e2e), hence the
calibration. The router builds on the device predicted faster (BUILD_DEVICE); the gpu policy builds
on the GPU and the cpu policies on the CPU, and every prediction includes the build.

usage: python3 analysis/plan_e2e.py --query q6 --morsel-log2 20 --rows 59986052 --p-workers 24 --e-workers 8
                                   [--model models/Apple-M3-Ultra.json] [--inflight 16] [--json plan.json] [--shell]
                                   [--data data/tpch-sf10]   (q14: its selectivity and the part rows)
--shell prints one line of NAME=value pairs for a sweep script to eval.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import validate as V  # noqa: E402


def per_morsel(query, model, n, sel=None):
    """Predicted us per morsel of n rows on gpu-warm-pipe-spin, cpu-p and cpu-e, and bytes per row
    (what the contention model charges; Q14: l_shipdate and the lines of the other three columns that
    hold a selected row, L(s) of predict_q14's rule lines)."""
    if query == "q14":
        import predict_q14 as P
        out = {}
        for d in ["gpu-warm-pipe-spin", "gpu-warm-spin", "cpu-p", "cpu-e"]:
            c = P.coefficients(model, d, sel)
            p = (c["alpha_us"], c["beta"]["gathers"], c["k"])
            out[d] = float(V.evaluate(p, float(n)))
            if d == "gpu-warm-spin":
                out["fill"] = float(p[0])
        lines = 1 - (1 - sel) ** P.LINE_ROWS
        return out, P.BYTES_FILTER + lines * P.BYTES_REST
    if query == "q6":
        import predict_q6 as P
        rule = "stream"
    else:
        import predict_q1 as P
        rule = P.REG_RULE
    out = {}
    for d in ["gpu-warm-pipe-spin", "gpu-warm-spin", "cpu-p", "cpu-e"]:
        c = P.coefficients(model, d)
        if rule == "register" and "register" in c:
            p = (c["register"]["alpha_us"], c["beta"][rule], c["register"]["k"])
        else:
            p = (c["alpha_us"], c["beta"][rule], c["k"])
        out[d] = float(V.evaluate(p, float(n)))
        if d == "gpu-warm-spin":  # the pipeline's fill and drain: one synchronous round trip's fixed cost
            out["fill"] = float(p[0])
    return out, P.BYTES_PER_ROW


def contention(model, demands, weights):
    """Shares (bytes/us) of devices streaming together under the shared ceiling."""
    cap = model["contention"]["B_max_GBps"] * 1e3  # bytes per us
    total = sum(demands.values())
    if total <= cap:
        return dict(demands)
    wsum = sum(weights[d] * demands[d] for d in demands)
    return {d: cap * weights[d] * demands[d] / wsum for d in demands}


def cpu_cap(model, qos, threads):
    """What `threads` CPU workers of one QoS class stream together at most (bytes/us): the contention
    calibration's solo rate for that thread count (the nearest measured count at or below it)."""
    table = model["contention"]["cpu_solo_GBps"].get(qos, {})
    counts = sorted(int(k) for k in table)
    if not counts or threads <= 0:
        return 0.0
    k = max([c for c in counts if c <= threads] or [counts[0]])
    return table[str(k)] * 1e3


def table_bytes(build_rows):
    """engine/hash_join.hpp make_table: capacity the next power of two >= 2 * rows, 8 B per slot."""
    return (1 << max(1, (2 * build_rows - 1).bit_length())) * 8


def build_phase(model, build_rows, n_p):
    """Predicted build phase (us) on the GPU and on n_p P workers together: clear the table, insert the rows."""
    nbytes = table_bytes(build_rows)
    out = {"rows": build_rows, "table_bytes": nbytes}
    g, _ = V.pick(model, "join_build/part_build", "gpu-warm-spin")
    fg, _ = V.pick(model, "filter_count", "gpu-warm-spin")
    clear_gpu = nbytes / (fg["bytes_per_elem"] / fg["beta_us_per_elem"])
    insert_gpu = g["large_n"]["alpha_us"] + g["large_n"]["beta_us_per_elem"] * build_rows
    c, _ = V.pick(model, "join_build/part_build", "cpu-p")
    fc, _ = V.pick(model, "filter_count", "cpu-p")
    cap = cpu_cap(model, "p", n_p)
    clear_cpu = nbytes / min(n_p * fc["bytes_per_elem"] / fc["beta_us_per_elem"], cap)
    insert_1 = c["large_n"]["alpha_us"] + c["large_n"]["beta_us_per_elem"] * build_rows  # one thread, every row
    demand = n_p * c["bytes_per_elem"] * build_rows / insert_1  # the P workers' streaming demand (bytes/us)
    stretch = max(1.0, demand / cap) if cap else 1.0
    divided = insert_1 / n_p * stretch  # the single-thread line divided by the thread count
    mt_cfg = f"cpu-p-t{n_p}"
    if mt_cfg in model["ops"]["join_build/part_build"]["configs"]:
        m, _ = V.pick(model, "join_build/part_build", mt_cfg)
        insert_cpu, source = m["large_n"]["alpha_us"] + m["large_n"]["beta_us_per_elem"] * build_rows, mt_cfg
    else:
        insert_cpu, source = divided, f"cpu-p / {n_p}"
    out["gpu"] = {"clear_us": clear_gpu, "insert_us": insert_gpu, "us": clear_gpu + insert_gpu}
    out["cpu"] = {"threads": n_p, "source": source, "clear_us": clear_cpu, "insert_us": insert_cpu,
                  "insert_one_thread_us": insert_1, "insert_divided_us": divided, "stretch": stretch,
                  "us": clear_cpu + insert_cpu}
    out["device"] = "gpu" if out["gpu"]["us"] <= out["cpu"]["us"] else "cpu"
    return out


def plan_fill_share(r_gpu, r_total):
    """The GPU's share of the work; its pipeline fill is paid once, in proportion."""
    return r_gpu / r_total if r_total else 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--query", required=True, choices=["q1", "q6", "q14"])
    ap.add_argument("--morsel-log2", type=int, required=True)
    ap.add_argument("--rows", type=int, required=True, help="rows of the table (morsels = ceil(rows / n))")
    ap.add_argument("--p-workers", type=int, required=True)
    ap.add_argument("--e-workers", type=int, required=True)
    ap.add_argument("--inflight", type=int, default=16)
    ap.add_argument("--model", default=str(V.ROOT / "models" / "Apple-M3-Ultra.json"))
    ap.add_argument("--data", default=str(V.ROOT / "data" / "tpch-sf10"), help="q14: selectivity and part rows")
    ap.add_argument("--json")
    ap.add_argument("--shell", action="store_true")
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    n = 1 << args.morsel_log2
    M = -(-args.rows // n)
    sel = build = None
    if args.query == "q14":
        import predict_q14
        sel = predict_q14.selectivity(args.data)[0]
        build = build_phase(model, Path(args.data, "p_partkey.u32").stat().st_size // 4, args.p_workers)
    t, bpr = per_morsel(args.query, model, n, sel)
    nbytes = bpr * n
    w_gpu = model["contention"]["w_gpu"]
    nP, nE = args.p_workers, args.e_workers
    t_gpu, t_p, t_e = t["gpu-warm-pipe-spin"], t["cpu-p"], t["cpu-e"]
    d_gpu = nbytes / t_gpu
    d_cpu_raw = nbytes * (nP / t_p + (nE / t_e if nE else 0.0))
    cap_cpu = cpu_cap(model, "p", nP) + cpu_cap(model, "e", nE)  # the CPU side's own ceiling
    cpu_scale = max(1.0, d_cpu_raw / cap_cpu) if cap_cpu else 1.0  # how much the per-worker times stretch
    d_cpu = d_cpu_raw / cpu_scale
    # gpu alone, cpu alone
    s = contention(model, {"gpu": d_gpu}, {"gpu": w_gpu})
    t_gpu_solo = t_gpu * d_gpu / s["gpu"]
    s = contention(model, {"cpu": d_cpu}, {"cpu": 1.0})
    scale_cpu_solo = cpu_scale * (d_cpu / s["cpu"] if d_cpu else 1.0)
    r_cpu_solo = nP / (t_p * scale_cpu_solo) + (nE / (t_e * scale_cpu_solo) if nE else 0.0)
    # both
    s = contention(model, {"gpu": d_gpu, "cpu": d_cpu}, {"gpu": w_gpu, "cpu": 1.0})
    t_gpu_both = t_gpu * d_gpu / s["gpu"]
    scale_cpu = cpu_scale * (d_cpu / s["cpu"] if d_cpu else 1.0)
    t_p_both, t_e_both = t_p * scale_cpu, t_e * scale_cpu
    r_total = 1 / t_gpu_both + nP / t_p_both + (nE / t_e_both if nE else 0.0)
    plan = {
        "query": args.query, "model": args.model, "n": n, "morsels": M, "bytes_per_row": bpr, "p_workers": nP, "e_workers": nE,
        "inflight": args.inflight,
        "solo_us_per_morsel": {"gpu-warm-pipe-spin": t_gpu, "cpu-p": t_p, "cpu-e": t_e},
        "solo_demand_GBps": {"gpu": d_gpu / 1e3, "cpu": d_cpu_raw / 1e3, "cpu_capped": d_cpu / 1e3},
        "cpu_cap_GBps": cap_cpu / 1e3, "B_max_GBps": model["contention"]["B_max_GBps"], "w_gpu": w_gpu,
        "both_us_per_morsel": {"gpu": t_gpu_both, "p": t_p_both, "e": t_e_both},
        "gpu_share": (1 / t_gpu_both) / r_total,
        "fill_us": t["fill"],
        "pred_ms": {"gpu": (M * t_gpu_solo + t["fill"]) / 1e3,
                    "cpu": M / r_cpu_solo / 1e3 if r_cpu_solo else None,
                    "both": (M / r_total + t["fill"] * plan_fill_share(1 / t_gpu_both, r_total)) / 1e3},
    }
    if build:  # the build phase runs alone, before the probe morsels: its time adds
        plan["selectivity"] = sel
        plan["build"] = build
        bg, bc = build["gpu"]["us"] / 1e3, build["cpu"]["us"] / 1e3
        probe = dict(plan["pred_ms"])
        plan["probe_pred_ms"] = probe
        plan["pred_ms"] = {"gpu": probe["gpu"] + bg, "cpu": probe["cpu"] + bc,
                           "both": probe["both"] + min(bg, bc), "both_gpu_build": probe["both"] + bg, "both_cpu_build": probe["both"] + bc}
    if args.json:
        Path(args.json).write_text(json.dumps(plan, indent=2))
    if args.shell:
        b = plan["both_us_per_morsel"]
        line = (f"T_GPU={b['gpu']:.3f} T_P={b['p']:.3f} T_E={b['e']:.3f} GPU_SHARE={plan['gpu_share']:.4f} "
                f"PRED_GPU_MS={plan['pred_ms']['gpu']:.3f} PRED_CPU_MS={plan['pred_ms']['cpu']:.3f} PRED_BOTH_MS={plan['pred_ms']['both']:.3f}")
        if build:
            line += (f" BUILD_DEVICE={build['device']} PRED_BUILD_GPU_MS={build['gpu']['us'] / 1e3:.3f}"
                     f" PRED_BUILD_CPU_MS={build['cpu']['us'] / 1e3:.3f} PRED_BOTH_GPUBUILD_MS={plan['pred_ms']['both_gpu_build']:.3f}"
                     f" PRED_BOTH_CPUBUILD_MS={plan['pred_ms']['both_cpu_build']:.3f}")
        print(line)
    else:
        print(json.dumps(plan, indent=2))


if __name__ == "__main__":
    main()
