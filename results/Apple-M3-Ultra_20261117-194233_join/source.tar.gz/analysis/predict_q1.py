#!/usr/bin/env python3
"""Predict TPC-H Q1 morsel times from the single-operator model and test the prediction on the
held-out Q1 runs (bench/val_q1, scripts/run_val_q1.sh). Nothing here is fitted on Q1.

usage: python3 analysis/predict_q1.py results/<run>_q1/val_q1.csv [more runs ...] [--model models/Apple-M1.json]

Q1 per row: 7 uint32 columns (28 B), one predicate, 6 groups, 6 aggregate fields per group.
Composition rules, per device configuration d (cpu-p, cpu-e, gpu-warm, gpu-warm-pipe), from the
calibrated operators in models/<machine>.json:
  stream    T = alpha_d + n * 28 B / BW_d                     bandwidth only
  roofline  T = alpha_d + n * max(28 B / BW_d, 6 * c_d)       streaming and compute overlap
  additive  T = alpha_d + n * (28 B / BW_d + 6 * c_d)         streaming and compute do not overlap
  per-device  roofline on the GPU, additive on the CPU. One CPU core runs the loads and the updates
            in one instruction stream, and its calibration kernel updates private tables as Q1's does,
            so the two costs add. A GPU overlaps one warp's arithmetic with other warps' loads, and
            its calibration kernel pays a threadgroup atomic per update, which Q1's register
            accumulators do not, so 6 * c_d only bounds Q1's compute from above.
  register  additive on the CPU; on the GPU, Q1's kernel as it is: every thread keeps 6 x 6 = 36
            uint64 accumulators in registers, updates all 36 for every row (branchless), and
            reduces 36 values per threadgroup. From the register-aggregation calibration
            (bench/calib_reg: the same structure on Q1's grid, C columns and U accumulators per
            thread), at the calibrated column count C nearest Q1's 7:
              beta = max(28 B / BW_d, 36 r_d) + kappa_d min(28 B / BW_d, 36 r_d), with r_d (cost
                     per update) and kappa_d (the share of the shorter term the longer does not
                     hide, at C) from the model's register_agg;
              alpha, k: those of agg_reg at C and U = 36, interpolated linearly in U between the
                     calibrated U, instead of filter_count's: a morsel's fixed cost and the share of
                     the launch that stays exposed grow with the accumulators per thread.
            Chosen after the M3 Ultra's Q1 runs (README, register aggregation), so post hoc there.
            Scored only when the model has register_agg for every GPU config of the runs.
  BW_d    = 4 B / beta of filter_count (the device's streaming rate)
  c_d     = beta of agg_group/G=7 minus its 8 B / BW_d: compute per aggregate update (>= 0)
  alpha_d = alpha of filter_count (launch + sync; Q1's two GPU dispatches share one command buffer)
Pipelined GPU configs hide part of the launch behind the previous morsel: with beta_d the rule's
per-row cost, T = max(alpha_d, n beta_d) + k_d min(alpha_d, n beta_d), k_d = filter_count's overlap.k,
and both betas above from the largest calibrated morsels (large_n), since a line through that shape
gets the slope too fast (models/<machine>.json; --pipe-form: max k = 0, line k = 1, fit = the earlier
full-range lines).
For comparison, `q1-fit` is a line fitted on the Q1 runs themselves: the best any alpha + beta * n
model could do (not a prediction).
Runs made under a cache state (--cache cpu-write, ...; configs <device>-<state>) are predicted from the
cold prediction of the base config and the state's table in the model's cache_states, keyed on the
morsel's footprint 28 B x n (validate.StatePred, --state-form delta | ratio | line, or none for the
cache-oblivious baseline; delta, the form that transferred from the filter on the held-out queries, is
the default); routers and crossovers are then scored per state, and the JSON carries the form
(_state_<form>).

Reported per rule: the prediction error over every (run, n) median per device, and placement
accuracy: over all (run, n), how often the device the rule predicts fastest is the one measured
fastest, for a sync router {cpu-p, cpu-e, gpu-warm} and a pipelined one {cpu-p, cpu-e, gpu-warm-pipe}.
Writes predict_q1.json next to the first CSV (_idle_coef with --coef-regime idle, _pipe_<form> with
another --pipe-form).
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import validate as V  # noqa: E402

ROOT = V.ROOT
BYTES_PER_ROW = 28
AGG_FIELDS = 6
Q1_UPDATES = 36  # kernels/q1.metal: SLOTS x FIELDS accumulators per thread, all updated per row
Q1_COLS = 7      # columns Q1 loads per row (BYTES_PER_ROW / 4)
RULES = ["stream", "roofline", "additive", "per-device"]
REG_RULE = "register"


def coefficients(model, dev, regime="auto", pipe_form="overlap"):
    """Calibrated coefficients for a Q1 device config (regime: see validate.pick; pipe_form:
    validate.pipe_coef)."""
    f, src = V.pick(model, "filter_count", dev, regime)
    g, _ = V.pick(model, "agg_group/G=7", dev, regime)
    fb, k = V.pipe_coef(f, dev, pipe_form)
    gb, _ = V.pipe_coef(g, dev, pipe_form)
    bw = f["bytes_per_elem"] / fb  # bytes per us
    c = max(gb - g["bytes_per_elem"] / bw, 0.0)
    stream = BYTES_PER_ROW / bw
    roofline, additive = max(stream, AGG_FIELDS * c), stream + AGG_FIELDS * c
    out = {"calibration": src, "alpha_us": f["alpha_us"], "k": k, "stream_us_per_row": stream,
           "compute_us_per_row": AGG_FIELDS * c,
           "beta": {"stream": stream, "roofline": roofline, "additive": additive,
                    "per-device": roofline if dev.startswith("gpu") else additive}}
    if not dev.startswith("gpu"):
        out["beta"][REG_RULE] = additive
        return out
    reg = model.get("register_agg", {}).get("configs", {}).get(src)
    if reg:
        cols = min(reg["cols"], key=lambda c: (abs(int(c) - Q1_COLS), -int(c)))  # nearest Q1's, the larger on a tie
        rc = reg["cols"][cols]
        u = Q1_UPDATES * reg["c_us_per_update"]
        ops = [model["ops"][key] for key in model["register_agg"]["ops"][cols]]  # sorted by U
        us = [o["groups"] for o in ops]
        alphas = [o["configs"][src]["alpha_us"] for o in ops]
        ks = [V.pipe_coef(o["configs"][src], dev, pipe_form)[1] for o in ops]
        out["register"] = {"cols": int(cols), "updates_us_per_row": u, "kappa": rc["kappa"],
                           "fit_max_rel_err": rc["max_rel_err"],
                           "alpha_us": float(np.interp(Q1_UPDATES, us, alphas)),
                           "k": float(np.interp(Q1_UPDATES, us, ks))}
        out["beta"][REG_RULE] = max(stream, u) + rc["kappa"] * min(stream, u)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--model", default=str(ROOT / "models" / "Apple-M1.json"))
    ap.add_argument("--coef-regime", choices=["auto", "idle"], default="auto",
                    help="auto: busy-GPU (-spin) calibration for -spin Q1 configs when available; idle: never")
    ap.add_argument("--state-form", choices=V.STATE_FORMS + ["none"], default="delta",
                    help="runs made under a cache state (--cache; configs <device>-<state>): how the state's table in "
                         "models/<machine>.json cache_states changes the cold prediction (validate.StatePred); none: "
                         "the cold prediction for every state, the cache-oblivious baseline")
    ap.add_argument("--pipe-form", choices=V.PIPE_FORMS, default="overlap",
                    help="pipelined GPU configs: overlap (the model's k), max (k = 0) or line (k = 1), all with the "
                         "large-morsel slopes; fit: the full-range lines (the earlier predictions)")
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    meds = V.load_runs(args.csv)
    devs = V.select_devices(meds["config"])  # cold configs, then the same under each cache state
    meds = meds[meds["config"].isin(devs)]

    coef = {d: coefficients(model, V.split_state(d)[0], args.coef_regime, args.pipe_form) for d in devs}
    missing = [coef[d]["calibration"] for d in devs if REG_RULE not in coef[d]["beta"]]
    predictive = RULES + ([] if missing else [REG_RULE])
    pred = {}
    for d in devs:
        a, b = V.query_fit(meds, d)
        coef[d]["q1_fit"] = {"alpha_us": a, "beta_us_per_row": b}
        for r in predictive:
            pred[(r, d)] = (coef[d]["alpha_us"], coef[d]["beta"][r], coef[d]["k"])
        if REG_RULE in predictive and "register" in coef[d]:  # the GPU: agg_reg's launch terms
            pred[(REG_RULE, d)] = (coef[d]["register"]["alpha_us"], coef[d]["beta"][REG_RULE], coef[d]["register"]["k"])
        for r in predictive:
            pred[(r, d)] = V.with_state(pred[(r, d)], model, d, BYTES_PER_ROW, args.state_form)
        pred[("q1-fit", d)] = (a, b)
    rules = predictive + ["q1-fit"]
    states = sorted({s for d in devs for s in [V.split_state(d)[1]] if s})

    out = {"model": str(Path(args.model).relative_to(ROOT)) if Path(args.model).is_absolute() else args.model,
           "runs": sorted(meds["run"].unique()), "coefficients": coef}
    err = sys.stderr
    print(f"Q1 runs: {', '.join(out['runs'])}\nmodel: {out['model']}" +
          (f"\ncache states: {', '.join(states)} (form {args.state_form})" if states else "") + "\n", file=err)
    print(f"{'device':19s} {'calibration':19s} {'alpha us':>9s} {'k':>5s} {'stream':>7s} {'compute':>8s} {'Q1 fit':>7s}"
          f"   (ns/row; Q1 fit = measured; pipelined: {args.pipe_form})", file=err)
    for d in devs:
        c = coef[d]
        print(f"{d:19s} {c['calibration']:19s} {c['alpha_us']:9.1f} {c['k']:5.2f} {c['stream_us_per_row'] * 1e3:7.3f}"
              f" {c['compute_us_per_row'] * 1e3:8.3f} {c['q1_fit']['beta_us_per_row'] * 1e3:7.3f}", file=err)
    regs = [d for d in devs if "register" in coef[d]]
    if regs:
        print(f"\nrule {REG_RULE}, GPU (register_agg at C columns; alpha and k of agg_reg at C, U = {Q1_UPDATES}):",
              file=err)
        print(f"{'device':19s} {'C':>2s} {'alpha us':>9s} {'k':>5s} {'36 upd':>7s} {'kappa':>5s} {'beta':>7s}   (ns/row)",
              file=err)
        for d in regs:
            r = coef[d]["register"]
            print(f"{d:19s} {r['cols']:2d} {r['alpha_us']:9.1f} {r['k']:5.2f} {r['updates_us_per_row'] * 1e3:7.3f}"
                  f" {r['kappa']:5.2f} {coef[d]['beta'][REG_RULE] * 1e3:7.3f}", file=err)
    if missing:
        out["register_missing"] = sorted(set(missing))
        print(f"(rule {REG_RULE} not scored: the model has no register_agg for {', '.join(sorted(set(missing)))};"
              f" run scripts/run_calib_reg.sh on this machine)", file=err)

    out["rules"], out["crossovers"] = V.score(meds, devs, pred, rules, predictive, err)
    out["coef_regime"], out["pipe_form"], out["state_form"] = args.coef_regime, args.pipe_form, args.state_form
    suffix = (("" if args.coef_regime == "auto" else "_idle_coef") + ("" if args.pipe_form == "overlap" else f"_pipe_{args.pipe_form}")
              + (f"_state_{args.state_form}" if states else ""))
    path = Path(args.csv[0]).with_name(f"predict_q1{suffix}.json")
    path.write_text(json.dumps(out, indent=2, default=float))
    print(f"\n-> {path}", file=err)


if __name__ == "__main__":
    main()
