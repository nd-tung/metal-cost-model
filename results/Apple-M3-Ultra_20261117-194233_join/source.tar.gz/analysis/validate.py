"""Shared scoring of the held-out query validations (analysis/predict_q1.py, analysis/predict_q6.py).

A query's predictor turns models/<machine>.json into one prediction (alpha, beta[, k]) per (rule,
device config): T = max(alpha, beta n) + k min(alpha, beta n), which is the line alpha + beta n for
k = 1 (the default; CPU and sync GPU) and lets a pipelined GPU morsel hide part of its launch behind
the previous one for k < 1 (models/<machine>.json overlap). This module loads the query runs, fits the
query's own line per device (the best any alpha + beta * n model could do; not a prediction) and
scores every rule: the prediction error over
every (run, n) median per device, the placement accuracy of the routers (over all (run, n), how often
the device the rule predicts fastest is the one measured fastest) and the predicted against the
measured GPU/CPU crossovers.

Cache states (models/<machine>.json cache_states; README "Cache state: producer probe"): a query run
made under --cache <state> gets configs <device config>-<state> from fit.prepare. Their prediction is
the cold prediction of the base config changed by the state's table (StatePred, --state-form), and the
routers and crossovers are scored per state (sync-spin@cpu-write: the candidates measured under that
state).
"""
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fit  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DEVICES = ["cpu-p", "cpu-e", "gpu-warm", "gpu-warm-pipe", "gpu-warm-spin", "gpu-warm-pipe-spin"]
ROUTERS = {"sync": ["cpu-p", "cpu-e", "gpu-warm"], "pipelined": ["cpu-p", "cpu-e", "gpu-warm-pipe"],
           "sync-spin": ["cpu-p", "cpu-e", "gpu-warm-spin"], "pipelined-spin": ["cpu-p", "cpu-e", "gpu-warm-pipe-spin"]}
# Cache states of a morsel's input (calib_filter / val_<query> --cache; fit.prepare suffixes every
# state but cold): what last touched the rows before the timed morsel.
STATES = ["hot", "cpu-write", "cpu-read", "gpu-write", "gpu-read", "cpu-touch1", "gpu-touch1"]
STATE_FORMS = ["delta", "ratio", "line"]  # delta: the default of the predictors (it transferred on the held-out queries)


def split_state(dev):
    """'gpu-warm-spin-cpu-write' -> ('gpu-warm-spin', 'cpu-write'); a cold config -> (dev, None)."""
    for s in STATES:
        if dev.endswith("-" + s):
            return dev[: -len(s) - 1], s
    return dev, None


def select_devices(configs):
    """The query's device configs among `configs`, in order: DEVICES cold, then the same under each state."""
    present = set(configs)
    out = []
    for s in [None] + STATES:
        suf = "" if s is None else "-" + s
        out += [d + suf for d in DEVICES if d + suf in present]
    return out


def state_table(model, op, base, state):
    """The cache-state table of (op, base config, state) in models/<machine>.json, or None."""
    try:
        return model["cache_states"]["ops"][op]["configs"][base]["states"][state]
    except KeyError:
        return None


def interp_log(x, xs, ys):
    """Linear interpolation in log2 x over a table with ascending xs, clamped to its ends."""
    return np.interp(np.log2(np.asarray(x, float)), np.log2(np.asarray(xs, float)), np.asarray(ys, float))


class StatePred:
    """A prediction for a device config under a cache state: the cold prediction (alpha, beta[, k]) of
    the base config, changed by the state's table t (models/<machine>.json cache_states, measured on
    filter_count), keyed on the morsel's footprint F = bytes_per_row * n (the bytes the state applies to):
      ratio  sync GPU (ratio_of "kernel"): T = max(a', r b n) + k min(a', r b n), a' = alpha + d_o(F):
             the streaming term scaled by the kernel's time under the state over cold at that footprint,
             the fixed part shifted by the round trip's change outside the kernel. Pipelined GPU and CPU
             (ratio_of "morsel"): T = r (max(a, b n) + k min(a, b n)), the whole morsel scaled by its time
             under the state over cold (a pipelined morsel's kernel overlaps its launch). Rates carry over
             to another operator at the same footprint.
      delta  T = cold prediction + delta_us(F): the state's extra time at that footprint as the filter
             measured it, whatever the operator.
      line   T from the state's own calibration line, as rates: alpha + (alpha_s - alpha_cold),
             beta * beta_s / beta_cold (pipelined: large_n slopes), the state's k.
    Tables are interpolated in log F and clamped outside the measured footprints. On the held-out queries
    (README "Cache state", stage 3) delta transferred from the filter to Q6 and Q1 on every device, ratio
    only on the GPU (a CPU operator bound by its own compute gains nothing from resident input, and
    scaling its whole morsel over-corrects), so delta is the predictors' default."""

    def __init__(self, base, table, form, bytes_per_row, dev):
        if form not in STATE_FORMS:
            raise ValueError(f"unknown state form {form!r}")
        self.base = tuple(base) if len(base) == 3 else (*base, 1.0)
        self.table, self.form, self.bpr, self.dev = table, form, float(bytes_per_row), dev

    def __call__(self, n):
        n = np.asarray(n, float)
        a, b, k = self.base
        t, F = self.table, self.bpr * n
        if self.form == "line":
            cold, st = t["cold_line"], t["line"]
            a, b, k = a + st["alpha_us"] - cold["alpha_us"], b * st["beta_us_per_elem"] / cold["beta_us_per_elem"], st["k"]
            return np.maximum(a, b * n) + k * np.minimum(a, b * n)
        if self.form == "delta":
            return np.maximum(a, b * n) + k * np.minimum(a, b * n) + interp_log(F, t["footprint_bytes"], t["delta_us"])
        r = interp_log(F, t["footprint_bytes"], t["ratio"])
        if t.get("ratio_of", "kernel") == "morsel":
            return r * (np.maximum(a, b * n) + k * np.minimum(a, b * n))
        a = a + interp_log(F, t["footprint_bytes"], t["delta_fixed_us"])
        return np.maximum(a, r * b * n) + k * np.minimum(a, r * b * n)

    def describe(self):
        a, b, k = self.base
        return {"alpha_us": a, "beta_ns_per_row": b * 1e3, "k": k, "state": split_state(self.dev)[1], "state_form": self.form}


def with_state(p, model, dev, bytes_per_row, form="delta", op="filter_count"):
    """The prediction p of the base config, under the cache state in `dev`'s suffix (a cold config: p
    itself). form "none" keeps p for every state: the cache-oblivious baseline."""
    base, state = split_state(dev)
    if state is None or form == "none":
        return p
    t = state_table(model, op, base, state)
    if t is None:
        raise SystemExit(f"{model.get('machine', 'model')}: no cache_states table for {op} {base} under {state}; "
                         f"list the machine's cache-state runs in analysis/model_runs.json and rebuild the model")
    return StatePred(p, t, form, bytes_per_row, dev)


def load_runs(paths):
    """Per-run medians per (device config, n) of the query CSVs; config = device config only."""
    meds = []
    for p in paths:
        df = fit.prepare(pd.read_csv(p))
        df["dev"] = df["config"].str.split("/", n=1).str[1]  # fit.prepare adds -spin for busy-GPU rows
        df["config"] = df["dev"]
        m = fit.medians(df)
        m["run"] = Path(p).parent.name
        meds.append(m)
    return pd.concat(meds, ignore_index=True)


def pick(model, op, dev, regime="auto"):
    """The calibrated config of `op` for the query's device config `dev`, and its name. regime auto:
    the same clock regime as the query runs when the model has it (a -spin config uses the busy-GPU
    calibration), else the idle one; regime idle: always the idle calibration."""
    cfgs = model["ops"][op]["configs"]
    if regime == "auto" and dev in cfgs:
        return cfgs[dev], dev
    return cfgs[dev.removesuffix("-spin")], dev.removesuffix("-spin")


PIPE_FORMS = ["overlap", "max", "line", "fit"]


def pipe_coef(entry, dev, pipe_form="overlap"):
    """(beta_us_per_elem, k) a predictor takes from the calibrated config `entry` for the query's device
    config dev. Pipelined GPU configs (-pipe) take the slope over the largest calibrated morsels
    (large_n), and k: the config's own overlap.k (pipe_form overlap), 0 (max: the launch hidden
    completely) or 1 (line: alpha + beta n). pipe_form fit, and every config not pipelined: the
    full-range line, k = 1 (the predictions before the overlap form)."""
    if "-pipe" not in dev or pipe_form == "fit":
        return entry["beta_us_per_elem"], 1.0
    k = {"overlap": entry["overlap"]["k"], "max": 0.0, "line": 1.0}[pipe_form]
    return entry["large_n"]["beta_us_per_elem"], k


def evaluate(p, n):
    """Predicted time of p = (alpha_us, beta_us_per_row[, k]) at n (k = 1, the line, if absent), or of a
    StatePred."""
    if callable(p):
        return p(n)
    a, b, k = p if len(p) == 3 else (*p, 1.0)
    return np.maximum(a, b * n) + k * np.minimum(a, b * n)


def describe(p):
    """Coefficients of a prediction for the JSON."""
    if callable(p):
        return p.describe()
    a, b, k = p if len(p) == 3 else (*p, 1.0)
    return {"alpha_us": a, "beta_ns_per_row": b * 1e3, "k": k}


def crossover(g, c, lo=2 ** 8, hi=2 ** 28):
    """n from which the GPU prediction g is below the CPU prediction c; None if it never is. Lines: in
    closed form (g is the larger of the lines a + k b n and k a + b n, so both must be below c). With a
    cache state (StatePred) on either side: the first point of a log grid [lo, hi] from which g stays
    below c."""
    if callable(g) or callable(c):
        ns = np.logspace(np.log2(lo), np.log2(hi), 2001, base=2)
        wins = evaluate(g, ns) < evaluate(c, ns)
        last_loss = np.flatnonzero(~wins)
        if wins.size == 0 or not wins[-1]:
            return None
        return float(ns[last_loss[-1] + 1]) if last_loss.size else float(lo)
    ga, gb, k = g if len(g) == 3 else (*g, 1.0)
    ca, cb = c[:2]
    if cb <= gb:
        return None
    return max((ga - ca) / (cb - k * gb), (k * ga - ca) / (cb - gb))


def query_fit(meds, dev):
    """alpha_us, beta_us_per_row of a line fitted on the query's own pooled medians of `dev`."""
    g = meds[meds["config"] == dev]
    a, b, _, _ = fit.fit_linear_rel(g.groupby("n")["t_med"].median().index.values.astype(float),
                                    g.groupby("n")["t_med"].median().values.astype(float))
    return a, b


def l2(x):
    return f"2^{math.log2(x):.1f}" if x else "none"


def score(meds, devs, pred, rules, predictive, err=sys.stderr):
    """Scores pred[(rule, dev)] = (alpha_us, beta_us_per_row[, k]) for every rule in `rules` against
    the medians and prints the error and placement table, then the crossovers (predicted for the rules
    in `predictive` only). A router is scored only when its GPU config was measured: without it, it
    would only rank the CPU workers. Returns (rules, crossovers) for the JSON."""
    # Routers: the candidate sets measured in these runs, cold and per cache state (<router>@<state>).
    routers = {}
    for name, cand in ROUTERS.items():
        for s in [None] + STATES:
            suf = "" if s is None else "-" + s
            c = [d + suf for d in cand if d + suf in devs]
            if len(c) >= 2 and any(d.startswith("gpu") for d in c):
                routers[name + ("" if s is None else "@" + s)] = c
    out = {}
    for r in rules:
        res = {"devices": {}, "placement": {}}
        for d in devs:
            g = meds[meds["config"] == d]
            p = pred[(r, d)]
            rel = (evaluate(p, g["n"].values.astype(float)) - g["t_med"].values) / g["t_med"].values
            res["devices"][d] = {**describe(p),
                                 "err_median": float(np.median(np.abs(rel))),
                                 "err_p90": float(np.quantile(np.abs(rel), 0.9)),
                                 "bias_median": float(np.median(rel))}
        for name, cand in routers.items():
            piv = meds[meds["config"].isin(cand)].pivot_table(index=["run", "n"], columns="config", values="t_med")
            piv = piv.dropna()
            measured_best = piv.idxmin(axis=1)
            ns = piv.index.get_level_values("n").values.astype(float)
            pt = pd.DataFrame({d: evaluate(pred[(r, d)], ns) for d in cand}, index=piv.index)
            predicted_best = pt.idxmin(axis=1)
            hit = (measured_best == predicted_best)
            # cost of a wrong pick: measured time of the predicted device / measured best time
            regret = np.array([piv.loc[i, predicted_best[i]] / piv.loc[i, measured_best[i]] for i in piv.index])
            res["placement"][name] = {"accuracy": float(hit.mean()), "points": int(hit.size),
                                      "mean_slowdown_when_wrong": float(regret[~hit.values].mean()) if (~hit).any() else 1.0,
                                      "max_slowdown": float(regret.max())}
        out[r] = res

    placed = [k for k in routers if k in out[rules[0]]["placement"]]
    print(f"\n{'rule':10s} " + " ".join(f"{d:>22s}" for d in devs) + "   placement: " + "  ".join(placed), file=err)
    for r in rules:
        res = out[r]
        cells = " ".join(f"{res['devices'][d]['err_median']:>9.0%} med {res['devices'][d]['err_p90']:>5.0%} p90"
                         for d in devs)
        pl = res["placement"]
        acc = "  ".join(f"{pl[k]['accuracy']:>{len(k)}.0%}" for k in placed)
        print(f"{r:10s} {cells}   {acc}", file=err)
    print("(error = |predicted - measured| / measured over every (run, n) median)", file=err)

    # Measured vs predicted GPU/CPU crossovers on the pooled medians, per cache state (same-state pairs).
    pooled = meds.groupby(["config", "n"])["t_med"].median()
    print("\ncrossovers (GPU faster from):", file=err)
    crossovers = {}
    for gk in [d for d in devs if d.startswith("gpu")]:
        for ck in [d for d in devs if d.startswith("cpu") and split_state(d)[1] == split_state(gk)[1]]:
            m = fit.measured_crossover(pooled[gk], pooled[ck])
            _, text = fit.report(m)
            row = {"measured": text, "measured_n": m["measured_interp_n"]}
            for r in predictive:
                row[r] = crossover(pred[(r, gk)], pred[(r, ck)])
            crossovers[f"{gk} vs {ck}"] = row
            print(f"  {gk:24s} vs {ck:16s}: measured {text}; predicted " +
                  ", ".join(f"{r} {l2(row[r])}" for r in predictive), file=err)
    return out, crossovers
