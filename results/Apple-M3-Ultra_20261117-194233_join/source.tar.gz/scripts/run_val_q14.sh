#!/usr/bin/env bash
# Q14 validation sweep: scripts/run_val_query.sh with QUERY=q14 (settings and examples there).
#   scripts/run_val_q14.sh            SPIN=20 scripts/run_val_q14.sh
exec env QUERY=q14 "$(dirname "$0")/run_val_query.sh" "$@"
