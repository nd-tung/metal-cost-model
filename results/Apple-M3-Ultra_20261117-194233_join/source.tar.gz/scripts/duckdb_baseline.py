#!/usr/bin/env python3
"""The DuckDB CPU-only baseline of the end-to-end evaluation: the official TPC-H Q1, Q6 and Q14 on DuckDB's
own tables (its tpch extension, dbgen), all threads, median of --runs after one warm-up. Needs
<data>/tpch.duckdb (scripts/gen_tpch.py keeps it); --sf creates it with dbgen when it is missing (the
same tables gen_tpch.py exported). Appends one row per query to --out.

usage: python3 scripts/duckdb_baseline.py --data data/tpch-sf10 [--sf 10] [--runs 5] [--queries q1,q6,q14]
                                         [--out results/<run>/duckdb.csv]
"""
import argparse
import platform
import statistics
import subprocess
import sys
import time
from pathlib import Path

import duckdb

sys.path.insert(0, str(Path(__file__).resolve().parent))
from tpch_reference import Q1_OFFICIAL, Q6_OFFICIAL, Q14_OFFICIAL  # noqa: E402

QUERIES = {"q1": Q1_OFFICIAL, "q6": Q6_OFFICIAL, "q14": Q14_OFFICIAL}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--sf", type=float, help="create <data>/tpch.duckdb with dbgen at this scale factor if missing")
    ap.add_argument("--runs", type=int, default=5)
    ap.add_argument("--threads", type=int, help="DuckDB threads (default: DuckDB's, all cores)")
    ap.add_argument("--queries", default="q1,q6,q14", help="comma-separated, of " + ",".join(QUERIES))
    ap.add_argument("--out", default="results/duckdb_baseline.csv")
    args = ap.parse_args()
    db = Path(args.data) / "tpch.duckdb"
    if not db.exists():
        if args.sf is None:
            raise SystemExit(f"{db} is missing; pass --sf to create it with dbgen")
        con = duckdb.connect(str(db))
        con.execute("INSTALL tpch; LOAD tpch;")
        t0 = time.perf_counter()
        con.execute(f"CALL dbgen(sf={args.sf})")
        con.close()
        print(f"dbgen(sf={args.sf}) -> {db} in {time.perf_counter() - t0:.0f} s", file=sys.stderr)
    con = duckdb.connect(str(db), read_only=True)
    if args.threads:
        con.execute(f"SET threads = {args.threads}")
    threads = con.execute("SELECT current_setting('threads')").fetchone()[0]
    rows = con.execute("SELECT count(*) FROM lineitem").fetchone()[0]
    machine = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True).stdout.strip().replace(" ", "-")
    out = Path(args.out)
    new = not out.exists() or out.stat().st_size == 0
    with out.open("a") as f:
        if new:
            f.write("machine,op,data,rows,threads,duckdb,runs,t_ms_median,t_ms_min,t_ms_max\n")
        for name in args.queries.split(","):
            sql = QUERIES[name]
            con.execute(sql).fetchall()  # warm-up
            times = []
            for _ in range(args.runs):
                t0 = time.perf_counter()
                con.execute(sql).fetchall()
                times.append((time.perf_counter() - t0) * 1e3)
            print(f"{name}: median {statistics.median(times):.1f} ms, min {min(times):.1f}, max {max(times):.1f} "
                  f"({threads} threads, {rows} rows, DuckDB {duckdb.__version__})", file=sys.stderr)
            f.write(f"{machine},{name},{Path(args.data).name},{rows},{threads},{duckdb.__version__},{args.runs},"
                    f"{statistics.median(times):.3f},{min(times):.3f},{max(times):.3f}\n")
    print(f"-> {out}", file=sys.stderr)


if __name__ == "__main__":
    main()
