#!/usr/bin/env bash
# End-to-end evaluation of the router (bench/run_query.cpp; PLAN.md M3): Q6, Q1 and Q14 over the whole
# table under every placement policy, per morsel size. Q14 starts with its build phase (the part hash
# table): the gpu policy builds on the GPU, cpu and cpu-router on the P workers, and split, dynamic and
# router on both in turn, the plan's build device (BUILD_DEVICE) first; HYBRID_BUILDS=plan: only that one.
# Results go to results/<machine>_<date-time>_e2e/ (run_query.csv, plan_<query>_<log2>.json; the DuckDB
# baseline is scripts/duckdb_baseline.py).
# Before running: AC power, Low Power Mode off, other apps closed.
#
#   scripts/run_e2e.sh                                   # SF10, Q6 and Q1, morsels 2^16..2^22, 6 policies, 3 reps
#   QUERIES=q6 SIZES="18 20" POLICIES="gpu split" scripts/run_e2e.sh
#   QUERIES=q14 scripts/run_e2e.sh
#   DATA=data/tpch-sf1 REPS=1 scripts/run_e2e.sh         # smoke
#   PLAN_DIR=plans scripts/run_e2e.sh                    # plans precomputed elsewhere (plan_<query>_<log2>.sh, the
#                                                        # --shell line of analysis/plan_e2e.py): no Python needed here
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

BIN=build/run_query
DATA="${DATA:-data/tpch-sf10}"
QUERIES="${QUERIES:-q6 q1}"
SIZES="${SIZES:-16 18 20 22}"          # log2 of the morsel size
POLICIES="${POLICIES:-gpu cpu cpu-router split dynamic router}"
HYBRID_BUILDS="${HYBRID_BUILDS:-both}"  # q14: split, dynamic, router with both build devices, or "plan"
SPIN="${SPIN:-20}"                     # ms of ALU-only GPU work before every rep (busy clock, the model's regime)
REPS="${REPS:-3}"
INFLIGHT="${INFLIGHT:-16}"
COOLDOWN="${COOLDOWN:-5}"
P_WORKERS="${P_WORKERS:-$(sysctl -n hw.perflevel0.physicalcpu)}"
E_WORKERS="${E_WORKERS:-$(sysctl -n hw.perflevel1.physicalcpu 2>/dev/null || echo 0)}"
PY="${PY:-python3}"
[[ -x .venv/bin/python ]] && PY=.venv/bin/python
PLAN_DIR="${PLAN_DIR:-}"     # precomputed plans (above); empty: analysis/plan_e2e.py runs here

[[ -f "$DATA/l_shipdate.u32" ]] || { echo "missing $DATA — run: python3 scripts/gen_tpch.py"; exit 1; }
rows=$(( $(stat -f %z "$DATA/l_shipdate.u32") / 4 ))

sweep_begin e2e
MODEL="models/${chip}.json"
[[ -f "$MODEL" ]] || { echo "missing $MODEL (analysis/model.py)"; exit 1; }
sweep_settings "DATA=$DATA QUERIES='$QUERIES' SIZES='$SIZES' POLICIES='$POLICIES' REPS=$REPS INFLIGHT=$INFLIGHT SPIN=$SPIN HYBRID_BUILDS=$HYBRID_BUILDS" \
               "P_WORKERS=$P_WORKERS E_WORKERS=$E_WORKERS MODEL=$MODEL PLAN_DIR='$PLAN_DIR' rows=$rows"
csv="$dir/run_query.csv"
json=(--machine-json "$dir/machine.json")
first=1
for q in $QUERIES; do
  for s in $SIZES; do
    if [[ -n "$PLAN_DIR" ]]; then
      plan=$(cat "$PLAN_DIR/plan_${q}_${s}.sh")
      cp "$PLAN_DIR/plan_${q}_${s}.sh" "$dir/"
      [[ -f "$PLAN_DIR/plan_${q}_${s}.json" ]] && cp "$PLAN_DIR/plan_${q}_${s}.json" "$dir/"
    else
      plan=$("$PY" analysis/plan_e2e.py --query "$q" --morsel-log2 "$s" --rows "$rows" --p-workers "$P_WORKERS" \
             --e-workers "$E_WORKERS" --inflight "$INFLIGHT" --model "$MODEL" --data "$DATA" --json "$dir/plan_${q}_${s}.json" --shell)
    fi
    BUILD_DEVICE=- PRED_BOTH_GPUBUILD_MS= PRED_BOTH_CPUBUILD_MS=  # set by the plans of queries with a build phase
    eval "$plan"
    echo "== $q 2^$s: $plan"
    for p in $POLICIES; do
      builds=-
      if [[ "$BUILD_DEVICE" != - ]]; then
        case "$p" in
          gpu) builds=gpu ;;
          cpu|cpu-router) builds=cpu ;;
          *) builds=$BUILD_DEVICE
             if [[ "$HYBRID_BUILDS" == both ]]; then [[ "$BUILD_DEVICE" == gpu ]] && builds="gpu cpu" || builds="cpu gpu"; fi ;;
        esac
      fi
      for b in $builds; do
        case "$p" in gpu) pred=$PRED_GPU_MS ;; cpu|cpu-router) pred=$PRED_CPU_MS ;; *) pred=$PRED_BOTH_MS ;; esac
        bargs=()
        if [[ "$b" != - ]]; then
          bargs=(--build-device "$b")
          case "$p" in
            gpu|cpu|cpu-router) ;;
            *) if [[ "$b" == gpu ]]; then pred=$PRED_BOTH_GPUBUILD_MS; else pred=$PRED_BOTH_CPUBUILD_MS; fi ;;
          esac
        fi
        if [[ $first == 1 ]]; then first=0; else sleep "$COOLDOWN"; fi
        "$BIN" --query "$q" --policy "$p" --morsel-log2 "$s" --data "$DATA" --reps "$REPS" --inflight "$INFLIGHT" \
               --p-workers "$P_WORKERS" --e-workers "$E_WORKERS" --t-gpu "$T_GPU" --t-p "$T_P" --t-e "$T_E" \
               --pred-ms "$pred" --gpu-spin-ms "$SPIN" --out "$csv" ${bargs[@]+"${bargs[@]}"} ${json[@]+"${json[@]}"}
        json=()
      done
    done
  done
done
echo "done -> $dir"
echo "next:  python3 analysis/e2e.py $csv"
