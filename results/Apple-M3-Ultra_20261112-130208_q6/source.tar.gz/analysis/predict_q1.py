#!/usr/bin/env python3
"""Predict TPC-H Q1 morsel times from the single-operator model and test the prediction on the
held-out Q1 runs (bench/val_q1, scripts/run_val_q1.sh). Nothing here is fitted on Q1.

usage: python3 analysis/predict_q1.py results/<run>_q1/val_q1.csv [more runs ...] [--model models/Apple-M1.json]

Q1 per row: 7 uint32 columns (28 B), one predicate, 6 groups, 6 aggregate fields per group.
Composition rules, per device configuration d (cpu-p, cpu-e, gpu-warm, gpu-warm-pipe), from the
calibrated operators in models/<machine>.json:
  stream    T = alpha_d + n * 28 B / BW_d                     bandwidth only
  roofline  T = alpha_d + n * max(28 B / BW_d, 6 * c_d)       streaming and compute overlap
  additive  T = alpha_d + n * (28 B / BW_d + 6 * c_d)         streaming and compute do not overlap
  BW_d    = 4 B / beta of filter_count (the device's streaming rate)
  c_d     = beta of agg_group/G=7 minus its 8 B / BW_d: compute per aggregate update (>= 0)
  alpha_d = alpha of filter_count (launch + sync; Q1's two GPU dispatches share one command buffer)
For comparison, `q1-fit` is a line fitted on the Q1 runs themselves: the best any alpha + beta * n
model could do (not a prediction).

Reported per rule: the prediction error over every (run, n) median per device, and placement
accuracy: over all (run, n), how often the device the rule predicts fastest is the one measured
fastest, for a sync router {cpu-p, cpu-e, gpu-warm} and a pipelined one {cpu-p, cpu-e, gpu-warm-pipe}.
Writes predict_q1.json next to the first CSV.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import validate as V  # noqa: E402

ROOT = V.ROOT
BYTES_PER_ROW = 28
AGG_FIELDS = 6
RULES = ["stream", "roofline", "additive"]


def coefficients(model, dev, regime="auto"):
    """Calibrated coefficients for a Q1 device config (regime: see validate.pick)."""
    f, src = V.pick(model, "filter_count", dev, regime)
    g, _ = V.pick(model, "agg_group/G=7", dev, regime)
    bw = f["bytes_per_elem"] / f["beta_us_per_elem"]  # bytes per us
    c = max(g["beta_us_per_elem"] - g["bytes_per_elem"] / bw, 0.0)
    stream = BYTES_PER_ROW / bw
    return {"calibration": src, "alpha_us": f["alpha_us"], "stream_us_per_row": stream, "compute_us_per_row": AGG_FIELDS * c,
            "beta": {"stream": stream, "roofline": max(stream, AGG_FIELDS * c), "additive": stream + AGG_FIELDS * c}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--model", default=str(ROOT / "models" / "Apple-M1.json"))
    ap.add_argument("--coef-regime", choices=["auto", "idle"], default="auto",
                    help="auto: busy-GPU (-spin) calibration for -spin Q1 configs when available; idle: never")
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    meds = V.load_runs(args.csv)
    meds = meds[meds["config"].isin(V.DEVICES)]
    devs = [d for d in V.DEVICES if d in set(meds["config"])]

    coef = {d: coefficients(model, d, args.coef_regime) for d in devs}
    pred = {}
    for d in devs:
        a, b = V.query_fit(meds, d)
        coef[d]["q1_fit"] = {"alpha_us": a, "beta_us_per_row": b}
        for r in RULES:
            pred[(r, d)] = (coef[d]["alpha_us"], coef[d]["beta"][r])
        pred[("q1-fit", d)] = (a, b)
    rules = RULES + ["q1-fit"]

    out = {"model": str(Path(args.model).relative_to(ROOT)) if Path(args.model).is_absolute() else args.model,
           "runs": sorted(meds["run"].unique()), "coefficients": coef}
    err = sys.stderr
    print(f"Q1 runs: {', '.join(out['runs'])}\nmodel: {out['model']}\n", file=err)
    print(f"{'device':19s} {'calibration':19s} {'alpha us':>9s} {'stream':>7s} {'compute':>8s} {'Q1 fit':>7s}"
          f"   (ns/row; Q1 fit = measured)", file=err)
    for d in devs:
        c = coef[d]
        print(f"{d:19s} {c['calibration']:19s} {c['alpha_us']:9.1f} {c['stream_us_per_row'] * 1e3:7.3f} {c['compute_us_per_row'] * 1e3:8.3f}"
              f" {c['q1_fit']['beta_us_per_row'] * 1e3:7.3f}", file=err)

    out["rules"], out["crossovers"] = V.score(meds, devs, pred, rules, RULES, err)
    out["coef_regime"] = args.coef_regime
    path = Path(args.csv[0]).with_name("predict_q1.json" if args.coef_regime == "auto" else "predict_q1_idle_coef.json")
    path.write_text(json.dumps(out, indent=2, default=float))
    print(f"\n-> {path}", file=err)


if __name__ == "__main__":
    main()
