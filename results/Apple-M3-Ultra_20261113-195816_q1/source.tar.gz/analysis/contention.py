#!/usr/bin/env python3
"""Shared-bandwidth contention between CPU and GPU from one calib_contention run: the model's
contention term.

usage: python3 analysis/contention.py results/<run>_contention/calib_contention.csv

Each rep streams for a fixed time and reports the bandwidth each side achieved: GPU alone, CPU
alone, or both at once (P or E workers, 1/2/4 threads). Writes contention.json next to the CSV and
prints a summary to stderr.

contention.json:
  gpu_solo_*    GPU streaming alone: median over the GPU-solo configs at the start and the end of
                the sweep, each of them, and the drift between them (thermal check)
  cpu_solo_GBps CPU streaming alone, per qos and thread count
  pairs         CPU and GPU together: each side's bandwidth, the total, and per side
                kappa = 1 - together / alone. That is the PLAN form BW_d * (1 - kappa * busy_other)
                with busy_other = 1 (the other side streams flat out). Kappa differs per pair, so it
                is reported, not used as one constant.
  shared_cap    one model for every pair, two parameters per machine: devices streaming at the same
                time share a ceiling B_max. If their solo demands D_d add up to more, each gets
                B_max * w_d * D_d / sum(w * D), with w = 1 for the CPU and w_gpu for the GPU.
                Fitted on log error over both sides of every pair; `points` has the predictions.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def load(path):
    df = pd.read_csv(path)
    # Configs run one after another; a block is one config. The GPU-solo config runs twice (first and
    # last block) under the same key, so blocks are told apart by position, not by key.
    key = df["cpu_qos"].astype(str) + "/" + df["cpu_threads"].astype(str) + "/" + df["gpu"].astype(str)
    df["block"] = (key != key.shift()).cumsum()
    return df


def iqr(s):
    return [float(s.quantile(0.25)), float(s.quantile(0.75))]


def summarize(df):
    gs = df[(df.cpu_threads == 0) & (df.gpu == "on") & (df.side == "gpu")]
    if gs.empty:
        raise SystemExit("no GPU-solo config in the CSV (cpu_threads 0, gpu on)")
    blocks = sorted(gs.block.unique())
    first, last = gs[gs.block == blocks[0]].gbps, gs[gs.block == blocks[-1]].gbps
    gpu_solo = float(gs.gbps.median())
    out = {
        "machine": str(df.machine.iloc[0]),
        "gpu_solo_GBps": gpu_solo,
        "gpu_solo_first_GBps": float(first.median()),
        "gpu_solo_last_GBps": float(last.median()) if len(blocks) > 1 else None,
        "gpu_drift": float(last.median() / first.median() - 1) if len(blocks) > 1 else None,
        "cpu_solo_GBps": {},
        "pairs": [],
    }
    cs = df[(df.cpu_threads > 0) & (df.gpu == "off") & (df.side == "cpu")]
    for (qos, t), g in cs.groupby(["cpu_qos", "cpu_threads"]):
        out["cpu_solo_GBps"].setdefault(str(qos), {})[str(int(t))] = float(g.gbps.median())
    both = df[(df.cpu_threads > 0) & (df.gpu == "on")]
    for (qos, t), g in both.groupby(["cpu_qos", "cpu_threads"]):
        c, gg = g[g.side == "cpu"], g[g.side == "gpu"]
        solo = out["cpu_solo_GBps"].get(str(qos), {}).get(str(int(t)))
        if solo is None:
            print(f"warning: no CPU-solo config for qos={qos} threads={t}; pair skipped", file=sys.stderr)
            continue
        total = c.set_index("rep").gbps.add(gg.set_index("rep").gbps)  # per rep, both sides
        cc, gc = float(c.gbps.median()), float(gg.gbps.median())
        out["pairs"].append({
            "qos": str(qos), "threads": int(t),
            "cpu_solo_GBps": solo, "gpu_solo_GBps": gpu_solo,
            "cpu_GBps": cc, "gpu_GBps": gc, "total_GBps": float(total.median()),
            "cpu_GBps_iqr": iqr(c.gbps), "gpu_GBps_iqr": iqr(gg.gbps),
            "kappa_cpu": 1 - cc / solo, "kappa_gpu": 1 - gc / gpu_solo,
            "gpu_busy_frac": float((gg.gpu_busy_s / gg.seconds).median()),
            "reps": int(len(c)),
        })
    return out


def cap_predict(dc, dg, b, w):
    """Shared-ceiling model: (CPU, GPU) bandwidth when both stream, from their solo demands."""
    over = dc + dg > b
    s = dc + w * dg
    return np.where(over, b * dc / s, dc), np.where(over, b * w * dg / s, dg)


def fit_shared_cap(pairs):
    dc = np.array([p["cpu_solo_GBps"] for p in pairs])
    dg = np.array([p["gpu_solo_GBps"] for p in pairs])
    xc = np.array([p["cpu_GBps"] for p in pairs])
    xg = np.array([p["gpu_GBps"] for p in pairs])
    best = None
    for w in np.exp(np.linspace(math.log(0.2), math.log(10), 4001)):
        s = dc + w * dg
        sc, sg = dc / s, w * dg / s  # each side's share of the ceiling
        over = np.ones(len(pairs), bool)
        for _ in range(4):  # B from the pairs over the ceiling, then re-check which pairs are over it
            logs = np.concatenate([np.log(xc[over] / sc[over]), np.log(xg[over] / sg[over])])
            if logs.size == 0:
                break
            b = math.exp(float(np.mean(logs)))
            over = dc + dg > b
        pc, pg = cap_predict(dc, dg, b, w)
        err = np.concatenate([np.log(pc / xc), np.log(pg / xg)])
        sse = float(np.sum(err ** 2))
        if best is None or sse < best[0]:
            best = (sse, float(w), b, pc, pg)
    _, w, b, pc, pg = best
    rel = np.abs(np.concatenate([pc / xc, pg / xg]) - 1)
    return {
        "B_max_GBps": b, "w_gpu": w,
        "median_rel_err": float(np.median(rel)), "max_rel_err": float(np.max(rel)),
        "all_pairs_over_cap": bool(np.all(dc + dg > b)),
        "points": [{"qos": p["qos"], "threads": p["threads"],
                    "cpu_pred_GBps": float(a), "gpu_pred_GBps": float(g)}
                   for p, a, g in zip(pairs, pc, pg)],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    args = ap.parse_args()
    out = summarize(load(args.csv))
    out["run"] = Path(args.csv).parent.name
    if not out["pairs"]:
        raise SystemExit("no CPU+GPU pairs in the CSV")
    out["shared_cap"] = fit_shared_cap(out["pairs"])
    path = Path(args.csv).with_name("contention.json")
    path.write_text(json.dumps(out, indent=2))

    sc = out["shared_cap"]
    pred = {(p["qos"], p["threads"]): p for p in sc["points"]}
    drift = f", drift {out['gpu_drift']:+.1%}" if out["gpu_drift"] is not None else ""
    print(f"{out['machine']} {out['run']}: GPU solo {out['gpu_solo_GBps']:.1f} GB/s{drift}", file=sys.stderr)
    print("qos thr | CPU solo | together: CPU   GPU  total | kappa CPU  GPU | cap model: CPU   GPU", file=sys.stderr)
    for p in out["pairs"]:
        m = pred[(p["qos"], p["threads"])]
        print(f"{p['qos']:>3} {p['threads']:>3} | {p['cpu_solo_GBps']:8.1f} | {p['cpu_GBps']:14.1f} {p['gpu_GBps']:5.1f}"
              f" {p['total_GBps']:6.1f} | {p['kappa_cpu']:9.2f} {p['kappa_gpu']:4.2f} |"
              f" {m['cpu_pred_GBps']:14.1f} {m['gpu_pred_GBps']:5.1f}", file=sys.stderr)
    print(f"shared cap: B_max {sc['B_max_GBps']:.1f} GB/s, w_gpu {sc['w_gpu']:.2f}, |error| median "
          f"{sc['median_rel_err']:.1%}, max {sc['max_rel_err']:.1%}"
          f"{'' if sc['all_pairs_over_cap'] else ' (some pairs under the cap)'}", file=sys.stderr)
    print(f"-> {path}", file=sys.stderr)


if __name__ == "__main__":
    main()
