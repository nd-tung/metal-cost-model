#!/usr/bin/env python3
"""Predict TPC-H Q6 morsel times from the single-operator model and test the prediction on the
held-out Q6 runs (bench/val_q6, scripts/run_val_q6.sh). Nothing here is fitted on Q6.

usage: python3 analysis/predict_q6.py results/<run>_q6/val_q6.csv [more runs ...] [--model models/Apple-M1.json]

Q6 per row: 4 uint32 columns (16 B), all read whatever the predicate says (the kernels are
branchless), three range predicates and one product summed; 1.9% of the rows pass. A filter-heavy
query, so the model predicts it from the streaming operator alone, per device configuration d:
  stream    T = alpha_d + n * 16 B / BW_d
  BW_d    = 4 B / beta of filter_count (the device's streaming rate, one predicate per 4 B included)
  alpha_d = alpha of filter_count (launch + sync; Q6's two GPU dispatches share one command buffer)
Pipelined GPU configs hide part of the launch behind the previous morsel: T = max(alpha_d, n beta_d)
+ k_d min(alpha_d, n beta_d), beta_d = 16 B / BW_d, k_d = filter_count's overlap.k and BW_d from its
largest calibrated morsels (large_n), as in predict_q1.py (--pipe-form).
For comparison, `q6-fit` is a line fitted on the Q6 runs themselves: the best any alpha + beta * n
model could do (not a prediction). Scored as in predict_q1.py (analysis/validate.py): error per
device, placement accuracy of the sync and pipelined routers, crossovers.
Writes predict_q6.json next to the first CSV (_idle_coef with --coef-regime idle, _pipe_<form> with
another --pipe-form).
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import validate as V  # noqa: E402

ROOT = V.ROOT
BYTES_PER_ROW = 16
RULES = ["stream"]


def coefficients(model, dev, regime="auto", pipe_form="overlap"):
    """Calibrated coefficients for a Q6 device config (regime: see validate.pick; pipe_form:
    validate.pipe_coef)."""
    f, src = V.pick(model, "filter_count", dev, regime)
    fb, k = V.pipe_coef(f, dev, pipe_form)
    bw = f["bytes_per_elem"] / fb  # bytes per us
    stream = BYTES_PER_ROW / bw
    return {"calibration": src, "alpha_us": f["alpha_us"], "k": k, "stream_us_per_row": stream, "beta": {"stream": stream}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--model", default=str(ROOT / "models" / "Apple-M1.json"))
    ap.add_argument("--coef-regime", choices=["auto", "idle"], default="auto",
                    help="auto: busy-GPU (-spin) calibration for -spin Q6 configs when available; idle: never")
    ap.add_argument("--pipe-form", choices=V.PIPE_FORMS, default="overlap",
                    help="pipelined GPU configs: overlap (the model's k), max (k = 0) or line (k = 1), all with the "
                         "large-morsel slope; fit: the full-range line (the earlier predictions)")
    args = ap.parse_args()
    model = json.loads(Path(args.model).read_text())
    meds = V.load_runs(args.csv)
    meds = meds[meds["config"].isin(V.DEVICES)]
    devs = [d for d in V.DEVICES if d in set(meds["config"])]

    coef = {d: coefficients(model, d, args.coef_regime, args.pipe_form) for d in devs}
    pred = {}
    for d in devs:
        a, b = V.query_fit(meds, d)
        coef[d]["q6_fit"] = {"alpha_us": a, "beta_us_per_row": b}
        for r in RULES:
            pred[(r, d)] = (coef[d]["alpha_us"], coef[d]["beta"][r], coef[d]["k"])
        pred[("q6-fit", d)] = (a, b)
    rules = RULES + ["q6-fit"]

    out = {"model": str(Path(args.model).relative_to(ROOT)) if Path(args.model).is_absolute() else args.model,
           "runs": sorted(meds["run"].unique()), "coefficients": coef}
    err = sys.stderr
    print(f"Q6 runs: {', '.join(out['runs'])}\nmodel: {out['model']}\n", file=err)
    print(f"{'device':19s} {'calibration':19s} {'alpha us':>9s} {'k':>5s} {'stream':>7s} {'Q6 fit':>7s} {'alpha fit':>9s}"
          f"   (ns/row; Q6 fit = measured; pipelined: {args.pipe_form})", file=err)
    for d in devs:
        c = coef[d]
        print(f"{d:19s} {c['calibration']:19s} {c['alpha_us']:9.1f} {c['k']:5.2f} {c['stream_us_per_row'] * 1e3:7.3f}"
              f" {c['q6_fit']['beta_us_per_row'] * 1e3:7.3f} {c['q6_fit']['alpha_us']:9.1f}", file=err)

    out["rules"], out["crossovers"] = V.score(meds, devs, pred, rules, RULES, err)
    out["coef_regime"], out["pipe_form"] = args.coef_regime, args.pipe_form
    suffix = ("" if args.coef_regime == "auto" else "_idle_coef") + ("" if args.pipe_form == "overlap" else f"_pipe_{args.pipe_form}")
    path = Path(args.csv[0]).with_name(f"predict_q6{suffix}.json")
    path.write_text(json.dumps(out, indent=2, default=float))
    print(f"\n-> {path}", file=err)


if __name__ == "__main__":
    main()
