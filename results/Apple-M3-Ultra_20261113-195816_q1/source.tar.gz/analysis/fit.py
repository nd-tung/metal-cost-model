#!/usr/bin/env python3
"""Fit T(n) = alpha + beta*n per configuration and find CPU/GPU crossovers two ways.

usage: python3 analysis/fit.py results/<run>/calib_<op>.csv [--plot out.pdf] [--max-err 0.2]

Configuration = (data, device, qos | state, dispatch). GPU cold time includes the buffer wrap
(t_wrap + t_total), because that is what a morsel placed on a cold buffer pays. GPU rows run with
--dispatch pipelined get a "-pipe" suffix: their time is the GPU time per morsel over a batch committed
back to back (GPU queue kept full), not one synchronous round trip. GPU rows run with --storage private
get a "-priv" suffix: their time includes the blit into a private buffer (state resident: no blit).
GPU rows run with --gpu-spin-ms get a "-spin" suffix: the GPU was kept busy before each timed rep. The fit minimises relative error, so small
morsels (where alpha dominates) count as much as large ones.

Crossover = the morsel size from which the GPU is faster than the CPU. Two estimates:
  fitted   : closed form n* = (alpha_gpu - alpha_cpu) / (beta_cpu - beta_gpu) from the two fits.
  measured : model-free, from the medians on the measured grid: the smallest measured n from which
             the GPU median beats the CPU median at every larger measured n ("first win"), the grid
             point below it ("last loss"), and a linear interpolation of t_gpu - t_cpu between them.
The fitted value is only trustworthy if both fits are good (max relative error <= --max-err), it lies
inside the measured range, and it falls between "last loss" and "first win". On the M1 runs it often
does not: where the timing is not linear in n, fitted crossovers came out up to 8x too early. So
fit.json gives every crossover a status and a `report` value (the measured one when it exists),
and the plot marks measured crossovers.

fit.json:
  coefficients        machine -> config -> alpha, beta, eff_bw, fit errors, fit_ok
  crossovers          machine -> "gpu vs cpu" -> fitted n* or null (kept for older readers)
  crossovers_detail   machine -> "gpu vs cpu" -> fitted + measured estimates, statuses, report
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def load(path):
    return prepare(pd.read_csv(path))


def prepare(df):
    """Rows of one calibration CSV -> rows that passed the check, with t_us and config.
    Also used by analysis/model.py, which pools several runs."""
    bad = (df["ok"] == 0).sum()
    if bad:
        print(f"WARNING: dropping {bad} rows that failed the correctness check", file=sys.stderr)
        df = df[df["ok"] == 1]
    df = df.copy()
    df["t_us"] = df["t_total_us"] + df["t_wrap_us"]
    dev = pd.Series(np.where(df["device"] == "gpu", "gpu-" + df["state"], "cpu-" + df["qos"]), index=df.index)
    if "dispatch" in df:
        dev = dev.where(df["dispatch"] != "pipelined", dev + "-pipe")
    if "storage" in df:  # --storage private: blit into a private buffer, then the kernel
        dev = dev.where(df["storage"] != "private", dev + "-priv")
    if "gpu_spin_ms" in df:  # --gpu-spin-ms: GPU kept busy before each timed rep (busy clock regime)
        dev = dev.where(~((df["device"] == "gpu") & (df["gpu_spin_ms"] > 0)), dev + "-spin")
    if "gpu_final" in df:  # val_<query> --gpu-final 0: a diagnostic without the query's final pass
        dev = dev.where(~((df["device"] == "gpu") & (df["gpu_final"] == 0)), dev + "-nofinal")
    if "gpu_kernel" in df:  # val_<query>: partial kernel <query>_partial_<v>, a diagnostic variant (-<v>)
        variant = df["gpu_kernel"].astype(str).str.extract(r"_partial_(\w+)$", expand=False)
        dev = dev.where(~((df["device"] == "gpu") & variant.notna()), dev + "-" + variant)
    df["config"] = (df["data"] + "/" + dev) if "data" in df else dev
    # Keep cache-hot and cache-cold runs apart if one CSV holds both.
    if "cache" in df and df["cache"].nunique() > 1:
        df["config"] = df["config"] + "-" + df["cache"]
    # CPU rep 0 is the first touch of this n in this process; keep it out of the warm fit.
    df = df[~((df["device"] == "cpu") & (df["state"] == "first"))]
    return df


def medians(df):
    agg = df.groupby(["machine", "config", "n"]).agg(
        t_med=("t_us", "median"),
        t_q1=("t_us", lambda s: s.quantile(0.25)),
        t_q3=("t_us", lambda s: s.quantile(0.75)),
        gpu_exec_med=("gpu_exec_us", "median"),
        overhead_med=("t_total_us", "median"),
        reps=("t_us", "size"),
        bytes=("bytes", "first"),
    ).reset_index()
    # launch + sync overhead for GPU rows: host total minus GPU-side execution
    is_gpu = agg["config"].str.contains("gpu-")
    agg.loc[is_gpu, "overhead_med"] = agg.loc[is_gpu, "overhead_med"] - agg.loc[is_gpu, "gpu_exec_med"]
    agg.loc[~is_gpu, ["gpu_exec_med", "overhead_med"]] = np.nan
    return agg


def fit_linear_rel(n, t):
    """Least squares on relative error: minimise sum(((a + b n) - t) / t)^2."""
    A = np.stack([np.ones_like(n), n], axis=1) / t[:, None]
    y = np.ones_like(t)
    (a, b), *_ = np.linalg.lstsq(A, y, rcond=None)
    pred = a + b * n
    rel = np.abs(pred - t) / t
    return float(a), float(b), float(np.median(rel)), float(np.max(rel))


def fitted_crossover(g, c):
    """n* where the fitted GPU line drops below the fitted CPU line, or None if it never does."""
    if c["beta_us_per_elem"] <= g["beta_us_per_elem"]:
        return None
    n = (g["alpha_us"] - c["alpha_us"]) / (c["beta_us_per_elem"] - g["beta_us_per_elem"])
    return max(n, 0.0)


def measured_crossover(tg, tc):
    """Model-free crossover from medians. tg, tc: median time indexed by n (GPU, CPU)."""
    ns = sorted(set(tg.index) & set(tc.index))
    wins = [bool(tg[n] < tc[n]) for n in ns]
    first = next((i for i in range(len(ns)) if all(wins[i:])), None)
    m = {"n_min": int(ns[0]), "n_max": int(ns[-1]),
         "cpu_over_gpu_at_n_max": float(tc[ns[-1]] / tg[ns[-1]]),
         "measured_last_loss_n": None, "measured_first_win_n": None, "measured_interp_n": None}
    if first is None:
        m["measured_status"] = "gpu_never_wins_in_range"
    elif first == 0:
        m["measured_status"] = "gpu_wins_everywhere"
        m["measured_first_win_n"] = int(ns[0])
    else:
        lo, hi = ns[first - 1], ns[first]
        dlo, dhi = tg[lo] - tc[lo], tg[hi] - tc[hi]  # dlo >= 0 > dhi
        m.update(measured_status="in_range", measured_last_loss_n=int(lo), measured_first_win_n=int(hi),
                 measured_interp_n=float(lo + (hi - lo) * dlo / (dlo - dhi)))
    return m


def judge(x, fg, fc, m, max_err):
    """Status of a fitted crossover x, given both fits and the measured crossover m."""
    st = m["measured_status"]
    if st == "in_range":
        agrees = x is not None and m["measured_last_loss_n"] < x <= m["measured_first_win_n"]
    elif st == "gpu_never_wins_in_range":
        agrees = x is None or x > m["n_max"]
    else:
        agrees = x is not None and x <= m["n_min"]
    if x is None:
        status = "none"
    elif fg["max_rel_err"] > max_err or fc["max_rel_err"] > max_err:
        status = "poor_fit"
    elif not (m["n_min"] <= x <= m["n_max"]):
        status = "extrapolated"
    elif not agrees:
        status = "disagrees_with_measured"
    else:
        status = "ok"
    return status, agrees


def log2s(n):
    return f"2^{math.log2(n):.1f}" if n and n > 0 else "0"


def report(m):
    """What to quote: the measured crossover, or its absence within the measured range."""
    st = m["measured_status"]
    if st == "in_range":
        return m["measured_interp_n"], (f"{log2s(m['measured_interp_n'])} (measured: GPU slower at "
                                        f"{log2s(m['measured_last_loss_n'])}, faster from {log2s(m['measured_first_win_n'])} on)")
    if st == "gpu_wins_everywhere":
        return None, f"below {log2s(m['n_min'])} (GPU faster at every measured n)"
    r = m["cpu_over_gpu_at_n_max"]
    at_max = (f"GPU {1 / r:.2f}x the CPU time" if r < 1 else f"GPU faster ({r:.2f}x) but not at every smaller n")
    return None, f"none up to {log2s(m['n_max'])} (at {log2s(m['n_max'])}: {at_max})"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--plot", help="write crossover figure (pdf/png)")
    ap.add_argument("--max-err", type=float, default=0.2,
                    help="a fit with a larger max relative error is flagged poor (default 0.2)")
    args = ap.parse_args()

    df = load(args.csv)
    med = medians(df)

    coeffs = {}
    for (machine, config), g in med.groupby(["machine", "config"]):
        n = g["n"].to_numpy(float)
        t = g["t_med"].to_numpy(float)
        a, b, mre, maxre = fit_linear_rel(n, t)
        bpe = float((g["bytes"] / g["n"]).median())  # bytes read per element (filter 4, grouped agg 8)
        coeffs.setdefault(machine, {})[config] = {
            "alpha_us": a,
            "beta_us_per_elem": b,
            "bytes_per_elem": bpe,
            "eff_bw_GBps": (bpe / (b * 1e3)) if b > 0 else None,
            "median_rel_err": mre,
            "max_rel_err": maxre,
            "fit_ok": maxre <= args.max_err,
            "points": int(len(g)),
        }

    out = {"settings": {"max_err": args.max_err}, "coefficients": coeffs, "crossovers": {}, "crossovers_detail": {}}
    lines = []
    for machine, cfgs in coeffs.items():
        mm = med[med["machine"] == machine]
        for gk in [k for k in cfgs if "gpu-" in k]:
            for ck in [k for k in cfgs if "cpu-" in k and k.split("/")[0] == gk.split("/")[0]]:
                x = fitted_crossover(cfgs[gk], cfgs[ck])
                tg = mm[mm["config"] == gk].set_index("n")["t_med"]
                tc = mm[mm["config"] == ck].set_index("n")["t_med"]
                m = measured_crossover(tg, tc)
                status, agrees = judge(x, cfgs[gk], cfgs[ck], m, args.max_err)
                rep_n, rep_text = report(m)
                key = f"{gk} vs {ck}"
                out["crossovers"].setdefault(machine, {})[key] = x
                out["crossovers_detail"].setdefault(machine, {})[key] = {
                    "fitted_n": x, "fitted_status": status, "fitted_agrees_with_measured": agrees,
                    **m, "report_n": rep_n, "report": rep_text}
                lines.append((key, rep_text, "-" if x is None else log2s(x), status))

    print(json.dumps(out, indent=2))
    out_path = Path(args.csv).with_name("fit.json")
    out_path.write_text(json.dumps(out, indent=2))
    med.to_csv(Path(args.csv).with_name("medians.csv"), index=False)
    print(f"-> {out_path}", file=sys.stderr)

    poor = [(k, round(v["max_rel_err"], 2)) for cf in coeffs.values() for k, v in cf.items() if not v["fit_ok"]]
    if poor:
        print(f"fits with max relative error > {args.max_err}: " + ", ".join(f"{k} ({e})" for k, e in poor),
              file=sys.stderr)
    print("crossovers (report = measured; fitted shown with its status):", file=sys.stderr)
    for key, rep_text, fx, status in lines:
        print(f"  {key}\n      report: {rep_text}\n      fitted: {fx} [{status}]", file=sys.stderr)

    if args.plot:
        plot(df, med, coeffs, out["crossovers_detail"], args.plot)


def plot(df, med, coeffs, details, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    op = "/".join(sorted(df["op"].unique())) if "op" in df else "operator"
    panels = sorted({(m, c.split("/")[0]) for m, c in zip(med["machine"], med["config"])})
    ncol = min(3, len(panels))
    nrow = math.ceil(len(panels) / ncol)
    fig, axes = plt.subplots(nrow, ncol, figsize=(4.6 * ncol, 3.6 * nrow), squeeze=False)
    for ax, (machine, data) in zip(axes.flat, panels):
        m = med[(med["machine"] == machine) & (med["config"].str.split("/").str[0] == data)]
        colors = {}
        for config, g in m.groupby("config"):
            g = g.sort_values("n")
            line, = ax.plot(g["n"], g["t_med"], "o", ms=3, label=config.split("/", 1)[-1])
            colors[config] = line.get_color()
            c = coeffs[machine][config]
            nn = np.logspace(np.log10(g["n"].min()), np.log10(g["n"].max()), 100)
            ax.plot(nn, c["alpha_us"] + c["beta_us_per_elem"] * nn, "-" if c["fit_ok"] else ":",
                    lw=1, color=line.get_color())
        for key, d in details.get(machine, {}).items():
            gk = key.split(" vs ")[0]
            if gk.split("/")[0] == data and d["measured_status"] == "in_range":
                ax.axvline(d["measured_interp_n"], ls="--", lw=0.7, color=colors.get(gk, "grey"), alpha=0.6)
        ax.set_xscale("log", base=2)
        ax.set_yscale("log")
        ax.set_xlabel("morsel size n (rows)")
        ax.set_ylabel("time per morsel (µs)")
        ax.set_title(f"{data} — {machine}", fontsize=9)
        ax.legend(fontsize=6)
    for ax in list(axes.flat)[len(panels):]:
        ax.axis("off")
    fig.suptitle(f"{op}: medians (dots), fits (solid; dotted = poor fit), measured GPU/CPU crossovers (dashed)",
                 fontsize=9)
    fig.tight_layout()
    fig.savefig(path)
    print(f"-> {path}", file=sys.stderr)


if __name__ == "__main__":
    main()
