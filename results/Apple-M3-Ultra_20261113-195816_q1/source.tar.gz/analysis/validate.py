"""Shared scoring of the held-out query validations (analysis/predict_q1.py, analysis/predict_q6.py).

A query's predictor turns models/<machine>.json into one prediction (alpha, beta[, k]) per (rule,
device config): T = max(alpha, beta n) + k min(alpha, beta n), which is the line alpha + beta n for
k = 1 (the default; CPU and sync GPU) and lets a pipelined GPU morsel hide part of its launch behind
the previous one for k < 1 (models/<machine>.json overlap). This module loads the query runs, fits the
query's own line per device (the best any alpha + beta * n model could do; not a prediction) and
scores every rule: the prediction error over
every (run, n) median per device, the placement accuracy of the routers (over all (run, n), how often
the device the rule predicts fastest is the one measured fastest) and the predicted against the
measured GPU/CPU crossovers.
"""
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fit  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DEVICES = ["cpu-p", "cpu-e", "gpu-warm", "gpu-warm-pipe", "gpu-warm-spin", "gpu-warm-pipe-spin"]
ROUTERS = {"sync": ["cpu-p", "cpu-e", "gpu-warm"], "pipelined": ["cpu-p", "cpu-e", "gpu-warm-pipe"],
           "sync-spin": ["cpu-p", "cpu-e", "gpu-warm-spin"], "pipelined-spin": ["cpu-p", "cpu-e", "gpu-warm-pipe-spin"]}


def load_runs(paths):
    """Per-run medians per (device config, n) of the query CSVs; config = device config only."""
    meds = []
    for p in paths:
        df = fit.prepare(pd.read_csv(p))
        df["dev"] = df["config"].str.split("/", n=1).str[1]  # fit.prepare adds -spin for busy-GPU rows
        df["config"] = df["dev"]
        m = fit.medians(df)
        m["run"] = Path(p).parent.name
        meds.append(m)
    return pd.concat(meds, ignore_index=True)


def pick(model, op, dev, regime="auto"):
    """The calibrated config of `op` for the query's device config `dev`, and its name. regime auto:
    the same clock regime as the query runs when the model has it (a -spin config uses the busy-GPU
    calibration), else the idle one; regime idle: always the idle calibration."""
    cfgs = model["ops"][op]["configs"]
    if regime == "auto" and dev in cfgs:
        return cfgs[dev], dev
    return cfgs[dev.removesuffix("-spin")], dev.removesuffix("-spin")


PIPE_FORMS = ["overlap", "max", "line", "fit"]


def pipe_coef(entry, dev, pipe_form="overlap"):
    """(beta_us_per_elem, k) a predictor takes from the calibrated config `entry` for the query's device
    config dev. Pipelined GPU configs (-pipe) take the slope over the largest calibrated morsels
    (large_n), and k: the config's own overlap.k (pipe_form overlap), 0 (max: the launch hidden
    completely) or 1 (line: alpha + beta n). pipe_form fit, and every config not pipelined: the
    full-range line, k = 1 (the predictions before the overlap form)."""
    if "-pipe" not in dev or pipe_form == "fit":
        return entry["beta_us_per_elem"], 1.0
    k = {"overlap": entry["overlap"]["k"], "max": 0.0, "line": 1.0}[pipe_form]
    return entry["large_n"]["beta_us_per_elem"], k


def evaluate(p, n):
    """Predicted time of p = (alpha_us, beta_us_per_row[, k]) at n (k = 1, the line, if absent)."""
    a, b, k = p if len(p) == 3 else (*p, 1.0)
    return np.maximum(a, b * n) + k * np.minimum(a, b * n)


def crossover(g, c):
    """n from which the GPU prediction g is below the CPU line c; None if g's per-row cost is not lower.
    g is the larger of the lines a + k b n and k a + b n, so both must be below c."""
    ga, gb, k = g if len(g) == 3 else (*g, 1.0)
    ca, cb = c[:2]
    if cb <= gb:
        return None
    return max((ga - ca) / (cb - k * gb), (k * ga - ca) / (cb - gb))


def query_fit(meds, dev):
    """alpha_us, beta_us_per_row of a line fitted on the query's own pooled medians of `dev`."""
    g = meds[meds["config"] == dev]
    a, b, _, _ = fit.fit_linear_rel(g.groupby("n")["t_med"].median().index.values.astype(float),
                                    g.groupby("n")["t_med"].median().values.astype(float))
    return a, b


def l2(x):
    return f"2^{math.log2(x):.1f}" if x else "none"


def score(meds, devs, pred, rules, predictive, err=sys.stderr):
    """Scores pred[(rule, dev)] = (alpha_us, beta_us_per_row[, k]) for every rule in `rules` against
    the medians and prints the error and placement table, then the crossovers (predicted for the rules
    in `predictive` only). A router is scored only when its GPU config was measured: without it, it
    would only rank the CPU workers. Returns (rules, crossovers) for the JSON."""
    out = {}
    for r in rules:
        res = {"devices": {}, "placement": {}}
        for d in devs:
            g = meds[meds["config"] == d]
            p = pred[(r, d)]
            rel = (evaluate(p, g["n"].values) - g["t_med"].values) / g["t_med"].values
            res["devices"][d] = {"alpha_us": p[0], "beta_ns_per_row": p[1] * 1e3, "k": p[2] if len(p) == 3 else 1.0,
                                 "err_median": float(np.median(np.abs(rel))),
                                 "err_p90": float(np.quantile(np.abs(rel), 0.9)),
                                 "bias_median": float(np.median(rel))}
        for name, cand in ROUTERS.items():
            cand = [d for d in cand if d in devs]
            if len(cand) < 2 or not any(d.startswith("gpu") for d in cand):
                continue
            piv = meds[meds["config"].isin(cand)].pivot_table(index=["run", "n"], columns="config", values="t_med")
            piv = piv.dropna()
            measured_best = piv.idxmin(axis=1)
            ns = piv.index.get_level_values("n").values.astype(float)
            pt = pd.DataFrame({d: evaluate(pred[(r, d)], ns) for d in cand}, index=piv.index)
            predicted_best = pt.idxmin(axis=1)
            hit = (measured_best == predicted_best)
            # cost of a wrong pick: measured time of the predicted device / measured best time
            regret = np.array([piv.loc[i, predicted_best[i]] / piv.loc[i, measured_best[i]] for i in piv.index])
            res["placement"][name] = {"accuracy": float(hit.mean()), "points": int(hit.size),
                                      "mean_slowdown_when_wrong": float(regret[~hit.values].mean()) if (~hit).any() else 1.0,
                                      "max_slowdown": float(regret.max())}
        out[r] = res

    placed = [k for k in ROUTERS if k in out[rules[0]]["placement"]]
    print(f"\n{'rule':10s} " + " ".join(f"{d:>22s}" for d in devs) + "   placement: " + "  ".join(placed), file=err)
    for r in rules:
        res = out[r]
        cells = " ".join(f"{res['devices'][d]['err_median']:>9.0%} med {res['devices'][d]['err_p90']:>5.0%} p90"
                         for d in devs)
        pl = res["placement"]
        acc = "  ".join(f"{pl[k]['accuracy']:>{len(k)}.0%}" for k in placed)
        print(f"{r:10s} {cells}   {acc}", file=err)
    print("(error = |predicted - measured| / measured over every (run, n) median)", file=err)

    # Measured vs predicted GPU/CPU crossovers on the pooled medians.
    pooled = meds.groupby(["config", "n"])["t_med"].median()
    print("\ncrossovers (GPU faster from):", file=err)
    crossovers = {}
    for gk in [d for d in devs if d.startswith("gpu")]:
        for ck in [d for d in devs if d.startswith("cpu")]:
            m = fit.measured_crossover(pooled[gk], pooled[ck])
            _, text = fit.report(m)
            row = {"measured": text, "measured_n": m["measured_interp_n"]}
            for r in predictive:
                row[r] = crossover(pred[(r, gk)], pred[(r, ck)])
            crossovers[f"{gk} vs {ck}"] = row
            print(f"  {gk:14s} vs {ck}: measured {text}; predicted " +
                  ", ".join(f"{r} {l2(row[r])}" for r in predictive), file=err)
    return out, crossovers
