#!/usr/bin/env bash
# Held-out query validation sweep (QUERY=q1 or q6; usually run as scripts/run_val_q1.sh or
# scripts/run_val_q6.sh): per-morsel times of the fused query kernel on the GPU (sync and pipelined
# dispatch), one P-core and one E-core worker. Held out: the model is never fitted on these runs;
# they test it (analysis/predict_<query>.py). Results go to results/<machine>_<date-time>_<query>/.
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_val_q1.sh                                  # SF10
#   DATA=data/tpch-sf1 scripts/run_val_q6.sh
#   MAX_LOG2=20 REPS=5 COOLDOWN=2 scripts/run_val_q1.sh    # quick smoke run
#   SPIN=20 scripts/run_val_q6.sh                          # keep the GPU busy ~20 ms before each timed rep
#   GPU_GROUPS="128 1024 4096" CPUS= scripts/run_val_q1.sh # GPU grid-size test: one CSV per cap
#   GPU_FINAL="1 0" CPUS= SPIN=20 scripts/run_val_q1.sh    # diagnostic: GPU morsels with and without the final pass
#   GPU_LOADS="eager dependent" CPUS= SPIN=20 scripts/run_val_q1.sh  # diagnostic: Q1's kernel and q1_partial_dependent
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

QUERY="${QUERY:?set QUERY=q1 or q6, or run scripts/run_val_q1.sh / scripts/run_val_q6.sh}"
case "$QUERY" in q1|q6) ;; *) echo "unknown QUERY=$QUERY (q1 or q6)" >&2; exit 1 ;; esac
BIN="build/val_$QUERY"
DATA="${DATA:-data/tpch-sf10}"
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-25}"
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"
CACHE="${CACHE:-cold}"
DISPATCH="${DISPATCH:-sync pipelined}"
BATCH="${BATCH:-16}"         # morsels per pipelined batch (capped at 1 GiB of input)
SPIN="${SPIN:-0}"            # ms of ALU-only GPU work before each timed GPU rep (GPU clock up)
GPU_GROUPS="${GPU_GROUPS:-}" # max threadgroups per GPU morsel (--gpu-groups); empty: the query's default.
                             # Several values: each runs every DISPATCH into its own val_<query>_g<G>.csv
CPUS="${CPUS-p e}"           # CPU workers after the GPU configs (P, E); CPUS= runs the GPU only
GPU_FINAL="${GPU_FINAL:-1}"  # --gpu-final per GPU config: 1 (the query); 0, a diagnostic without the final
                             # pass. Several values run each in turn into the same CSV (column gpu_final)
GPU_LOADS="${GPU_LOADS:-eager}"  # q1 only, --gpu-loads per GPU config: eager (the query's kernel); dependent,
                             # a diagnostic, the kernel before 13 Nov 2026 (l_returnflag and l_linestatus
                             # loaded after the shipdate test). Several values run each in turn into the
                             # same CSV (column gpu_kernel)

if [[ $QUERY != q1 && $GPU_LOADS != eager ]]; then echo "GPU_LOADS applies to QUERY=q1 only" >&2; exit 1; fi
loads() { if [[ $QUERY == q1 ]]; then echo "--gpu-loads $1"; fi; }  # val_q6 has no --gpu-loads

[[ -f "$DATA/l_shipdate.u32" ]] || { echo "missing $DATA — run: python3 scripts/gen_tpch.py --sf 10"; exit 1; }
[[ -f "$DATA/${QUERY}_expected.txt" ]] ||
  echo "note: no $DATA/${QUERY}_expected.txt, so no check against DuckDB; run: python3 scripts/tpch_reference.py --data $DATA"

sweep_begin "$QUERY"
sweep_settings "QUERY=$QUERY DATA=$DATA MIN_LOG2=$MIN_LOG2 MAX_LOG2=$MAX_LOG2 REPS=$REPS CACHE=$CACHE DISPATCH='$DISPATCH'" \
               "BATCH=$BATCH SPIN=$SPIN COOLDOWN=$COOLDOWN GPU_GROUPS='$GPU_GROUPS' CPUS='$CPUS' GPU_FINAL='$GPU_FINAL'" \
               "GPU_LOADS='$GPU_LOADS'"
csv="$dir/val_$QUERY.csv"
common=(--data "$DATA" --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2" --reps "$REPS" --cache "$CACHE")
json=(--machine-json "$dir/machine.json")

first=1
bench() {  # bench <out.csv> <args...>: one configuration, after a cool-down unless it is the first
  local out="$1"
  shift
  if [[ $first == 1 ]]; then first=0; else sleep "$COOLDOWN"; fi
  "$BIN" "$@" "${common[@]}" --out "$out" ${json[@]+"${json[@]}"}
  json=()
}

if [[ -z "$GPU_GROUPS" ]]; then
  for d in $DISPATCH; do
    for f in $GPU_FINAL; do
      for l in $GPU_LOADS; do
        bench "$csv" --device gpu --dispatch "$d" --batch "$BATCH" --gpu-spin-ms "$SPIN" --gpu-final "$f" $(loads "$l")
      done
    done
  done
else
  several=0
  if [[ "$(echo $GPU_GROUPS | wc -w | tr -d ' ')" -gt 1 ]]; then several=1; fi
  for g in $GPU_GROUPS; do
    out="$csv"
    if [[ $several == 1 ]]; then out="$dir/val_${QUERY}_g$g.csv"; fi
    for d in $DISPATCH; do
      for f in $GPU_FINAL; do
        for l in $GPU_LOADS; do
          bench "$out" --device gpu --dispatch "$d" --batch "$BATCH" --gpu-spin-ms "$SPIN" --gpu-groups "$g" \
                --gpu-final "$f" $(loads "$l")
        done
      done
    done
  done
fi
for q in $CPUS; do bench "$csv" --device cpu --qos "$q"; done

echo "done -> $dir"
echo "next:  python3 analysis/predict_$QUERY.py $csv"
