#!/usr/bin/env bash
# One full calibration round on this machine: the filter, agg, contention, sort and join sweeps
# (scripts/run_calib_*.sh with their defaults: SF10, GPU kept busy), one after another. A failing
# sweep is reported and the round goes on. For a long unattended run:
#
#   nohup caffeinate -is scripts/run_calibration.sh > calibration.log 2>&1 &
#   MCM_FLUSH_MB=512 THREADS="1 2 4 8 16 24" scripts/run_calibration.sh   # M3 Ultra: larger SLC, more cores
set -uo pipefail
cd "$(dirname "$0")/.."

DATA="${DATA:-data/tpch-sf10}"
status=0
run() {
  echo "== $(date '+%F %T') start: $*"
  "$@"
  local rc=$?
  echo "== $(date '+%F %T') exit $rc: $*"
  [[ $rc -eq 0 ]] || status=1
  sleep 30
}

echo "== machine: $(sysctl -n machdep.cpu.brand_string) | flush ${MCM_FLUSH_MB:-64} MB | load $(uptime | sed 's/.*load average[s]*: //')"
run env COLUMN="$DATA/l_quantity.u32" scripts/run_calib_filter.sh
run env DATA="$DATA" scripts/run_calib_agg.sh
run scripts/run_calib_contention.sh
run env DATA="$DATA" scripts/run_calib_sort.sh
run env DATA="$DATA" scripts/run_calib_join.sh
echo "== $(date '+%F %T') calibration round done (status $status)"
exit $status
