#!/usr/bin/env bash
# Full calib_sort sweep: per-morsel radix sort of (key, row id) pairs on the GPU (warm and cold, kept
# busy), one P-core and one E-core; std::sort on the P-core as the comparison-sort reference; the CPU
# merge of k sorted runs. Results go to results/<machine>_<date-time>_sort/.
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_calib_sort.sh                                   # SF10 keys + uniform random keys
#   KEYS="random l_partkey" scripts/run_calib_sort.sh
#   MAX_LOG2=18 REPS=3 COOLDOWN=1 scripts/run_calib_sort.sh     # quick smoke run
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

BIN=build/calib_sort
DATA="${DATA:-data/tpch-sf10}"
KEYS="${KEYS:-random l_partkey l_shipdate l_orderkey}"   # random = uniform 32-bit keys
MERGE_KEYS="${MERGE_KEYS:-random}"
MERGE_RUNS="${MERGE_RUNS:-4 16 64}"
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-25}"
STD_MAX_LOG2="${STD_MAX_LOG2:-22}"     # std::sort is n log n: cap its sweep
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"
CACHE="${CACHE:-cold}"
SPIN="${SPIN:-20}"                     # ms of ALU-only GPU work before each timed GPU rep (busy regime)

sweep_begin sort
sweep_settings "DATA=$DATA KEYS='$KEYS' MERGE_KEYS='$MERGE_KEYS' MERGE_RUNS='$MERGE_RUNS' MIN_LOG2=$MIN_LOG2" \
               "MAX_LOG2=$MAX_LOG2 STD_MAX_LOG2=$STD_MAX_LOG2 REPS=$REPS CACHE=$CACHE SPIN=$SPIN COOLDOWN=$COOLDOWN"
csv="$dir/calib_sort.csv"
json=(--machine-json "$dir/machine.json")

keyarg() { if [[ "$1" == random ]]; then echo "--random"; else echo "--keys $DATA/$1.u32"; fi; }
run() {
  # shellcheck disable=SC2086
  "$BIN" "$@" --reps "$REPS" --cache "$CACHE" --out "$csv" ${json[@]+"${json[@]}"}
  json=()
  sleep "$COOLDOWN"
}

for k in $KEYS; do
  # shellcheck disable=SC2046
  for s in warm cold; do run --device gpu --state "$s" --gpu-spin-ms "$SPIN" $(keyarg "$k") --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2"; done
  for q in p e; do run --device cpu --qos "$q" $(keyarg "$k") --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2"; done
  run --device cpu --qos p --algo std $(keyarg "$k") --min-log2 "$MIN_LOG2" --max-log2 "$STD_MAX_LOG2"
done
for k in $MERGE_KEYS; do
  for r in $MERGE_RUNS; do
    # shellcheck disable=SC2046
    for q in p e; do run --device cpu --qos "$q" --mode merge --runs "$r" $(keyarg "$k") --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2"; done
  done
done

echo "done -> $dir"
echo "next:  python3 analysis/fit.py $csv --plot $dir/crossover.pdf"
