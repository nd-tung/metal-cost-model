#!/usr/bin/env bash
# Full calib_join sweep: hash-join probe and build at TPC-H's natural build sizes, on the GPU (warm and
# cold; probes sync and pipelined; GPU kept busy), one P-core and one E-core.
# Results go to results/<machine>_<date-time>_join/.
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_calib_join.sh                                   # SF10, every join configuration
#   JOINS="supplier part" PHASES=probe scripts/run_calib_join.sh
#   DATA=data/tpch-sf1 MAX_LOG2=18 REPS=3 COOLDOWN=1 scripts/run_calib_join.sh   # quick smoke run
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

BIN=build/calib_join
DATA="${DATA:-data/tpch-sf10}"
JOINS="${JOINS:-nation supplier customer part part_promo orders}"
PHASES="${PHASES:-probe build}"
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-25}"
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"
CACHE="${CACHE:-cold}"
DISPATCH="${DISPATCH:-sync pipelined}"   # probe only; builds are sync
BATCH="${BATCH:-16}"
SPIN="${SPIN:-20}"                       # ms of ALU-only GPU work before each timed GPU rep (busy regime)

# name -> build key, payload, build filter (- = none), probe key. Must match JOINS in scripts/tpch_reference.py.
join_cols() {
  case "$1" in
    nation)     echo "n_nationkey n_regionkey - c_nationkey" ;;
    supplier)   echo "s_suppkey s_nationkey - l_suppkey" ;;
    customer)   echo "c_custkey c_nationkey - o_custkey" ;;
    part)       echo "p_partkey p_retailprice - l_partkey" ;;
    part_promo) echo "p_partkey p_retailprice p_promo l_partkey" ;;
    orders)     echo "o_orderkey o_custkey - l_orderkey" ;;
    *) echo "unknown join $1" >&2; return 1 ;;
  esac
}

[[ -f "$DATA/s_suppkey.u32" ]] || { echo "missing join columns in $DATA — run: python3 scripts/gen_tpch.py --sf 10"; exit 1; }
[[ -f "$DATA/join_expected.txt" ]] ||
  echo "note: no $DATA/join_expected.txt, so no check against DuckDB; run: python3 scripts/tpch_reference.py --data $DATA"

sweep_begin join
sweep_settings "DATA=$DATA JOINS='$JOINS' PHASES='$PHASES' MIN_LOG2=$MIN_LOG2 MAX_LOG2=$MAX_LOG2 REPS=$REPS" \
               "CACHE=$CACHE DISPATCH='$DISPATCH' BATCH=$BATCH SPIN=$SPIN COOLDOWN=$COOLDOWN"
csv="$dir/calib_join.csv"
json=(--machine-json "$dir/machine.json")

for j in $JOINS; do
  read -r bk pay filt pk <<< "$(join_cols "$j")"
  cols=(--name "$j" --build "$DATA/$bk.u32" --payload "$DATA/$pay.u32" --probe "$DATA/$pk.u32")
  [[ "$filt" != "-" ]] && cols+=(--filter "$DATA/$filt.u32")
  common=("${cols[@]}" --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2" --reps "$REPS" --cache "$CACHE" --out "$csv")
  for ph in $PHASES; do
    cfgs=()
    if [[ "$ph" == probe ]]; then
      for d in $DISPATCH; do
        for s in warm cold; do cfgs+=("gpu --state $s --dispatch $d --batch $BATCH --gpu-spin-ms $SPIN"); done
      done
    else
      for s in warm cold; do cfgs+=("gpu --state $s --gpu-spin-ms $SPIN"); done
    fi
    cfgs+=("cpu --qos p" "cpu --qos e")
    for cfg in "${cfgs[@]}"; do
      # shellcheck disable=SC2086
      "$BIN" --phase "$ph" --device $cfg "${common[@]}" ${json[@]+"${json[@]}"}
      json=()
      sleep "$COOLDOWN"
    done
  done
done

echo "done -> $dir"
echo "next:  python3 analysis/fit.py $csv --plot $dir/crossover.pdf"
