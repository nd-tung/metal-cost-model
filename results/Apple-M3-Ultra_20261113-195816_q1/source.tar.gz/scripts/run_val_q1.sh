#!/usr/bin/env bash
# Q1 validation sweep: scripts/run_val_query.sh with QUERY=q1 (settings and examples there).
#   scripts/run_val_q1.sh            SPIN=20 scripts/run_val_q1.sh
exec env QUERY=q1 "$(dirname "$0")/run_val_query.sh" "$@"
