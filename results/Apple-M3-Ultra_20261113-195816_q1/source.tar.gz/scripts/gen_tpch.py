#!/usr/bin/env python3
"""Generate TPC-H with DuckDB and export columns as raw binary arrays.

usage: python3 scripts/gen_tpch.py --sf 1 [--out data/tpch-sf1] [--force]

Output (one file per column, little-endian, no header):
  <col>.u32       uint32 values, one per row of the column's table
  manifest.json   per table: row count; per column: file, min/max, distinct count

Exported: the lineitem columns in (l_orderkey, l_linenumber) order, and the join columns of nation,
supplier, customer, part and orders, each in primary-key order. A column file that already exists
is kept (its manifest entry too) unless --force is given.

Encodings (all fit uint32 so every kernel reads the same element type):
  DATE columns     -> days since 1970-01-01
  DECIMAL(15,2)    -> value * 100 (exact integer cents)
  CHAR(1) flags    -> ASCII code
  l_shipmode       -> dictionary code 0..6 (dictionary stored in manifest)
  p_promo          -> 1 if p_type LIKE 'PROMO%' (Q14's build-side filter), else 0
  keys             -> as is

The DuckDB database file is kept as well (tpch.duckdb) so the DuckDB CPU-only
baseline runs on exactly the same data.
"""
import argparse
import json
import time
from pathlib import Path

import duckdb
import numpy as np

COLUMNS = {
    # name: SQL expression producing a non-negative integer < 2^32
    "l_orderkey":      "l_orderkey",
    "l_partkey":       "l_partkey",
    "l_suppkey":       "l_suppkey",
    "l_quantity":      "CAST(l_quantity * 100 AS UBIGINT)",
    "l_extendedprice": "CAST(l_extendedprice * 100 AS UBIGINT)",
    "l_discount":      "CAST(l_discount * 100 AS UBIGINT)",
    "l_tax":           "CAST(l_tax * 100 AS UBIGINT)",
    "l_returnflag":    "ascii(l_returnflag)",
    "l_linestatus":    "ascii(l_linestatus)",
    "l_shipdate":      "CAST(l_shipdate - DATE '1970-01-01' AS UBIGINT)",
    "l_commitdate":    "CAST(l_commitdate - DATE '1970-01-01' AS UBIGINT)",
    "l_receiptdate":   "CAST(l_receiptdate - DATE '1970-01-01' AS UBIGINT)",
    "l_shipmode":      "shipmode_code",
}

# Join columns of the build-side tables: table -> (ORDER BY, {name: SQL expression}).
TABLES = {
    "nation":   ("n_nationkey", {"n_nationkey": "n_nationkey", "n_regionkey": "n_regionkey"}),
    "supplier": ("s_suppkey", {"s_suppkey": "s_suppkey", "s_nationkey": "s_nationkey"}),
    "customer": ("c_custkey", {"c_custkey": "c_custkey", "c_nationkey": "c_nationkey"}),
    "part":     ("p_partkey", {"p_partkey": "p_partkey",
                               "p_retailprice": "CAST(p_retailprice * 100 AS UBIGINT)",
                               "p_promo": "CAST(p_type LIKE 'PROMO%' AS UBIGINT)"}),
    "orders":   ("o_orderkey", {"o_orderkey": "o_orderkey", "o_custkey": "o_custkey"}),
}


def export(con, out, table, order_by, name, expr, old, force):
    """Writes <name>.u32 (unless it exists and is in the old manifest) and returns its manifest entry."""
    path = out / f"{name}.u32"
    if path.exists() and not force and name in old:
        print(f"  {name:16s} kept")
        return old[name]
    arr = con.execute(f"SELECT {expr} AS v FROM {table} ORDER BY {order_by}").fetchnumpy()["v"]
    if arr.max() >= 2**32:
        raise SystemExit(f"{name} does not fit uint32")
    arr = np.ascontiguousarray(arr.astype("<u4"))
    arr.tofile(path)
    entry = {"file": path.name, "min": int(arr.min()), "max": int(arr.max()), "distinct": int(len(np.unique(arr)))}
    print(f"  {name:16s} distinct={entry['distinct']:>9d}")
    return entry


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sf", type=float, default=1.0)
    ap.add_argument("--out", default=None)
    ap.add_argument("--force", action="store_true", help="re-export column files that already exist")
    args = ap.parse_args()

    sf_tag = f"{args.sf:g}"
    out = Path(args.out or f"data/tpch-sf{sf_tag}")
    out.mkdir(parents=True, exist_ok=True)
    db_path = out / "tpch.duckdb"
    old = json.loads((out / "manifest.json").read_text()) if (out / "manifest.json").exists() else {}
    old_cols = dict(old.get("columns", {}))
    for t in old.get("tables", {}).values():
        old_cols.update(t.get("columns", {}))

    con = duckdb.connect(str(db_path))
    have = con.execute(
        "SELECT count(*) FROM information_schema.tables WHERE table_name = 'lineitem'"
    ).fetchone()[0]
    if not have:
        con.execute("INSTALL tpch; LOAD tpch;")
        t0 = time.time()
        print(f"generating TPC-H SF{sf_tag} ...")
        con.execute(f"CALL dbgen(sf={args.sf})")
        print(f"  done in {time.time() - t0:.1f}s")
    else:
        print(f"reusing existing {db_path}")

    modes = [r[0] for r in con.execute(
        "SELECT DISTINCT l_shipmode FROM lineitem ORDER BY 1").fetchall()]
    case = " ".join(f"WHEN '{m}' THEN {i}" for i, m in enumerate(modes))

    nrows = con.execute("SELECT count(*) FROM lineitem").fetchone()[0]
    manifest = {"sf": args.sf, "rows": nrows, "dtype": "uint32", "columns": {},
                "shipmode_dictionary": modes, "tables": {}}

    # lineitem in a stable physical order (orderkey, linenumber) so runs are reproducible.
    for name, expr in COLUMNS.items():
        e = expr.replace("shipmode_code", f"CASE l_shipmode {case} END")
        manifest["columns"][name] = export(con, out, "lineitem", "l_orderkey, l_linenumber", name, e,
                                           old_cols, args.force)
    for table, (order_by, cols) in TABLES.items():
        rows = con.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
        manifest["tables"][table] = {"rows": rows, "columns": {
            name: export(con, out, table, order_by, name, expr, old_cols, args.force) for name, expr in cols.items()}}
        print(f"  {table}: {rows} rows")

    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"{nrows} lineitem rows -> {out}")


if __name__ == "__main__":
    main()
