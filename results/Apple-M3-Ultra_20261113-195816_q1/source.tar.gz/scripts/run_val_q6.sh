#!/usr/bin/env bash
# Q6 validation sweep: scripts/run_val_query.sh with QUERY=q6 (settings and examples there).
#   scripts/run_val_q6.sh            SPIN=20 scripts/run_val_q6.sh
exec env QUERY=q6 "$(dirname "$0")/run_val_query.sh" "$@"
