#!/usr/bin/env python3
"""Exact TPC-H answers from DuckDB, in the integer encodings of scripts/gen_tpch.py, so the engine's
results can be checked exactly. Also times DuckDB on the official query text (informational only:
the DuckDB baseline has its own protocol in the evaluation).

usage: python3 scripts/tpch_reference.py --data data/tpch-sf10 [--runs 5]

Writes <data>/join_expected.txt, one line per join configuration of calib_join (JOINS below):
  name build_rows matches payload_sum_mod_2^32
build_rows counts the build rows after the build-side filter; matches and the payload sum are over
the whole probe column (count(*) and sum(payload) of the equi-join; sums wrap mod 2^32 like the
kernels' uint32 sums).

Writes <data>/q1_expected.txt, one line per group in ORDER BY l_returnflag, l_linestatus:
  returnflag linestatus count sum_qty sum_base_price sum_disc_price sum_charge sum_disc
Flags are ASCII codes. Sums are over the x100 integers of gen_tpch.py: sum_qty, sum_base_price and
sum_disc are x100, sum_disc_price = sum(price * (100 - disc)) is x10^4, and
sum_charge = sum(price * (100 - disc) * (100 + tax)) is x10^6. The averages of Q1 follow from these
and count.

Writes <data>/q6_expected.txt, one line:
  count revenue
count is the number of rows that pass Q6's filter, revenue = sum(price * disc) over the x100
integers (x10^4).
"""
import argparse
import statistics
import time
from pathlib import Path

import duckdb

Q1_CUTOFF_DAYS = 10471  # DATE '1998-12-01' - INTERVAL 90 DAY, as days since 1970-01-01
Q6_DATES_DAYS = (8766, 9131)  # DATE '1994-01-01' and '1995-01-01', as days since 1970-01-01

Q1_EXACT = """
SELECT ascii(l_returnflag) AS rf, ascii(l_linestatus) AS ls, count(*) AS cnt,
       sum(CAST(l_quantity * 100 AS HUGEINT)) AS sum_qty,
       sum(CAST(l_extendedprice * 100 AS HUGEINT)) AS sum_base_price,
       sum(CAST(l_extendedprice * 100 AS HUGEINT) * (100 - CAST(l_discount * 100 AS HUGEINT))) AS sum_disc_price,
       sum(CAST(l_extendedprice * 100 AS HUGEINT) * (100 - CAST(l_discount * 100 AS HUGEINT))
           * (100 + CAST(l_tax * 100 AS HUGEINT))) AS sum_charge,
       sum(CAST(l_discount * 100 AS HUGEINT)) AS sum_disc
FROM lineitem
WHERE l_shipdate <= DATE '1998-12-01' - INTERVAL 90 DAY
GROUP BY ALL
ORDER BY rf, ls
"""

Q6_WHERE = """
WHERE l_shipdate >= DATE '1994-01-01' AND l_shipdate < DATE '1994-01-01' + INTERVAL 1 YEAR
  AND l_discount BETWEEN 0.06 - 0.01 AND 0.06 + 0.01 AND l_quantity < 24
"""

Q6_EXACT = """
SELECT count(*) AS cnt,
       coalesce(sum(CAST(l_extendedprice * 100 AS HUGEINT) * CAST(l_discount * 100 AS HUGEINT)), 0) AS revenue
FROM lineitem
""" + Q6_WHERE

Q6_OFFICIAL = "SELECT sum(l_extendedprice * l_discount) AS revenue FROM lineitem" + Q6_WHERE

# calib_join configurations (scripts/run_calib_join.sh uses the same names):
# name -> (build table, build key, payload, build filter or None, probe table, probe key)
JOINS = {
    "nation":     ("nation", "n_nationkey", "n_regionkey", None, "customer", "c_nationkey"),
    "supplier":   ("supplier", "s_suppkey", "s_nationkey", None, "lineitem", "l_suppkey"),
    "customer":   ("customer", "c_custkey", "c_nationkey", None, "orders", "o_custkey"),
    "part":       ("part", "p_partkey", "CAST(p_retailprice * 100 AS BIGINT)", None, "lineitem", "l_partkey"),
    "part_promo": ("part", "p_partkey", "CAST(p_retailprice * 100 AS BIGINT)", "p_type LIKE 'PROMO%'",
                   "lineitem", "l_partkey"),
    "orders":     ("orders", "o_orderkey", "o_custkey", None, "lineitem", "l_orderkey"),
}


def join_reference(con, path):
    lines = []
    for name, (bt, bk, pay, filt, pt, pk) in JOINS.items():
        where = f"WHERE {filt}" if filt else ""
        build_rows = con.execute(f"SELECT count(*) FROM {bt} {where}").fetchone()[0]
        matches, total = con.execute(
            f"SELECT count(*), coalesce(sum(CAST(b.payload AS HUGEINT)), 0) FROM {pt} AS p "
            f"JOIN (SELECT {bk} AS k, {pay} AS payload FROM {bt} {where}) AS b ON p.{pk} = b.k").fetchone()
        lines.append(f"{name} {build_rows} {matches} {int(total) % 2**32}\n")
        print(f"  join {name:10s} build {build_rows:>9d} rows, {matches:>9d} matches")
    path.write_text("".join(lines))
    print(f"-> {path}")


Q1_OFFICIAL = """
SELECT l_returnflag, l_linestatus,
       sum(l_quantity) AS sum_qty,
       sum(l_extendedprice) AS sum_base_price,
       sum(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
       sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
       avg(l_quantity) AS avg_qty,
       avg(l_extendedprice) AS avg_price,
       avg(l_discount) AS avg_disc,
       count(*) AS count_order
FROM lineitem
WHERE l_shipdate <= DATE '1998-12-01' - INTERVAL 90 DAY
GROUP BY l_returnflag, l_linestatus
ORDER BY l_returnflag, l_linestatus
"""


def time_query(con, sql, runs):
    """Median wall time in seconds of `runs` executions after one warm-up."""
    con.execute(sql).fetchall()
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        con.execute(sql).fetchall()
        times.append(time.perf_counter() - t0)
    return statistics.median(times)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="directory written by scripts/gen_tpch.py")
    ap.add_argument("--runs", type=int, default=5, help="timed DuckDB runs of the official Q1 and Q6 (after one warm-up)")
    args = ap.parse_args()
    data = Path(args.data)
    con = duckdb.connect(str(data / "tpch.duckdb"), read_only=True)

    cutoff = con.execute("SELECT CAST(DATE '1998-12-01' - INTERVAL 90 DAY AS DATE) - DATE '1970-01-01'").fetchone()[0]
    if cutoff != Q1_CUTOFF_DAYS:
        raise SystemExit(f"Q1 cutoff is day {cutoff}, expected {Q1_CUTOFF_DAYS}")
    q6_dates = con.execute("SELECT DATE '1994-01-01' - DATE '1970-01-01', "
                           "CAST(DATE '1994-01-01' + INTERVAL 1 YEAR AS DATE) - DATE '1970-01-01'").fetchone()
    if tuple(q6_dates) != Q6_DATES_DAYS:
        raise SystemExit(f"Q6 dates are days {q6_dates}, expected {Q6_DATES_DAYS}")

    rows = con.execute(Q1_EXACT).fetchall()
    out = data / "q1_expected.txt"
    out.write_text("".join(" ".join(str(int(v)) for v in r) + "\n" for r in rows))
    print(f"Q1: {len(rows)} groups, {sum(r[2] for r in rows)} rows pass the filter -> {out}")
    for r in rows:
        print(f"  {chr(r[0])}{chr(r[1])} count={r[2]} sum_charge={r[6]}")

    cnt, revenue = con.execute(Q6_EXACT).fetchone()
    out = data / "q6_expected.txt"
    out.write_text(f"{int(cnt)} {int(revenue)}\n")
    print(f"Q6: {cnt} rows pass the filter, revenue {int(revenue)} (x10^4) -> {out}")

    join_reference(con, data / "join_expected.txt")

    threads = con.execute("SELECT current_setting('threads')").fetchone()[0]
    for name, sql in (("Q1", Q1_OFFICIAL), ("Q6", Q6_OFFICIAL)):
        t = time_query(con, sql, args.runs)
        print(f"DuckDB official {name}: median {t * 1e3:.1f} ms over {args.runs} runs "
              f"({threads} threads; informational, not the baseline protocol)")


if __name__ == "__main__":
    main()
