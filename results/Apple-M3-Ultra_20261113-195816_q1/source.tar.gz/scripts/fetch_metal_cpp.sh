#!/usr/bin/env bash
# Download Apple's metal-cpp headers into third_party/metal-cpp.
# Pick the newest zip listed at https://developer.apple.com/metal/cpp/ and pass
# its URL as METAL_CPP_URL if the default below is outdated. The code here only
# uses long-stable API, so any recent version works.
set -euo pipefail
cd "$(dirname "$0")/.."

URL="${METAL_CPP_URL:-https://developer.apple.com/metal/cpp/files/metal-cpp_macOS15_iOS18.zip}"
DEST="third_party/metal-cpp"

if [[ -f "$DEST/Metal/Metal.hpp" ]]; then
  echo "metal-cpp already present in $DEST"
  exit 0
fi

mkdir -p third_party
tmp="$(mktemp -d)"
echo "Downloading $URL"
curl -fL "$URL" -o "$tmp/metal-cpp.zip"
unzip -q "$tmp/metal-cpp.zip" -d "$tmp"
mv "$tmp/metal-cpp" "$DEST"
rm -rf "$tmp"
echo "metal-cpp installed in $DEST"
