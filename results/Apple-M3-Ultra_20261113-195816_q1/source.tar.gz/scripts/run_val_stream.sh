#!/usr/bin/env bash
# Diagnostic sweep, not validation (bench/val_stream.cpp): GPU morsels of the stream and agg kernels
# next to Q1 itself, in one session, pipelined and with the GPU kept busy as in the Q1 runs. Results
# go to results/<machine>_<date-time>_stream/: val_stream.csv (column op names the variant) and,
# for q1, val_q1.csv. Variants:
#   stream<C>[_r<R>]  the first C (1..7) of Q1's columns, summed: --kernel stream --cols C [--rows-per-thread R]
#   agg1[_r<R>]       Q1's aggregation on l_shipdate alone: --kernel agg
#   q1                val_q1 itself (default grid)
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_val_stream.sh
#   VARIANTS="q1 stream7" DISPATCH="sync pipelined" scripts/run_val_stream.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

DATA="${DATA:-data/tpch-sf10}"
MIN_LOG2="${MIN_LOG2:-10}"
MAX_LOG2="${MAX_LOG2:-25}"
REPS="${REPS:-15}"
COOLDOWN="${COOLDOWN:-20}"
CACHE="${CACHE:-cold}"
DISPATCH="${DISPATCH:-pipelined}"
BATCH="${BATCH:-16}"  # morsels per pipelined batch (capped at 1 GiB of input)
SPIN="${SPIN:-20}"    # ms of ALU-only GPU work before each timed rep, as the Q1 runs
VARIANTS="${VARIANTS:-q1 stream1 stream2 stream4 stream7 stream7_r2 agg1}"

[[ -f "$DATA/l_shipdate.u32" ]] || { echo "missing $DATA — run: python3 scripts/gen_tpch.py --sf 10"; exit 1; }
re='^(stream|agg)([1-7])(_r([0-9]+))?$'
for v in $VARIANTS; do  # all of them before the sweep starts
  if [[ $v != q1 ]] && { ! [[ $v =~ $re ]] || [[ ${BASH_REMATCH[1]} == agg && ${BASH_REMATCH[2]} != 1 ]]; }; then
    echo "unknown variant $v (stream1..stream7, agg1, optional _r<R>; q1)" >&2
    exit 1
  fi
done

sweep_begin stream
sweep_settings "DATA=$DATA MIN_LOG2=$MIN_LOG2 MAX_LOG2=$MAX_LOG2 REPS=$REPS CACHE=$CACHE DISPATCH='$DISPATCH'" \
               "BATCH=$BATCH SPIN=$SPIN COOLDOWN=$COOLDOWN VARIANTS='$VARIANTS'"
common=(--device gpu --data "$DATA" --min-log2 "$MIN_LOG2" --max-log2 "$MAX_LOG2" --reps "$REPS" --cache "$CACHE"
        --batch "$BATCH" --gpu-spin-ms "$SPIN")
json=(--machine-json "$dir/machine.json")

first=1
for v in $VARIANTS; do
  if [[ $v == q1 ]]; then
    bin=build/val_q1
    args=()
    out="$dir/val_q1.csv"
  else
    [[ $v =~ $re ]]
    bin=build/val_stream
    args=(--kernel "${BASH_REMATCH[1]}" --cols "${BASH_REMATCH[2]}")
    if [[ -n "${BASH_REMATCH[4]}" ]]; then args+=(--rows-per-thread "${BASH_REMATCH[4]}"); fi
    out="$dir/val_stream.csv"
  fi
  for d in $DISPATCH; do
    if [[ $first == 1 ]]; then first=0; else sleep "$COOLDOWN"; fi
    "$bin" ${args[@]+"${args[@]}"} --dispatch "$d" "${common[@]}" --out "$out" ${json[@]+"${json[@]}"}
    json=()
  done
done

echo "done -> $dir"
