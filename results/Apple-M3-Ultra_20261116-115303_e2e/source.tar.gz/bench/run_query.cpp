// run_query — TPC-H Q1 or Q6 end to end: the whole table in morsels of n rows, placed on the GPU, on
// CPU worker threads (P and E), or on both, under a placement policy. The evaluation of the router
// (PLAN.md M3): what the cost model's placement wins over the static placements and over a
// model-free dynamic scheduler, measured as the wall time of the whole query.
//
//   --policy gpu      every morsel on the GPU, pipelined (--inflight command buffers in flight)
//   --policy cpu      every morsel on the CPU workers (--p-workers at USER_INTERACTIVE QoS, --e-workers at
//                     BACKGROUND QoS), which share one morsel counter
//   --policy split    the model's static split: the GPU takes the first share of the morsels, the CPU
//                     workers the rest, the share from the predicted per-morsel times (--t-gpu, --t-p,
//                     --t-e, in us, under contention; analysis/plan_e2e.py computes them from
//                     models/<machine>.json) so that both sides finish together; --gpu-share overrides it
//   --policy dynamic  one shared counter: every device takes the next morsel when it is free (no model)
//   --policy router   the shared counter, guided by the model: a device takes the next morsel only if its
//                     predicted time for it is no longer than the time the other devices would need for
//                     everything left, so a slow worker does not start a morsel that would end after the
//                     rest of the query (the fastest device class always takes); the GPU keeps --inflight
//                     morsels in flight and counts them as its latency
// Every rep runs the whole table once and is checked against the scalar reference and, if present,
// <data>/<query>_expected.txt (DuckDB). One warm-up run per policy, untimed. No cache flush: the table
// (SF10: 0.96 GB for Q6, 1.7 GB for Q1) is far larger than the caches, and a query starts cold anyway.
// CSV (one row per rep): machine, query, policy, n, morsels, workers, inflight, the predicted times, the
// measured wall time, the morsels and busy time per device class and when each class finished.
//
// usage: run_query --query q1|q6 --policy gpu|cpu|split|dynamic|router [--morsel-log2 20] [--data data/tpch-sf10]
//                  [--p-workers <P cores>] [--e-workers <E cores>] [--inflight 16] [--t-gpu us] [--t-p us] [--t-e us]
//                  [--gpu-share f] [--pred-ms t] [--reps 3] [--out results/run_query.csv] [--machine-json path]
//                  [--expect <data>/<query>_expected.txt]
#include <pthread/qos.h>

#include <Foundation/Foundation.hpp>
#include <Metal/Metal.hpp>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <deque>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include "common/args.hpp"
#include "common/bench.hpp"
#include "common/machine_info.hpp"
#include "common/metal_ctx.hpp"
#include "common/timer.hpp"
#include "engine/q1.hpp"
#include "engine/q1_gpu.hpp"
#include "engine/q6.hpp"
#include "engine/q6_gpu.hpp"

namespace {

using mcm::Clock;
using mcm::us_since;

struct Q1 {
  static constexpr const char* kOp = "q1";
  static constexpr const char* kKernelFile = "q1.metal";
  static constexpr size_t kBytesPerRow = mcm::q1::kBytesPerRow;
  using Columns = mcm::q1::Columns;
  using Result = mcm::q1::Result;
  using Gpu = mcm::q1::Gpu;
  static Columns load(const std::string& dir) { return mcm::q1::load_columns(dir); }
  static Result reference(const Columns& c, size_t begin, size_t n) { return mcm::q1::reference(c, begin, n); }
  static void cpu(const Columns& c, size_t begin, size_t n, Result& out) { mcm::q1::cpu(c, begin, n, out); }
  static bool load_expected(const std::string& path, Result& r) { return mcm::q1::load_expected(path, r); }
  static std::string describe(const Result& r) { return mcm::q1::describe(r); }
};

struct Q6 {
  static constexpr const char* kOp = "q6";
  static constexpr const char* kKernelFile = "q6.metal";
  static constexpr size_t kBytesPerRow = mcm::q6::kBytesPerRow;
  using Columns = mcm::q6::Columns;
  using Result = mcm::q6::Result;
  using Gpu = mcm::q6::Gpu;
  static Columns load(const std::string& dir) { return mcm::q6::load_columns(dir); }
  static Result reference(const Columns& c, size_t begin, size_t n) { return mcm::q6::reference(c, begin, n); }
  static void cpu(const Columns& c, size_t begin, size_t n, Result& out) { mcm::q6::cpu(c, begin, n, out); }
  static bool load_expected(const std::string& path, Result& r) { return mcm::q6::load_expected(path, r); }
  static std::string describe(const Result& r) { return mcm::q6::describe(r); }
};

struct Morsel {
  size_t begin;
  uint32_t n;
};

enum class Dev { gpu, p, e };
constexpr size_t kNone = static_cast<size_t>(-1);

// Who takes the next morsel, per policy (file header).
struct Dispatcher {
  std::string policy;
  size_t M = 0;
  std::atomic<size_t> next{0};      // shared counter (cpu, dynamic, router), or the CPU side of split
  std::atomic<size_t> gpu_next{0};  // split: the GPU's own counter over [0, gpu_end)
  size_t gpu_end = 0;
  double t_gpu = 0, t_p = 0, t_e = 0;  // predicted us per morsel under contention (split, router)
  int n_p = 0, n_e = 0, inflight = 1;
  bool gpu_on = false;

  double rate(Dev d) const { return d == Dev::gpu ? 1.0 / t_gpu : d == Dev::p ? 1.0 / t_p : 1.0 / t_e; }
  double total_rate() const { return (gpu_on ? rate(Dev::gpu) : 0) + n_p * rate(Dev::p) + n_e * rate(Dev::e); }
  double latency(Dev d, int in_flight) const {
    return d == Dev::gpu ? t_gpu * (in_flight + 1) : d == Dev::p ? t_p : t_e;
  }
  Dev fastest() const {
    double best = 1e300;
    Dev out = Dev::p;
    if (gpu_on && t_gpu < best) best = t_gpu, out = Dev::gpu;
    if (n_p > 0 && t_p < best) best = t_p, out = Dev::p;
    if (n_e > 0 && t_e < best) best = t_e, out = Dev::e;
    return out;
  }
  size_t take(Dev d, int in_flight) {
    if (policy == "split" && d == Dev::gpu) {
      const size_t i = gpu_next.fetch_add(1);
      return i < gpu_end ? i : kNone;
    }
    if (policy == "router" && d != fastest()) {
      const size_t rem = M - std::min(M, next.load());
      const double others = total_rate() - rate(d);
      if (others > 0 && latency(d, in_flight) > static_cast<double>(rem) / others) return kNone;
    }
    const size_t i = next.fetch_add(1);
    return i < M ? i : kNone;
  }
};

struct DevStats {
  size_t morsels = 0;
  double busy_us = 0, finished_us = 0;  // finished: when the last morsel of this device completed, from t0
};

template <class Q>
int run(const mcm::Args& a) {
  using Columns = typename Q::Columns;
  using Result = typename Q::Result;
  using Gpu = typename Q::Gpu;
  const std::string policy = a.str("policy", "");
  const std::vector<std::string> policies = {"gpu", "cpu", "split", "dynamic", "router"};
  if (std::find(policies.begin(), policies.end(), policy) == policies.end())
    throw std::runtime_error("--policy must be one of gpu, cpu, split, dynamic, router");
  const int log2n = static_cast<int>(a.i64("morsel-log2", 20));
  if (log2n < 10 || log2n > 26) throw std::runtime_error("--morsel-log2 must be in [10, 26]");
  const uint32_t n = 1u << log2n;
  const std::string data_dir = a.str("data", "data/tpch-sf10");
  const int inflight = static_cast<int>(a.i64("inflight", 16));
  if (inflight < 1 || inflight > 64) throw std::runtime_error("--inflight must be in [1, 64]");
  const int reps = static_cast<int>(a.i64("reps", 3));
  const std::string out_path = a.str("out", "results/run_query.csv");
  const std::string expect_path = a.str("expect", data_dir + "/" + std::string(Q::kOp) + "_expected.txt");
  const double pred_ms = a.f64("pred-ms", 0);
  mcm::acquire_bench_lock();

  NS::AutoreleasePool* pool = NS::AutoreleasePool::alloc()->init();
  mcm::MetalCtx ctx(std::vector<std::string>{std::string(MCM_KERNEL_DIR) + "/" + Q::kKernelFile});
  mcm::MachineInfo mi = mcm::collect_machine_info(ctx.device());
  if (a.has("machine-json")) std::ofstream(a.str("machine-json", "")) << mi.to_json();
  const int n_p = static_cast<int>(a.i64("p-workers", mi.p_cores));
  const int n_e = static_cast<int>(a.i64("e-workers", mi.e_cores));
  const bool gpu_on = policy != "cpu";
  const bool cpu_on = policy != "gpu";
  if (cpu_on && n_p + n_e == 0) throw std::runtime_error("no CPU workers");
  std::cerr << "machine: " << mi.cpu_brand << " | P=" << mi.p_cores << " E=" << mi.e_cores << " GPU cores=" << mi.gpu_cores
            << " | power=" << mi.power_source << (mi.low_power_mode ? " (LOW POWER MODE ON)" : "") << "\n";

  Columns cols = Q::load(data_dir);
  std::vector<Morsel> morsels;
  for (size_t b = 0; b < cols.rows; b += n) morsels.push_back({b, static_cast<uint32_t>(std::min<size_t>(n, cols.rows - b))});
  const size_t M = morsels.size();
  std::cerr << Q::kOp << ": " << cols.rows << " rows, " << M << " morsels of 2^" << log2n << " (" << (cols.rows * Q::kBytesPerRow >> 20)
            << " MiB) | policy " << policy << " | GPU " << (gpu_on ? "on, " + std::to_string(inflight) + " in flight" : "off")
            << " | CPU " << (cpu_on ? std::to_string(n_p) + " P + " + std::to_string(n_e) + " E workers" : "off") << "\n";

  Dispatcher disp;
  disp.policy = policy;
  disp.M = M;
  disp.t_gpu = a.f64("t-gpu", 0);
  disp.t_p = a.f64("t-p", 0);
  disp.t_e = a.f64("t-e", 0);
  disp.n_p = cpu_on ? n_p : 0;
  disp.n_e = cpu_on ? n_e : 0;
  disp.inflight = inflight;
  disp.gpu_on = gpu_on;
  double gpu_share = a.f64("gpu-share", -1);
  if (policy == "split" || policy == "router") {
    if (disp.t_gpu <= 0 || disp.t_p <= 0 || (disp.n_e > 0 && disp.t_e <= 0))
      throw std::runtime_error("--policy " + policy + " needs --t-gpu, --t-p and --t-e (predicted us per morsel; analysis/plan_e2e.py)");
    if (policy == "split") {
      if (gpu_share < 0) gpu_share = disp.rate(Dev::gpu) / disp.total_rate();
      disp.gpu_end = static_cast<size_t>(std::lround(gpu_share * static_cast<double>(M)));
      disp.gpu_end = std::min(disp.gpu_end, M);
      std::cerr << "split: GPU share " << gpu_share << " -> morsels [0, " << disp.gpu_end << "), CPU [" << disp.gpu_end << ", " << M << ")\n";
    }
  }

  // Reference (scalar) and DuckDB's answer, once.
  const Result ref_all = Q::reference(cols, 0, cols.rows);
  Result exp_all;
  const bool have_expect = Q::load_expected(expect_path, exp_all);
  if (have_expect && !(ref_all == exp_all)) std::cerr << "WARNING: the scalar reference disagrees with DuckDB\n";

  std::unique_ptr<Gpu> gpu;
  if (gpu_on) gpu = std::make_unique<Gpu>(ctx, cols, Gpu::default_max_groups(mi.gpu_cores));

  std::ifstream in(out_path);
  const bool empty = !in.good() || in.peek() == std::ifstream::traits_type::eof();
  in.close();
  std::ofstream csv(out_path, std::ios::app);
  if (empty)
    csv << "machine,op,data,policy,n,morsels,p_workers,e_workers,inflight,t_gpu_us,t_p_us,t_e_us,gpu_share,pred_ms,rep,t_ms,"
           "gpu_morsels,p_morsels,e_morsels,gpu_busy_ms,p_busy_ms,e_busy_ms,gpu_finished_ms,p_finished_ms,e_finished_ms,ok\n";
  const std::string data_tag = data_dir.substr(data_dir.find_last_of('/') + 1);

  for (int rep = -1; rep < reps; ++rep) {  // -1: warm-up, untimed and unrecorded
    disp.next = 0;
    disp.gpu_next = 0;
    if (policy == "split") disp.next = disp.gpu_end;
    std::atomic<int> ready{0}, go{0};
    const int parties = (gpu_on ? 1 : 0) + (cpu_on ? n_p + n_e : 0);
    DevStats st_gpu;
    std::vector<DevStats> st_cpu(static_cast<size_t>(cpu_on ? n_p + n_e : 0));
    Result got_gpu;
    std::vector<Result> got_cpu(st_cpu.size());
    Clock::time_point t0;
    auto wait_go = [&] {
      ready.fetch_add(1);
      while (go.load() == 0) std::this_thread::yield();
    };

    std::thread gpu_thread;
    if (gpu_on) {
      gpu_thread = std::thread([&] {
        pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
        std::vector<typename Gpu::Slot> slots(static_cast<size_t>(inflight));
        for (auto& s : slots) s = gpu->new_slot();
        struct InFlight {
          MTL::CommandBuffer* cb;
          int slot;
        };
        std::deque<InFlight> q;
        int free_slot = 0;
        wait_go();
        auto t_busy0 = Clock::now();
        auto retire = [&] {  // the oldest command buffer: wait, merge, free its slot
          InFlight f = q.front();
          q.pop_front();
          f.cb->waitUntilCompleted();
          if (f.cb->status() != MTL::CommandBufferStatusCompleted) throw std::runtime_error("GPU command buffer failed");
          got_gpu.merge(Gpu::read(slots[static_cast<size_t>(f.slot)]));
          f.cb->release();
          free_slot = f.slot;
          st_gpu.morsels++;
        };
        std::vector<int> free_slots;
        for (int i = 0; i < inflight; ++i) free_slots.push_back(i);
        while (true) {
          if (free_slots.empty()) {
            retire();
            free_slots.push_back(free_slot);
          }
          const size_t i = disp.take(Dev::gpu, static_cast<int>(q.size()));
          if (i == kNone) {
            if (q.empty()) break;
            retire();
            free_slots.push_back(free_slot);
            continue;
          }
          const int slot = free_slots.back();
          free_slots.pop_back();
          NS::AutoreleasePool* p = NS::AutoreleasePool::alloc()->init();
          MTL::CommandBuffer* cb = ctx.queue()->commandBuffer();
          cb->retain();
          MTL::ComputeCommandEncoder* enc = cb->computeCommandEncoder();
          gpu->encode(enc, morsels[i].begin, morsels[i].n, slots[static_cast<size_t>(slot)]);
          enc->endEncoding();
          cb->commit();
          p->release();
          q.push_back({cb, slot});
        }
        st_gpu.busy_us = us_since(t_busy0, Clock::now());
        st_gpu.finished_us = us_since(t0, Clock::now());
        for (auto& s : slots) Gpu::free_slot(s);
      });
    }
    std::vector<std::thread> workers;
    for (int w = 0; cpu_on && w < n_p + n_e; ++w) {
      workers.emplace_back([&, w] {
        const Dev d = w < n_p ? Dev::p : Dev::e;
        if (w == 0 || w == n_p) {
          mcm::place_cpu_thread(d == Dev::p ? "p" : "e");  // prints the core probe once per class
        } else {
          pthread_set_qos_class_self_np(d == Dev::p ? QOS_CLASS_USER_INTERACTIVE : QOS_CLASS_BACKGROUND, 0);
        }
        DevStats& st = st_cpu[static_cast<size_t>(w)];
        Result& got = got_cpu[static_cast<size_t>(w)];
        wait_go();
        while (true) {
          const size_t i = disp.take(d, 0);
          if (i == kNone) break;
          auto t1 = Clock::now();
          Q::cpu(cols, morsels[i].begin, morsels[i].n, got);
          st.busy_us += us_since(t1, Clock::now());
          st.morsels++;
          st.finished_us = us_since(t0, Clock::now());
        }
      });
    }
    while (ready.load() < parties) std::this_thread::yield();
    t0 = Clock::now();
    go.store(1);
    if (gpu_thread.joinable()) gpu_thread.join();
    for (auto& t : workers) t.join();
    const double t_ms = us_since(t0, Clock::now()) / 1e3;

    Result got = got_gpu;
    for (const Result& r : got_cpu) got.merge(r);
    const bool ok = got == ref_all && (!have_expect || got == exp_all);
    DevStats sp, se;
    for (int w = 0; w < static_cast<int>(st_cpu.size()); ++w) {
      DevStats& acc = w < n_p ? sp : se;
      acc.morsels += st_cpu[static_cast<size_t>(w)].morsels;
      acc.busy_us += st_cpu[static_cast<size_t>(w)].busy_us;
      acc.finished_us = std::max(acc.finished_us, st_cpu[static_cast<size_t>(w)].finished_us);
    }
    std::cerr << (rep < 0 ? "warm-up" : "rep " + std::to_string(rep)) << ": " << t_ms << " ms | GPU " << st_gpu.morsels << " morsels"
              << " | P " << sp.morsels << " | E " << se.morsels << " | finished at GPU " << st_gpu.finished_us / 1e3 << " P "
              << sp.finished_us / 1e3 << " E " << se.finished_us / 1e3 << " ms | " << (ok ? "exact" : "MISMATCH") << "\n";
    if (rep < 0) continue;
    csv << mi.tag() << "," << Q::kOp << "," << data_tag << "," << policy << "," << n << "," << M << "," << (cpu_on ? n_p : 0) << ","
        << (cpu_on ? n_e : 0) << "," << (gpu_on ? inflight : 0) << "," << disp.t_gpu << "," << disp.t_p << "," << disp.t_e << ","
        << (policy == "split" ? gpu_share : -1.0) << "," << pred_ms << "," << rep << "," << t_ms << "," << st_gpu.morsels << ","
        << sp.morsels << "," << se.morsels << "," << st_gpu.busy_us / 1e3 << "," << sp.busy_us / 1e3 << "," << se.busy_us / 1e3 << ","
        << st_gpu.finished_us / 1e3 << "," << sp.finished_us / 1e3 << "," << se.finished_us / 1e3 << "," << (ok ? 1 : 0) << "\n";
    if (!ok) {
      std::cerr << "result:\n" << Q::describe(got) << "reference:\n" << Q::describe(ref_all);
      return 2;
    }
  }
  csv.close();
  std::cerr << "-> " << out_path << "\n";
  gpu.reset();
  pool->release();
  return 0;
}

}  // namespace

int main(int argc, char** argv) {
  try {
    const mcm::Args a(argc, argv);
    const std::string q = a.str("query", "");
    if (a.has("help") || (q != "q1" && q != "q6")) {
      std::cerr << "usage: run_query --query q1|q6 --policy gpu|cpu|split|dynamic|router [--morsel-log2 20] [--data data/tpch-sf10]\n"
                   "                 [--p-workers <P cores>] [--e-workers <E cores>] [--inflight 16] [--t-gpu us] [--t-p us] [--t-e us]\n"
                   "                 [--gpu-share f] [--pred-ms t] [--reps 3] [--out results/run_query.csv] [--machine-json path]\n"
                   "                 [--expect <data>/<query>_expected.txt]\n";
      return a.has("help") ? 0 : 1;
    }
    return q == "q1" ? run<Q1>(a) : run<Q6>(a);
  } catch (const std::exception& e) {
    std::cerr << "error: " << e.what() << "\n";
    return 1;
  }
}
