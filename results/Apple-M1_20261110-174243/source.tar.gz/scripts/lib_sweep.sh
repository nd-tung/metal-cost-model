# Sourced by scripts/run_calib_*.sh. `sweep_begin <dir-suffix>` gives every sweep:
#  - the machine to itself: a lock that other sweeps respect, and that the benchmark binaries
#    check too (common/bench.hpp), so a stray benchmark cannot run inside a sweep. Two sweeps
#    that overlapped once contaminated each other's data for six minutes.
#  - a fresh results directory named to the second; it refuses to reuse an existing one.
#  - binaries rebuilt from the current source, and that source recorded next to the data:
#    $dir/source.txt (commit, dirty flag, changed files) and, if the source differs from the
#    commit, $dir/source.tar.gz with the exact files the binaries were built from.
# It sets $dir and $chip, and exports MCM_SWEEP_PID for the benchmark binaries.

SWEEP_LOCK=/tmp/metal-cost-model-sweep.lock   # must match kSweepLockDir in src/common/bench.hpp
SOURCE_PATHS=(CMakeLists.txt src bench kernels scripts analysis)

sweep_begin() {
  if ! mkdir "$SWEEP_LOCK" 2>/dev/null; then
    local holder
    holder="$(cat "$SWEEP_LOCK/pid" 2>/dev/null || true)"
    if [[ -n "$holder" ]] && kill -0 "$holder" 2>/dev/null; then
      echo "error: another sweep is running (pid $holder); wait for it or stop it first" >&2
      exit 3
    fi
    echo "note: removing a stale sweep lock (pid ${holder:-unknown} has exited)" >&2
    rm -rf "$SWEEP_LOCK"
    mkdir "$SWEEP_LOCK"
  fi
  echo $$ > "$SWEEP_LOCK/pid"
  trap 'rm -rf "$SWEEP_LOCK"' EXIT
  export MCM_SWEEP_PID=$$

  [[ -d build ]] || { echo "error: configure first: cmake -B build" >&2; exit 1; }
  cmake --build build -j > /dev/null   # the binaries must match the source recorded below

  chip="$(sysctl -n machdep.cpu.brand_string | tr ' ' '-')"
  dir="results/${chip}_$(date +%Y%m%d-%H%M%S)${1:+_$1}"
  if [[ -e "$dir" ]]; then echo "error: $dir already exists" >&2; exit 1; fi
  mkdir -p "$dir"

  local commit changed
  commit="$(git rev-parse HEAD 2>/dev/null || echo none)"
  changed="$(git status --porcelain -- "${SOURCE_PATHS[@]}" 2>/dev/null || true)"
  {
    echo "commit: $commit"
    echo "source_dirty: $([[ -n "$changed" ]] && echo yes || echo no)"
    echo "started: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "script: $0"
    if [[ -n "$changed" ]]; then
      echo "changed or untracked source files (snapshot in source.tar.gz):"
      echo "$changed"
    fi
  } > "$dir/source.txt"
  if [[ -n "$changed" ]]; then
    tar czf "$dir/source.tar.gz" --exclude '__pycache__' "${SOURCE_PATHS[@]}"
    echo "warning: source differs from commit ${commit:0:7}; snapshot saved in $dir/source.tar.gz" >&2
  fi
}

# Appends the sweep's settings to source.txt: sweep_settings "NAME=value ..."
sweep_settings() { echo "settings: $*" >> "$dir/source.txt"; }
