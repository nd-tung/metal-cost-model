#!/usr/bin/env bash
# Full calib_contention sweep for one machine: GPU solo, CPU solo and CPU+GPU together,
# for P and E workers at 1, 2, 4 threads. Results go to results/<machine>_<date-time>_contention/.
# Before running: plug in AC power, turn Low Power Mode off, close other apps.
#
#   scripts/run_calib_contention.sh
#   THREADS="1 2 3 4" REPS=7 scripts/run_calib_contention.sh
#   DURATION=0.5 REPS=2 COOLDOWN=2 scripts/run_calib_contention.sh   # quick smoke run
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/lib_sweep.sh

BIN=build/calib_contention
THREADS="${THREADS:-1 2 4}"
REPS="${REPS:-5}"
DURATION="${DURATION:-1.5}"
COOLDOWN="${COOLDOWN:-20}"   # seconds between configurations (fanless MacBook Air: thermal)

sweep_begin contention
sweep_settings "THREADS='$THREADS' REPS=$REPS DURATION=$DURATION COOLDOWN=$COOLDOWN"
csv="$dir/calib_contention.csv"
common=(--reps "$REPS" --duration "$DURATION" --out "$csv")

"$BIN" --cpu-threads 0 --gpu on "${common[@]}" --machine-json "$dir/machine.json"
sleep "$COOLDOWN"
for q in p e; do
  for t in $THREADS; do
    "$BIN" --cpu-threads "$t" --qos "$q" --gpu off "${common[@]}"
    sleep "$COOLDOWN"
    "$BIN" --cpu-threads "$t" --qos "$q" --gpu on "${common[@]}"
    sleep "$COOLDOWN"
  done
done
# GPU solo again at the end: detects thermal drift over the sweep.
"$BIN" --cpu-threads 0 --gpu on "${common[@]}"

echo "done -> $dir"
